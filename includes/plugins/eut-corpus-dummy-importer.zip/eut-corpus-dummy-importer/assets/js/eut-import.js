jQuery(document).ready(function($) {

	"use strict";

	$('.eut-import-clear-selection').click(function(e) {
		e.preventDefault();
		$(this).closest( ".eut-importer-content" ).find('.eut-single-selector option:selected').prop("selected", false);
	});

	$('.eut-import-dummy-data').click(function(e) {
		e.preventDefault();
		var confirmText = eut_import_texts.confirmation_text;
		var dummySingularElement = $(this).closest( ".eut-admin-dummy-item" ).find('.eut-admin-dummy-option-singular');
		if( dummySingularElement.length ) {
			confirmText = eut_import_texts.confirmation_text_singular;
		}
		var eutConfirm = confirm( confirmText );
		if ( eutConfirm == true ) {

			$('#eut-import-output-info').hide().html('');
			$('#eut-import-output-container').hide().html('');

			$('.eut-import-dummy-data').attr('disabled','disabled').addClass('disabled');
			$('.eut-admin-dummy-item').hide();
			$('#eut-import-loading').show();
			$('#eut-import-countdown').show();

			//Show Loader
			$('#eut-importer-loader').show();

			var startTime = new Date();
			$('#eut-import-countdown').countdown('destroy');
			$('#eut-import-countdown').countdown({since: startTime, format: 'MS'});

			var dummyID = $(this).data('dummy-id');

			var dummySinglePages = false,
				dummyContent  = false,
				dummyOptions  = false,
				dummyWidgets  = false,
				dummySingular  = false,
				dummyDemoImages = false,
				dummySinglePages = '',
				dummySinglePosts = '',
				dummySinglePortfolios = '',
				dummySingleProducts = '';

			var dummyNonce = $(this).closest( ".eut-admin-dummy-item" ).find('.eut-admin-dummy-option-dummy-nonce').val();

			if( dummySingularElement.length ) {
				dummySingular = $(this).closest( ".eut-admin-dummy-item" ).find('.eut-admin-dummy-option-singular').val();
				dummySinglePages = $(this).closest( ".eut-admin-dummy-item" ).find('.eut-admin-dummy-option-single-pages').val();
				dummySinglePosts = $(this).closest( ".eut-admin-dummy-item" ).find('.eut-admin-dummy-option-single-posts').val();
				dummySinglePortfolios = $(this).closest( ".eut-admin-dummy-item" ).find('.eut-admin-dummy-option-single-portfolios').val();
				dummySingleProducts = $(this).closest( ".eut-admin-dummy-item" ).find('.eut-admin-dummy-option-single-products').val();
				dummyDemoImages = $(this).closest( ".eut-admin-dummy-item" ).find('.eut-admin-dummy-option-single-demo-images').is(':checked');
			} else {
				dummyContent = $(this).closest( ".eut-admin-dummy-item" ).find('.eut-admin-dummy-option-dummy-content').is(':checked');
				dummyOptions = $(this).closest( ".eut-admin-dummy-item" ).find('.eut-admin-dummy-option-theme-options').is(':checked');
				dummyWidgets = $(this).closest( ".eut-admin-dummy-item" ).find('.eut-admin-dummy-option-widgets').is(':checked');
			}

			$.post(
				ajaxurl, {
					action:'eut_import_dummy_data',
					eut_import_data: dummyID,
					eut_import_content: dummyContent,
					eut_import_options: dummyOptions,
					eut_import_widgets: dummyWidgets,
					eut_import_single_pages: dummySinglePages,
					eut_import_single_posts: dummySinglePosts,
					eut_import_single_portfolios: dummySinglePortfolios,
					eut_import_single_products: dummySingleProducts,
					eut_import_singular: dummySingular,
					eut_import_demo_images: dummyDemoImages,
					nonce: dummyNonce
				},
				function( response ) {
					$('#eut-import-countdown').countdown('pause');
					$('#eut-import-loading').hide();
					if ( '-1' != response ) {
						if(response.changed){
							if(!response.errors){
								$( "#eut-import-finish-form" ).submit();
							} else {
								$('#eut-import-output-info').show().append(response.info);
								$('#eut-import-output-container').show().append(response.output);
								$('.eut-import-dummy-data').removeAttr('disabled').removeClass('disabled');
							}
						} else {
							$('#eut-import-countdown').hide();
							$('#eut-import-output-info').show().append(response.info);
							$('.eut-admin-dummy-item').show();
							$('.eut-import-dummy-data').removeAttr('disabled').removeClass('disabled');
						}
					}
				}
			);
		}

	});

});