<?php
/*
 * Plugin Name: Corpus Extension
 * Description: This plugin extends Visual Composer and adds custom post type capabilities.
 * Author: Euthemians Team
 * Author URI: http://euthemians.com
 * Version: 2.13
 * Text Domain: eut-corpus-vc-extension
 */

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! defined( 'CORPUS_EXT_VERSION' ) ) {
	define( 'CORPUS_EXT_VERSION', '2.13' );
}

if ( ! defined( 'EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH' ) ) {
	define( 'EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'EUT_CORPUS_VC_EXT_PLUGIN_DIR_URL' ) ) {
	define( 'EUT_CORPUS_VC_EXT_PLUGIN_DIR_URL', plugin_dir_url( __FILE__ ) );
}

if ( ! class_exists( 'EUT_CORPUS_VC_Extension_Plugin' ) ) {

	class EUT_CORPUS_VC_Extension_Plugin {

		/**
		 * @action plugins_loaded
		 * @return EUT_CORPUS_VC_Extension_Plugin
		 * @static
		 */
		public static function init()
		{

			static $instance = false;

			if ( ! $instance ) {
				load_plugin_textdomain( 'eut-corpus-vc-extension' , false , dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
				$instance = new EUT_CORPUS_VC_Extension_Plugin;
			}
			return $instance;

		}

		/* Add Visual Composer Plugin*/

		private function __construct() {

			if ( is_user_logged_in() ) {
				add_action( 'admin_enqueue_scripts' , $this->marshal( 'eut_vc_extension_add_scripts' ) );
			}

			require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'includes/eut-functions.php';
			require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'includes/eut-add-param.php';
			require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'includes/eut-shortcode-param.php';


			//Shortcodes
			if( function_exists( 'vc_lean_map' ) || function_exists( 'vc_map' ) ) {

				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_title.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_divider.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_list.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_button.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_quote.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_dropcap.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_slogan.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_callout.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_progress_bar.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_pricing_table.php';

				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_message_box.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_icon_box.php';

				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_image_text.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_media_box.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_single_image.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_gallery.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_slider.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_video.php';

				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_social.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_gmap.php';

				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_team.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_blog.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_portfolio.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_testimonial.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_counter.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_pie_chart.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_typed_text.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_expandable_info.php';
				
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_privacy_gtracking.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_privacy_gmaps.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_privacy_gfonts.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_privacy_video_embeds.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_privacy_required.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_privacy_policy_page_link.php';
				require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'shortcodes/eut_privacy_preferences_link.php';

			}

		}

		public function EUT_CORPUS_VC_Extension_Plugin() {
			$this->__construct();
		}


		public function eut_vc_extension_add_scripts( $hook ) {
			wp_enqueue_style('eut-vc-elements', EUT_CORPUS_VC_EXT_PLUGIN_DIR_URL .'assets/css/eut-vc-elements.css', array(), time(), 'all');
			wp_enqueue_style('eut-vc-icon-box', EUT_CORPUS_VC_EXT_PLUGIN_DIR_URL .'assets/css/eut-icon-preview.css', array(), time(), 'all');
			wp_enqueue_style('eut-vc-multi-checkbox', EUT_CORPUS_VC_EXT_PLUGIN_DIR_URL .'assets/css/eut-multi-checkbox.css', array(), time(), 'all');
		}

		public function marshal( $method_name ) {
			return array( &$this , $method_name );
		}
	}

	/**
	 * Initialize Extension Plugin
	 */
	add_action( 'init' , array( 'EUT_CORPUS_VC_Extension_Plugin' , 'init' ), 12 );

	/**
	 * Initialize Custom Post Types
	 */
	function eut_corpus_rewrite_flush() {

		eut_corpus_register_custom_post_init();
		flush_rewrite_rules();
	}
	register_activation_hook( __FILE__, 'eut_corpus_rewrite_flush' );

	function eut_corpus_register_custom_post_init() {
		require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'includes/eut-portfolio-post-type.php';
		require_once EUT_CORPUS_VC_EXT_PLUGIN_DIR_PATH . 'includes/eut-testimonial-post-type.php';
	}
	add_action( 'init', 'eut_corpus_register_custom_post_init', 9 );

	function corpus_ext_vce_body_class( $classes ){
		$ext_ver = 'eut-vce-ver-' . CORPUS_EXT_VERSION;
		return array_merge( $classes, array( $ext_ver ) );
	}
	add_filter( 'body_class', 'corpus_ext_vce_body_class' );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
