<?php
/**
 * Team Shortcode
 */

if( !function_exists( 'eut_team_shortcode' ) ) {

	function eut_team_shortcode( $attr, $content ) {

		$output = $data = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'image' => '',
					'image_size' => 'square',
					'name' => '',
					'identity' => '',
					'social_facebook' => '',
					'social_twitter' => '',
					'social_linkedin' => '',
					'align' => 'left',
					'email' => '',
					'link' => '',
					'animation' => '',
					'animation_delay' => '200',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$attr
			)
		);

		if ( !empty( $animation ) ) {
			$animation = 'eut-' . $animation;
		}

		if( 'square' == $image_size ) {
			$image_size = 'eut-image-small-square';
		} elseif( 'portrait' == $image_size ) {
			$image_size = 'eut-image-small-rect-vertical';
		} elseif ( 'landscape' == $image_size ) {
			$image_size = 'eut-image-small-rect-horizontal';
		} elseif( 'medium_large' == $image_size ) {
			$image_size = 'medium_large';
		} elseif( 'medium' == $image_size ) {
			$image_size = 'medium';
		}  else {
			$image_size = 'large';
		}


		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		if ( !empty( $image ) ) {
			$id = preg_replace('/[^\d]/', '', $image);
			$image_string = wp_get_attachment_image( $id, $image_size );
		} else {
			$image_string = eut_corpus_vce_get_empty_image( $image_size );
		}

		if ( !empty( $link ) ){
			$href = vc_build_link( $link );
			$url = $href['url'];
			if ( !empty( $href['target'] ) ){
				$target = $href['target'];
			} else {
				$target = "_self";
			}
		} else {
			$url = "#";
			$target = "_self";
		}
		$target = trim( $target );

		$links = '';
		if ( !empty( $social_facebook ) ) {
			$links .= '<li><a href="' . esc_url( $social_facebook ) . '" target="_blank" class="eut-small-text">Facebook</a></li>';
		}
		if ( !empty( $social_twitter ) ) {
			$links .= '<li><a href="' . esc_url( $social_twitter ) . '" target="_blank" class="eut-small-text">Twitter</a></li>';
		}
		if ( !empty( $social_linkedin ) ) {
			$links .= '<li><a href="' . esc_url( $social_linkedin ) . '" target="_blank" class="eut-small-text">Linkedin</a></li>';
		}
		if ( !empty( $email ) ) {
			$links .= '<li><a href="mailto:' . antispambot( $email ) . '" class="eut-small-text">E-mail</a></li>';
		}

		$team_classes = array( 'eut-element' );

		if ( !empty( $animation ) ) {
			array_push( $team_classes, 'eut-animated-item' );
			array_push( $team_classes, $animation);
			$data = ' data-delay="' . esc_attr( $animation_delay ) . '"';
		}
		if ( !empty( $el_class ) ) {
			array_push( $team_classes, $el_class);
		}

		$team_class_string = implode( ' ', $team_classes );


		ob_start();

		?>

		<div class="eut-team <?php echo esc_attr( $team_class_string ); ?>" style="<?php echo $style; ?>"<?php echo $data; ?>>
			<figure>
				<?php if ( !empty( $url ) && '#' != $url ) { ?>
				<a href="<?php echo esc_url( $url ); ?>" target="<?php echo esc_attr( $target ); ?>">
				<?php } ?>
				<div class="eut-team-person eut-media eut-align-<?php echo esc_attr( $align ); ?>">
					<?php echo $image_string; ?>
				</div>
				<?php if ( !empty( $url ) && '#' != $url ) { ?>
				</a>
				<?php } ?>
				<figcaption>
					<div class="eut-team-description eut-align-<?php echo esc_attr( $align ); ?>">
						<div class="eut-team-identity eut-subtitle"><?php echo esc_html( $identity ); ?></div>
						<?php if ( !empty( $url ) && '#' != $url ) { ?>
						<a href="<?php echo esc_url( $url ); ?>" target="<?php echo esc_attr( $target ); ?>">
						<?php } ?>
						<h5 class="eut-team-name"><?php echo esc_html( $name ); ?></h5>
						<?php if ( !empty( $url ) && '#' != $url ) { ?>
						</a>
						<?php } ?>
						<?php if ( !empty( $content ) ) { ?>
						<p class="eut-team-content"><?php echo $content; ?></p>
						<?php } ?>
					</div>
					<?php if ( !empty( $links ) ) { ?>
					<div class="eut-team-social eut-align-<?php echo esc_attr( $align ); ?>">
						<ul>
							<?php echo $links; ?>
						</ul>
					</div>
					<?php } ?>
				</figcaption>
			</figure>
		</div>

		<?php

		return ob_get_clean();

	}
	add_shortcode( 'eut_team', 'eut_team_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_team_shortcode_params' ) ) {
	function eut_corpus_vce_team_shortcode_params( $tag ) {
		return array(
			"name" => __( "Team", "eut-corpus-vc-extension" ),
			"description" => __( "Show your team members", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-team",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "attach_image",
					"heading" => __( "Image", "eut-corpus-vc-extension" ),
					"param_name" => "image",
					"value" => '',
					"description" => __( "Select an image.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Image Mode", "eut-corpus-vc-extension" ),
					"param_name" => "image_size",
					'value' => array(
						__( 'Square Crop', 'eut-corpus-vc-extension' ) => 'square',
						__( 'Landscape Crop', 'eut-corpus-vc-extension' ) => 'landscape',
						__( 'Portrait Crop', 'eut-corpus-vc-extension' ) => 'portrait',
						__( 'Resize ( Large )', 'eut-corpus-vc-extension' ) => 'resize',
						__( 'Resize ( Medium Large )', 'eut-corpus-vc-extension' ) => 'medium_large',
						__( 'Resize ( Medium )', 'eut-corpus-vc-extension' ) => 'medium',
					),
					'std' => 'square',
					"description" => __( "Select your Image Mode.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Name", "eut-corpus-vc-extension" ),
					"param_name" => "name",
					"value" => "John Smith",
					"description" => __( "Enter your team name.", "eut-corpus-vc-extension" ),
					"save_always" => true,
					"admin_label" => true,
				),
				array(
					"type" => "textfield",
					"heading" => __( "Identity", "eut-corpus-vc-extension" ),
					"param_name" => "identity",
					"value" => "",
					"description" => __( "Enter your team identity/profession e.g: Designer", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Facebook", "eut-corpus-vc-extension" ),
					"param_name" => "social_facebook",
					"value" => "",
					"description" => __( "Enter facebook URL. Clear input if you don't want to display.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Twitter", "eut-corpus-vc-extension" ),
					"param_name" => "social_twitter",
					"value" => "",
					"description" => __( "Enter twitter URL. Clear input if you don't want to display.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Linkedin", "eut-corpus-vc-extension" ),
					"param_name" => "social_linkedin",
					"value" => "",
					"description" => __( "Enter linkedin URL. Clear input if you don't want to display.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Email", "eut-corpus-vc-extension" ),
					"param_name" => "email",
					"value" => "",
					"description" => __( "Enter your email. Clear input if you don't want to display.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textarea",
					"heading" => __( "Text", "eut-corpus-vc-extension" ),
					"param_name" => "content",
					"value" => "Sample Text",
					"description" => __( "Enter your text.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "vc_link",
					"heading" => __( "Link", "eut-corpus-vc-extension" ),
					"param_name" => "link",
					"value" => "",
					"description" => __( "Enter link.", "eut-corpus-vc-extension" ),
				),
				eut_vce_add_align(),
				eut_vce_add_animation(),
				eut_vce_add_animation_delay(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_team', 'eut_corpus_vce_team_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_team_shortcode_params( 'eut_team' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
