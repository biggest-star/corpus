<?php
/**
 * Quote Shortcode
 */

if( !function_exists( 'eut_quote_shortcode' ) ) {

	function eut_quote_shortcode( $atts, $content ) {

		$output = $data = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'animation' => '',
					'animation_delay' => '200',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		if ( !empty( $animation ) ) {
			$animation = 'eut-' . $animation;
		}

		$quote_classes = array( 'eut-element' );

		if ( !empty( $animation ) ) {
			array_push( $quote_classes, 'eut-animated-item' );
			array_push( $quote_classes, $animation);
			$data = ' data-delay="' . esc_attr( $animation_delay ) . '"';
		}

		if ( !empty( $el_class ) ) {
			array_push( $quote_classes, $el_class);
		}

		$quote_class_string = implode( ' ', $quote_classes );


		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );


		$output .= '<blockquote class="' . esc_attr( $quote_class_string ) . '" style="' . $style . '"' . $data . '>';
		$output .= '<p>' . $content . '</p>';
		$output .= '</blockquote>';


		return $output;
	}
	add_shortcode( 'eut_quote', 'eut_quote_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_quote_shortcode_params' ) ) {
	function eut_corpus_vce_quote_shortcode_params( $tag ) {
		return array(
			"name" => __( "Quote", "eut-corpus-vc-extension" ),
			"description" => __( "Easily create your Quote Text", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-quote",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "textarea",
					"heading" => __( "Text", "eut-corpus-vc-extension" ),
					"param_name" => "content",
					"value" => "Sample Quote",
					"description" => __( "Type your quote.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				eut_vce_add_animation(),
				eut_vce_add_animation_delay(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_quote', 'eut_corpus_vce_quote_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_quote_shortcode_params( 'eut_quote' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
