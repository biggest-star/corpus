<?php
/**
 * Privacy Required Shortcode
 */

if( !function_exists( 'eut_privacy_required_shortcode' ) ) {

	function eut_privacy_required_shortcode( $atts, $content ) {

		$output = '';
		
		extract(
			shortcode_atts(
				array(
					'value' => 'required',
				),
				$atts
			)
		);		

		if( empty( $content ) ) {
			$content = "write your required title here";
		}

		if ( function_exists( 'eut_get_privacy_required' ) ) {
			$output .= eut_get_privacy_required ( $value , $content );
		}

		return $output;
	}
	add_shortcode( 'eut_privacy_required', 'eut_privacy_required_shortcode' );

}

//Omit closing PHP tag to avoid accidental whitespace output errors.
