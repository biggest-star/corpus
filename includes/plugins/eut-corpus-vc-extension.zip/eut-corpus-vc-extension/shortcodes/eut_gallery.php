<?php
/**
 * Gallery Shortcode
 */

if( !function_exists( 'eut_gallery_shortcode' ) ) {

	function eut_gallery_shortcode( $attr, $content ) {

		$output = $start_block = $end_block = $item_class = $class_fullwidth = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'ids' => '',
					'gallery_type' => 'grid',
					'grid_image_mode' => 'square',
					'carousel_image_mode' => 'landscape',
					'carousel_popup' => '',
					'link_mode' => 'popup',
					'custom_links' => '',
					'custom_links_target' => '_self',
					'columns' => '3',
					'columns_tablet_landscape' => '2',
					'columns_tablet_portrait' => '2',
					'columns_mobile' => '1',
					'item_gutter' => 'yes',
					'hide_image_title' => '',
					'hide_image_caption' => '',
					'zoom_effect' => 'none',
					'overlay_color' => 'light',
					'overlay_opacity' => '90',
					'items_per_page' => '4',
					'slideshow_speed' => '3000',
					'auto_play' => 'yes',
					'navigation_type' => '1',
					'navigation_color' => 'dark',
					'pause_hover' => 'no',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$attr
			)
		);

		$attachments = explode( ",", $ids );

		if ( empty( $attachments ) ) {
			return '';
		}

		//Gallery Classes
		$gallery_classes = array( 'eut-element', 'eut-gallery' , 'eut-isotope' );

		if ( 'custom_link' == $link_mode ) {
			$custom_links = vc_value_from_safe( $custom_links );
			$custom_links = explode( ',', $custom_links );
		} elseif ( 'popup' == $link_mode ) {
			array_push( $gallery_classes, 'eut-gallery-popup' );
		}

		if ( !empty( $el_class ) ) {
			array_push( $gallery_classes, $el_class);
		}



		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		$data_string = '';

		switch( $gallery_type ) {
			case 'masonry':
				$data_string = ' data-columns="' . esc_attr( $columns ) . '" data-columns-tablet-landscape="' . esc_attr( $columns_tablet_landscape ) . '" data-columns-tablet-portrait="' . esc_attr( $columns_tablet_portrait ) . '" data-columns-mobile="' . esc_attr( $columns_mobile ) . '" data-layout="masonry"';
				if ( 'yes' == $item_gutter ) {
					array_push( $gallery_classes, 'eut-with-gap' );
				}
				break;
			case 'carousel':
				$data_string = ' data-items="' . esc_attr( $items_per_page ) . '" data-slider-autoplay="' . esc_attr( $auto_play ) . '" data-slider-speed="' . esc_attr( $slideshow_speed ) . '" data-slider-pause="' . esc_attr( $pause_hover ) . '"';
				break;
			case 'grid':
			default:
				$data_string = ' data-columns="' . esc_attr( $columns ) . '" data-columns-tablet-landscape="' . esc_attr( $columns_tablet_landscape ) . '" data-columns-tablet-portrait="' . esc_attr( $columns_tablet_portrait ) . '" data-columns-mobile="' . esc_attr( $columns_mobile ) . '" data-layout="fitRows"';
				if ( 'yes' == $item_gutter ) {
					array_push( $gallery_classes, 'eut-with-gap' );
				}
				break;
		}
		$gallery_class_string = implode( ' ', $gallery_classes );

		if ( 'carousel' == $gallery_type ) {
			//Gallery Output ( carousel)

			if( 'square' == $carousel_image_mode ) {
				$image_size = 'eut-image-small-square';
			} elseif( 'portrait' == $carousel_image_mode ) {
				$image_size = 'eut-image-small-rect-vertical';
			} else {
				$image_size = 'eut-image-small-rect-horizontal';
			}


			$output .= '<div class="eut-element eut-carousel-wrapper" style="' . $style . '">';

			if ( 0 != $navigation_type ) {

				$output .= '<div class="eut-carousel-navigation eut-' . esc_attr( $navigation_color ) . '" data-navigation-type="' . esc_attr( $navigation_type ) . '">';
				$output .= '	<div class="eut-carousel-buttons">';
				$output .= '		<div class="eut-carousel-prev eut-icon-nav-left"></div>';
				$output .= '		<div class="eut-carousel-next eut-icon-nav-right"></div>';
				$output .= '	</div>';
				$output .= '</div>';

			}
			$output .= '	<div class="eut-carousel eut-gallery-popup eut-carousel-element ' . esc_attr( $el_class ) . '"' . $data_string . '>

			';

				foreach ( $attachments as $id ) {
					$full_src = wp_get_attachment_image_src( $id, 'eut-image-fullscreen' );
					$image_title = get_post_field( 'post_title', $id );
					$caption = get_post_field( 'post_excerpt', $id );
					$link_data = '';
					if ( !empty( $image_title ) && 'yes' != $hide_image_title  ) {
						$link_data .= ' data-title="' . esc_attr( $image_title ) . '"';
					}
					if ( !empty( $caption ) && 'yes' != $hide_image_caption ) {
						$link_data .= ' data-desc="' . esc_attr( $caption ) . '"';
					}

					$output .= '<div class="eut-carousel-item">';
					if ( 'yes' == $carousel_popup ) {
					$output .= '  <a href="' . esc_url( $full_src[0] ) . '" ' . $link_data . '>';
					}
					$output .= '	<figure class="eut-image-hover">';
					$output .= '		<div class="eut-media">';
					$output .= wp_get_attachment_image( $id, $image_size );
					$output .= '		</div>';
					$output .= '	</figure>';
					if ( 'yes' == $carousel_popup ) {
					$output .= '  </a>';
					}
					$output .= '</div>';

				}
			$output .= '	</div>';
			$output .= '</div>';
		} else {
			//Gallery Output ( grid / masonry)
			$output .= '<div class="' . esc_attr( $gallery_class_string ) . '" style="' . $style . '"' . $data_string . '>';
			$output .= '  <div class="eut-isotope-container">';

			$gallery_index = 0;
			$i = -1;
			$image_size = 'eut-image-small-square';
			$image_size_class = '';

			foreach ( $attachments as $id ) {
				$gallery_index++;
				$i++;

				if ( 'masonry' == $gallery_type ) {

					$eut_masonry_data = eut_corpus_vce_get_masonry_data( $gallery_index, $columns );
					$image_size_class = ' ' . $eut_masonry_data['class'];
					$image_size = $eut_masonry_data['image_size'];

				} else {
					//Grid - Default
					if ( 'resize' == $grid_image_mode || 'large' == $grid_image_mode ) {
						$image_size = 'large';
					} elseif( 'medium_large' == $grid_image_mode ) {
						$image_size = 'medium_large';
					} elseif( 'medium' == $grid_image_mode ) {
						$image_size = 'medium';
					} elseif( 'square' == $grid_image_mode ) {
						$image_size = 'eut-image-small-square';
					} elseif( 'portrait' == $grid_image_mode ) {
						$image_size = 'eut-image-small-rect-vertical';
					} else {
						$image_size = 'eut-image-small-rect-horizontal';
					}
				}


				$image_link_href =  wp_get_attachment_url( $id );

				$full_src = wp_get_attachment_image_src( $id, 'eut-image-fullscreen' );
				$image_title = get_post_field( 'post_title', $id );
				$caption = get_post_field( 'post_excerpt', $id );

				$output .= '<div class="eut-isotope-item ' . $image_size_class . '">';
				if ( 'popup' ==  $link_mode ) {
					$output .= '<a href="' . esc_url( $full_src[0] ) . '">';
				} elseif ( 'custom_link' == $link_mode && isset( $custom_links[ $i ] ) && !empty(  $custom_links[ $i ] )  ) {
					$output .= '<a href="' . esc_url( $custom_links[ $i ] ) . '" target="' . esc_attr( $custom_links_target ) . '">';
				}
				$output .= '    <figure class="eut-image-hover eut-zoom-' . $zoom_effect . '">';
				$output .= '      <div class="eut-media eut-' . $overlay_color . '-overlay eut-opacity-' . $overlay_opacity . '">';
				$output .= wp_get_attachment_image( $id, $image_size );
				$output .= '      </div>';
				$output .= '      <figcaption>';

					if ( !empty( $image_title ) && 'yes' != $hide_image_title  ) {
						$output .= '<h5 class="eut-title eut-' . esc_attr( $overlay_color ) . '">' . wptexturize( $image_title ) . '</h5>';
					}

					if ( !empty( $caption ) && 'yes' != $hide_image_caption ) {
						$output .= '<span class="eut-caption eut-' . esc_attr( $overlay_color ) . '">' . wptexturize( $caption ) . '</span>';
					}

				$output .= '      </figcaption>';
				$output .= '    </figure>';
				if ( 'popup' ==  $link_mode ) {
					$output .= '</a>';
				} elseif ( 'custom_link' == $link_mode && isset( $custom_links[ $i ] ) && !empty(  $custom_links[ $i ] )  ) {
					$output .= '</a>';
				}
				$output .= '</div>';

			}

			$output .= '  </div>';
			$output .= '</div>';
		}


		return $output;

	}
	add_shortcode( 'eut_gallery', 'eut_gallery_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_gallery_shortcode_params' ) ) {
	function eut_corpus_vce_gallery_shortcode_params( $tag ) {
		return array(
			"name" => __( "Gallery", "eut-corpus-vc-extension" ),
			"description" => __( "Numerous styles, multiple columns for galleries", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-gallery",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "dropdown",
					"heading" => __( "Gallery type", "eut-corpus-vc-extension" ),
					"param_name" => "gallery_type",
					"value" => array(
						__( "Grid", "eut-corpus-vc-extension" ) => 'grid',
						__( "Masonry", "eut-corpus-vc-extension" ) => 'masonry',
						__( "Carousel", "eut-corpus-vc-extension" ) => 'carousel',
					),
					"description" => __( "Select your gallery type.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Grid Image Mode", "eut-corpus-vc-extension" ),
					"param_name" => "grid_image_mode",
					'value' => array(
						__( 'Square Crop', 'eut-corpus-vc-extension' ) => 'square',
						__( 'Landscape Crop', 'eut-corpus-vc-extension' ) => 'landscape',
						__( 'Portrait Crop', 'eut-corpus-vc-extension' ) => 'portrait',
						__( 'Resize ( Large )', 'eut-corpus-vc-extension' ) => 'resize',
						__( 'Resize ( Medium Large )', 'eut-corpus-vc-extension' ) => 'medium_large',
						__( 'Resize ( Medium )', 'eut-corpus-vc-extension' ) => 'medium',
					),
					'std' => 'square',
					"description" => __( "Select your Grid Image Mode.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "gallery_type", 'value' => array( 'grid' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Carousel Image Mode", "eut-corpus-vc-extension" ),
					"param_name" => "carousel_image_mode",
					'value' => array(
						__( 'Square Crop', 'eut-corpus-vc-extension' ) => 'square',
						__( 'Landscape Crop', 'eut-corpus-vc-extension' ) => 'landscape',
						__( 'Portrait Crop', 'eut-corpus-vc-extension' ) => 'portrait',
					),
					'std' => 'landscape',
					"description" => __( "Select your Carousel Image Mode.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "gallery_type", 'value' => array( 'carousel' ) ),
				),
				array(
					"type"			=> "attach_images",
					"admin_label"	=> true,
					"class"			=> "",
					"heading"		=> __( "Attach Images", "eut-corpus-vc-extension" ),
					"param_name"	=> "ids",
					"value" => '',
					"description"	=> __( "Select your gallery images.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Link Mode", "eut-corpus-vc-extension" ),
					"param_name" => "link_mode",
					'value' => array(
						__( 'Gallery Popup', 'eut-corpus-vc-extension' ) => 'popup',
						__( 'None', 'eut-corpus-vc-extension' ) => 'none',
						__( "Custom Link", "eut-corpus-vc-extension" ) => 'custom_link',
					),
					"description" => __( "Select your gallery link mode.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "gallery_type", 'value' => array( 'grid', 'masonry' ) ),
					"std" => 'popup',
				),
				array(
					'type' => 'exploded_textarea_safe',
					'heading' => __( 'Custom links', 'eut-corpus-vc-extension' ),
					'param_name' => 'custom_links',
					'description' => __( 'Enter links for each slide (Note: divide links with linebreaks (Enter)).', 'eut-corpus-vc-extension' ),
					'dependency' => array(
						'element' => 'link_mode',
						'value' => array( 'custom_link' ),
					),
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Custom link target', 'eut-corpus-vc-extension' ),
					'param_name' => 'custom_links_target',
					'description' => __( 'Select where to open custom links.', 'eut-corpus-vc-extension' ),
					'dependency' => array(
						'element' => 'link_mode',
						'value' => array( 'custom_link' ),
					),
					"value" => array(
						__( "Same Window", "eut-corpus-vc-extension" ) => '_self',
						__( "New Window", "eut-corpus-vc-extension" ) => '_blank',
					),
				),
				//Gallery ( grid /masonry )
				array(
					"type" => "dropdown",
					"heading" => __( "Columns", "eut-corpus-vc-extension" ),
					"param_name" => "columns",
					"value" => array( '2', '3', '4', '5' ),
					"std" => '3',
					"description" => __( "Select number of columns.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "gallery_type", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Tablet Landscape Columns", "eut-corpus-vc-extension" ),
					"param_name" => "columns_tablet_landscape",
					"value" => array( '2', '3', '4', '5' ),
					"std" => '2',
					"description" => __( "Select responsive column on tablet devices, landscape orientation.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "gallery_type", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Tablet Portrait Columns", "eut-corpus-vc-extension" ),
					"param_name" => "columns_tablet_portrait",
					"value" => array( '2', '3', '4', '5' ),
					"std" => '2',
					"description" => __( "Select responsive column on tablet devices, portrait orientation.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "gallery_type", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Mobile Columns", "eut-corpus-vc-extension" ),
					"param_name" => "columns_mobile",
					"value" => array( '1', '2', '3' ),
					"std" => '1',
					"description" => __( "Select responsive column on mobile devices.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "gallery_type", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Gutter between images", "eut-corpus-vc-extension" ),
					"param_name" => "item_gutter",
					"value" => array(
						__( "Yes", "eut-corpus-vc-extension" ) => 'yes',
						__( "No", "eut-corpus-vc-extension" ) => 'no',
					),
					"description" => __( "Add gutter among images.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "gallery_type", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Hide Image Title", "eut-corpus-vc-extension" ),
					"param_name" => "hide_image_title",
					"value" => Array( __( "If selected, image title will be hidden", "eut-corpus-vc-extension" ) => 'yes' ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Hide Image Caption", "eut-corpus-vc-extension" ),
					"param_name" => "hide_image_caption",
					"value" => Array( __( "If selected, image caption will be hidden", "eut-corpus-vc-extension" ) => 'yes' ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Image Zoom Effect", "eut-corpus-vc-extension" ),
					"param_name" => "zoom_effect",
					"value" => array(
						__( "Zoom In", "eut-corpus-vc-extension" ) => 'in',
						__( "Zoom Out", "eut-corpus-vc-extension" ) => 'out',
						__( "None", "eut-corpus-vc-extension" ) => 'none',
					),
					"description" => __( "Choose the image zoom effect.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "gallery_type", 'value' => array( 'grid', 'masonry' ) ),
					'std' => 'none',
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Overlay Color", "eut-corpus-vc-extension" ),
					"param_name" => "overlay_color",
					"value" => array(
						__( "Light", "eut-corpus-vc-extension" ) => 'light',
						__( "Dark", "eut-corpus-vc-extension" ) => 'dark',
						__( "Primary 1", "eut-corpus-vc-extension" ) => 'primary-1',
						__( "Primary 2", "eut-corpus-vc-extension" ) => 'primary-2',
						__( "Primary 3", "eut-corpus-vc-extension" ) => 'primary-3',
						__( "Primary 4", "eut-corpus-vc-extension" ) => 'primary-4',
						__( "Primary 5", "eut-corpus-vc-extension" ) => 'primary-5',
					),
					"description" => __( "Choose the image color overlay.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "gallery_type", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Overlay Opacity", "eut-corpus-vc-extension" ),
					"param_name" => "overlay_opacity",
					"value" => array( '0', '10', '20', '30', '40', '50', '60', '70', '80', '90', '100' ),
					"std" => '90',
					"description" => __( "Choose the opacity for the overlay.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "gallery_type", 'value' => array( 'grid', 'masonry' ) ),
				),
				//Gallery ( carousel )
				array(
					"type" => "dropdown",
					"heading" => __( "Items per page", "eut-corpus-vc-extension" ),
					"param_name" => "items_per_page",
					"value" => array( '3', '4', '5' ),
					"description" => __( "Number of images per page", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "gallery_type", 'value' => array( 'carousel' ) ),
					"std" => "4",
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Carousel Image Popup", "eut-corpus-vc-extension" ),
					"param_name" => "carousel_popup",
					"value" => Array( __( "Enable carousel image popup", "eut-corpus-vc-extension" ) => 'yes' ),
					"dependency" => Array( 'element' => "gallery_type", 'value' => array( 'carousel' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Autoplay", "eut-corpus-vc-extension" ),
					"param_name" => "auto_play",
					"value" => array(
						__( "Yes", "eut-corpus-vc-extension" ) => 'yes',
						__( "No", "eut-corpus-vc-extension" ) => 'no',
					),
					"dependency" => Array( 'element' => "gallery_type", 'value' => array( 'carousel' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Slideshow Speed", "eut-corpus-vc-extension" ),
					"param_name" => "slideshow_speed",
					"value" => '3000',
					"description" => __( "Slideshow Speed in ms.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "gallery_type", 'value' => array( 'carousel' ) ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Pause on Hover", "eut-corpus-vc-extension" ),
					"param_name" => "pause_hover",
					"value" => Array( __( "If selected, carousel will be paused on hover", "eut-corpus-vc-extension" ) => 'yes' ),
					"dependency" => Array( 'element' => "gallery_type", 'value' => array( 'carousel' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Navigation Type", "eut-corpus-vc-extension" ),
					"param_name" => "navigation_type",
					'value' => array(
						__( 'Style 1' , 'eut-corpus-vc-extension' ) => '1',
						__( 'Style 2' , 'eut-corpus-vc-extension' ) => '2',
						__( 'Style 3' , 'eut-corpus-vc-extension' ) => '3',
						__( 'Style 4' , 'eut-corpus-vc-extension' ) => '4',
						__( 'No Navigation' , 'eut-corpus-vc-extension' ) => '0',
					),
					"description" => __( "Select your Navigation type.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "gallery_type", 'value' => array( 'carousel' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Navigation Color", "eut-corpus-vc-extension" ),
					"param_name" => "navigation_color",
					'value' => array(
						__( 'Dark' , 'eut-corpus-vc-extension' ) => 'dark',
						__( 'Light' , 'eut-corpus-vc-extension' ) => 'light',
					),
					"description" => __( "Select the background Navigation color.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "gallery_type", 'value' => array( 'carousel' ) ),
				),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_gallery', 'eut_corpus_vce_gallery_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_gallery_shortcode_params( 'eut_gallery' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
