<?php
/**
 * Privacy Google Maps Shortcode
 */

if( !function_exists( 'eut_privacy_gmaps_shortcode' ) ) {

	function eut_privacy_gmaps_shortcode( $atts, $content ) {

		$output = '';

		if( empty( $content ) ) {
			$content = "Click to enable/disable Google Maps.";
		}

		if ( function_exists( 'eut_get_privacy_switch' ) ) {
			$output .= eut_get_privacy_switch ( 'eut-privacy-content-gmaps' , $content );
		}

		return $output;
	}
	add_shortcode( 'eut_privacy_gmaps', 'eut_privacy_gmaps_shortcode' );

}

//Omit closing PHP tag to avoid accidental whitespace output errors.
