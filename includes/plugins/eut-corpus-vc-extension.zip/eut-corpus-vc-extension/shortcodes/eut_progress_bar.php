<?php
/**
 * Progress Bar Shortcode
 */

if( !function_exists( 'eut_progress_bar_shortcode' ) ) {

	function eut_progress_bar_shortcode( $atts, $content ) {

		$output = $style = $bar_height_style = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'bar_style' => 'style-1',
					'values' => '',
					'bar_line_style' => 'square',
					'bar_height' => '35',
					'color' => 'primary-1',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		$bars_classes = array( 'eut-element', 'eut-progress-bars' );
		array_push( $bars_classes, 'eut-' . $bar_style );
		array_push( $bars_classes, 'eut-line-' . $bar_line_style );

		$bars_class_string = implode( ' ', $bars_classes );

		if( !empty( $bar_height ) && 'style-2' == $bar_style ) {
			$bar_height_style .= 'height: '.(preg_match('/(px|em|\%|pt|cm)$/', $bar_height) ? $bar_height : $bar_height.'px').';';
		}

		$style .= eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		$graph_lines = explode(",", $values);

		$graph_lines_data = array();
		foreach ($graph_lines as $line) {
			$new_line = array();
			$data = explode("|", $line);
			$new_line['value'] = isset( $data[0] ) && !empty( $data[0] ) ? $data[0] : 0;
			$new_line['percentage_value'] = isset( $data[1] ) && !empty( $data[1] ) ? $data[1] : '';
			$new_line['color'] = isset( $data[2] ) && !empty( $data[2] ) ? $data[2] : $color;

			if( (float)$new_line['value'] < 0 ) {
				$new_line['value'] = 0;
			} else if ( (float)$new_line['value'] > 100 ) {
				$new_line['value'] = 100;
			}

			$new_line['label'] = $new_line['percentage_value'];

			$graph_lines_data[] = $new_line;
		}

		$output .= '<div class="' . esc_attr( $bars_class_string ) . '" style="' . $style . '">';

		foreach($graph_lines_data as $line) {

			$color_class = 'eut-primary';
			if ( 'primary' != $line['color'] ) {
				$color_class = 'eut-bg-' . $line['color'];
			}

			$output .= '<div class="eut-element eut-progress-bar eut-margin-10" data-value="' .  esc_attr( $line['value'] ) . '">';
			$output .= '  <div class="eut-small-text eut-bar-title">' .  $line['label'] . '</div>';
			$output .= '  <div class="eut-bar">';
			$output .= '    <div class="eut-bar-line ' .  esc_attr( $color_class ) . '" style="' . $bar_height_style . '"></div>';
			$output .= '  </div>';
			$output .= '</div>';

		}

		$output .= '</div>';

		return $output;
	}
	add_shortcode( 'eut_progress_bar', 'eut_progress_bar_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_progress_bar_shortcode_params' ) ) {
	function eut_corpus_vce_progress_bar_shortcode_params( $tag ) {
		return array(
			"name" => __( "Progress Bar", "eut-corpus-vc-extension" ),
			"description" => __( "Create horizontal progress bar", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-progress-bar",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "dropdown",
					"heading" => __( "Progress Bar Style", "eut-corpus-vc-extension" ),
					"param_name" => "bar_style",
					"value" => array(
						__( "Style 1", "eut-corpus-vc-extension" ) => 'style-1',
						__( "Style 2", "eut-corpus-vc-extension" ) => 'style-2',
					),
					"description" => __( "Style of the bar line.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "exploded_textarea",
					"heading" => __("Bar values", "eut-corpus-vc-extension"),
					"param_name" => "values",
					"description" => __( "Input bar values here. Divide values with linebreaks (Enter). Example: 90|Development|black.", "eut-corpus-vc-extension" ) . '<br/>' .
									__( "Available colors: primary-1, green, orange, red, blue, aqua, purple, black, white.", "eut-corpus-vc-extension" ),
					"value" => "90|Development,80|Design,70|Marketing",
					"save_always" => true,
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Bars Color", "eut-corpus-vc-extension" ),
					"param_name" => "color",
					"value" => array(
						__( "Primary 1", "eut-corpus-vc-extension" ) => 'primary-1',
						__( "Primary 2", "eut-corpus-vc-extension" ) => 'primary-2',
						__( "Primary 3", "eut-corpus-vc-extension" ) => 'primary-3',
						__( "Primary 4", "eut-corpus-vc-extension" ) => 'primary-4',
						__( "Primary 5", "eut-corpus-vc-extension" ) => 'primary-5',
						__( "Green", "eut-corpus-vc-extension" ) => 'green',
						__( "Orange", "eut-corpus-vc-extension" ) => 'orange',
						__( "Red", "eut-corpus-vc-extension" ) => 'red',
						__( "Blue", "eut-corpus-vc-extension" ) => 'blue',
						__( "Aqua", "eut-corpus-vc-extension" ) => 'aqua',
						__( "Purple", "eut-corpus-vc-extension" ) => 'purple',
						__( "Black", "eut-corpus-vc-extension" ) => 'black',
						__( "Grey", "eut-corpus-vc-extension" ) => 'grey',
					),
					"description" => __( "Use single color for all bars ( If not specified in Bar values )", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Progress Bar Height", "eut-corpus-vc-extension" ),
					"param_name" => "bar_height",
					"value" => "35",
					"description" => __( "Enter progress bar height.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
					"dependency" => Array( 'element' => "bar_style", 'value' => array( 'style-2' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Bars Line Style", "eut-corpus-vc-extension" ),
					"param_name" => "bar_line_style",
					"value" => array(
						__( "Square", "eut-corpus-vc-extension" ) => 'square',
						__( "Round", "eut-corpus-vc-extension" ) => 'round',
					),
					"description" => __( "Style of the bar line.", "eut-corpus-vc-extension" ),
				),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_progress_bar', 'eut_corpus_vce_progress_bar_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_progress_bar_shortcode_params( 'eut_progress_bar' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
