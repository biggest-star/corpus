<?php
/**
 * Pie Chart Shortcode
 */

if( !function_exists( 'eut_pie_chart_shortcode' ) ) {

	function eut_pie_chart_shortcode( $atts, $content ) {

		$output = $link_start = $link_end = $retina_data = $data = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'pie_chart_val' => '50',
					'pie_chart_prefix' => '',
					'pie_chart_suffix' => '',
					'pie_chart_line_size' => '6',
					'pie_chart_color' => '',
					'pie_active_color' => '',
					'pie_line_style' => 'square',
					'title' => '',
					'heading' => 'h3',
					'pie_chart_text' => '',
					'animation' => '',
					'animation_delay' => '200',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		if ( !empty( $animation ) ) {
			$animation = 'eut-' . $animation;
		}

		$pie_chart_classes = array( 'eut-element' );

		array_push( $pie_chart_classes, 'eut-pie-chart' );

		if ( !empty( $animation ) ) {
			array_push( $pie_chart_classes, 'eut-animated-item' );
			array_push( $pie_chart_classes, $animation);
			$data = ' data-delay="' . esc_attr( $animation_delay ) . '"';
		}

		if ( !empty ( $el_class ) ) {
			array_push( $pie_chart_classes, $el_class);
		}

		$pie_chart_class_string = implode( ' ', $pie_chart_classes );


		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );


		$output .= '<div class="' . esc_attr( $pie_chart_class_string ) . '" style="' . $style . '"' . $data . '>';
		$output .= '  <div class="eut-chart-number" data-percent="' . esc_attr( $pie_chart_val ) . '" data-pie-active-color="' . esc_attr( $pie_active_color ) . '" data-pie-color="' . esc_attr( $pie_chart_color ) . '" data-pie-line-cap="' . esc_attr( $pie_line_style ) . '" data-pie-line-size="' . esc_attr( $pie_chart_line_size ) . '">';
		$output .= '    <span class="eut-counter">' . $pie_chart_prefix . $pie_chart_val . $pie_chart_suffix . '</span>';
		$output .= '  </div>';
			if ( !empty( $title ) ) {
				$output .= '	  <' . $heading . ' class="eut-chart-title">' . $title. '</' . $heading . '>';
			}
			if ( !empty( $pie_chart_text ) ) {
				$output .= '      <p>' . $pie_chart_text. '</p>';
			}
		$output .= '</div>';

		return $output;
	}
	add_shortcode( 'eut_pie_chart', 'eut_pie_chart_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_pie_chart_shortcode_params' ) ) {
	function eut_corpus_vce_pie_chart_shortcode_params( $tag ) {
		return array(
			"name" => __( "Pie Chart", "eut-corpus-vc-extension" ),
			"description" => __( "Add a counter with icon and title", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-pie-chart",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "textfield",
					"heading" => __( "Pie Chart Value", "eut-corpus-vc-extension" ),
					"param_name" => "pie_chart_val",
					"value" => "50",
					"description" => __( "Enter the pie chart value number.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "textfield",
					"heading" => __( "Value Prefix", "eut-corpus-vc-extension" ),
					"param_name" => "pie_chart_prefix",
					"value" => "",
					"description" => __( "Enter value prefix.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Value Suffix", "eut-corpus-vc-extension" ),
					"param_name" => "pie_chart_suffix",
					"value" => "",
					"description" => __( "Enter value suffix.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Pie Chart Line Size", "eut-corpus-vc-extension" ),
					"param_name" => "pie_chart_line_size",
					"value" => "6",
					"description" => __( "Enter pie chart line size.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Pie Chart Style", "eut-corpus-vc-extension" ),
					"param_name" => "pie_line_style",
					"value" => array(
						__( "Square", "eut-corpus-vc-extension" ) => 'square',
						__( "Round", "eut-corpus-vc-extension" ) => 'round',
					),
					"description" => __( "Set the pie chart shape style", "eut-corpus-vc-extension" ),
				),
				array(
					'type' => 'colorpicker',
					'heading' => __( "Pie Chart Active Color", "eut-corpus-vc-extension" ),
					'param_name' => 'pie_active_color',
					'description' => __( "Select the active color for your pie", "eut-corpus-vc-extension" ),
				),
				array(
					'type' => 'colorpicker',
					'heading' => __( "Pie Chart Base Color", "eut-corpus-vc-extension" ),
					'param_name' => 'pie_chart_color',
					'description' => __( "Select the base color for your pie", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Title", "eut-corpus-vc-extension" ),
					"param_name" => "title",
					"value" => "",
					"description" => __( "Enter pie chart title", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Heading", "eut-corpus-vc-extension" ),
					"param_name" => "heading",
					"admin_label" => true,
					"value" => array( 'h1', 'h2', 'h3', 'h4' , 'h5', 'h6' ),
					"description" => __( "Heading size", "eut-corpus-vc-extension" ),
					"std" => "h3",
				),
				array(
					"type" => "textarea",
					"heading" => __( "Text", "eut-corpus-vc-extension" ),
					"param_name" => "pie_chart_text",
					"value" => "",
					"description" => __( "Type your text", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				eut_vce_add_animation(),
				eut_vce_add_animation_delay(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_pie_chart', 'eut_corpus_vce_pie_chart_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_pie_chart_shortcode_params( 'eut_pie_chart' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
