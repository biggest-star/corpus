<?php
/**
 * Privacy Video Embeds Shortcode
 */

if( !function_exists( 'eut_privacy_video_embeds_shortcode' ) ) {

	function eut_privacy_video_embeds_shortcode( $atts, $content ) {

		$output = $el_class = '';

		if( empty( $content ) ) {
			$content = "Click to enable/disable video embeds.";
		}

		if ( function_exists( 'eut_get_privacy_switch' ) ) {
			$output .= eut_get_privacy_switch ( 'eut-privacy-content-video-embeds' , $content );
		}

		return $output;
	}
	add_shortcode( 'eut_privacy_video_embeds', 'eut_privacy_video_embeds_shortcode' );

}

//Omit closing PHP tag to avoid accidental whitespace output errors.
