<?php
/**
 * Privacy Link
 */

if( !function_exists( 'eut_privacy_preferences_link_shortcode' ) ) {

	function eut_privacy_preferences_link_shortcode( $atts, $content ) {

		$output = '';

		if ( function_exists( 'eut_get_privacy_preferences_link' ) ) {
			$output .= eut_get_privacy_preferences_link ( $content );
		}
		return $output;
	}
	add_shortcode( 'eut_privacy_preferences_link', 'eut_privacy_preferences_link_shortcode' );

}


//Omit closing PHP tag to avoid accidental whitespace output errors.
