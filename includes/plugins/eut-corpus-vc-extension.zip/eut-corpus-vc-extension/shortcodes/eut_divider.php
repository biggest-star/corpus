<?php
/**
 * Divider Shortcode
 */

if( !function_exists( 'eut_divider_shortcode' ) ) {

	function eut_divider_shortcode( $atts, $content ) {

		$output = $class_fullwidth = $style = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'line_type' => 'line',
					'backtotop_title' => '',
					'padding_top' => '',
					'padding_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		$style .= eut_corpus_vce_build_padding_top_style( $padding_top );
		$style .= eut_corpus_vce_build_padding_bottom_style( $padding_bottom );

		$output .= '<div class="eut-element eut-hr ' . $el_class.'" style="' . $style . '">';
			$output .= '<div class="eut-' . $line_type . '-divider">';
			if ( !empty( $backtotop_title ) && 'top-line' == $line_type ) {
				$output .= '    <span class="eut-divider-backtotop eut-small-text">' . $backtotop_title. '</span>';
			}
			$output .= '</div>';
		$output .= '</div>';

		return $output;
	}
	add_shortcode( 'eut_divider', 'eut_divider_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_divider_shortcode_params' ) ) {
	function eut_corpus_vce_divider_shortcode_params( $tag ) {
		return array(
			"name" => __( "Divider", "eut-corpus-vc-extension" ),
			"description" => __( "Insert dividers, just spaces or different lines", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-divider",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "dropdown",
					"heading" => __( "Line type", "eut-corpus-vc-extension" ),
					"param_name" => "line_type",
					"value" => array(
						__( "Line", "eut-corpus-vc-extension" ) => 'line',
						__( "Double Line", "eut-corpus-vc-extension" ) => 'double-line',
						__( "Dashed Line", "eut-corpus-vc-extension" ) => 'dashed-line',
						__( "Back to Top", "eut-corpus-vc-extension" ) => 'top-line',
					),
					"description" => '',
					"admin_label" => true,
				),
				array(
					"type" => "textfield",
					"heading" => __( "Back to Top Title", "eut-corpus-vc-extension" ),
					"param_name" => "backtotop_title",
					"value" => "Back to top",
					"description" => __( "Set Back to top title.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "line_type", 'value' => array( 'top-line' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Top padding", "eut-corpus-vc-extension" ),
					"param_name" => "padding_top",
					"description" => __( "You can use px, em, %, etc. or enter just number and it will use pixels.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Bottom padding", "eut-corpus-vc-extension" ),
					"param_name" => "padding_bottom",
					"description" => __( "You can use px, em, %, etc. or enter just number and it will use pixels.", "eut-corpus-vc-extension" ),
				),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_divider', 'eut_corpus_vce_divider_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_divider_shortcode_params( 'eut_divider' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
