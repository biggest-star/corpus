<?php
/**
 * Blog Shortcode
 */

if( !function_exists( 'eut_blog_shortcode' ) ) {

	function eut_blog_shortcode( $atts, $content ) {

		$output = $allow_filter = $el_class = $data_string = '';

		extract(
			shortcode_atts(
				array(
					'categories' => '',
					'exclude_posts' => '',
					'include_posts' => '',
					'blog_style' => 'large-media',
					'blog_mode' => 'no-shadow-mode',
					'blog_image_mode' => '',
					'blog_masonry_image_mode' => 'large',
					'blog_image_prio' => '',
					'columns' => '4',
					'columns_tablet_landscape' => '2',
					'columns_tablet_portrait' => '2',
					'columns_mobile' => '1',
					'auto_excerpt' => '',
					'excerpt_length' => '55',
					'excerpt_more' => '',
					'hide_comments' => '',
					'posts_per_page' => '10',
					'order_by' => 'date',
					'order' => 'DESC',
					'disable_pagination' => '',
					'blog_filter' => '',
					'blog_filter_align' => 'left',
					'filter_order_by' => '',
					'filter_order' => 'ASC',
					'item_spinner' => 'no',
					'items_per_page' => '4',
					'slideshow_speed' => '3000',
					'navigation_type' => '1',
					'navigation_color' => 'dark',
					'pause_hover' => 'no',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		$blog_classes = array( 'eut-element' );

		switch( $blog_style ) {

			case 'masonry':
				$data_string .= 'data-columns="' . esc_attr( $columns ) . '" data-columns-tablet-landscape="' . esc_attr( $columns_tablet_landscape ) . '" data-columns-tablet-portrait="' . esc_attr( $columns_tablet_portrait ) . '" data-columns-mobile="' . esc_attr( $columns_mobile ) . '" data-layout="masonry" data-spinner="' . esc_attr( $item_spinner ) . '"';
				break;
			case 'grid':
				$data_string .= 'data-columns="' . esc_attr( $columns ) . '" data-columns-tablet-landscape="' . esc_attr( $columns_tablet_landscape ) . '" data-columns-tablet-portrait="' . esc_attr( $columns_tablet_portrait ) . '" data-columns-mobile="' . esc_attr( $columns_mobile ) . '" data-layout="fitRows" data-spinner="' . esc_attr( $item_spinner ) . '"';
				break;
			case 'carousel':
				$disable_pagination = 'yes';
			break;
			case 'large-media':
			case 'small-media':
			default:
				break;
		}

		array_push( $blog_classes, eut_corpus_vce_get_blog_class( $blog_style ) );
		if ( !empty ( $el_class ) ) {
			array_push( $blog_classes, $el_class);
		}
		if ( 'shadow-mode' == $blog_mode && ( 'masonry' == $blog_style || 'grid' == $blog_style ) ) {
			array_push( $blog_classes, 'eut-shadow-mode' );
		} else {
			array_push( $blog_classes, 'eut-without-shadow' );
		}
		$blog_class_string = implode( ' ', $blog_classes );

		$paged = 1;

		if ( 'yes' != $disable_pagination ) {
			if ( get_query_var( 'paged' ) ) {
				$paged = get_query_var( 'paged' );
			} elseif ( get_query_var( 'page' ) ) {
				$paged = get_query_var( 'page' );
			}
		}

		$exclude_ids = array();
		if( !empty( $exclude_posts ) ){
			$exclude_ids = explode( ',', $exclude_posts );
		}

		$include_ids = array();
		if( !empty( $include_posts ) ){
			$include_ids = explode( ',', $include_posts );
			$args = array(
				'post_type' => 'post',
				'post_status'=>'publish',
				'posts_per_page' => $posts_per_page,
				'post__in' => $include_ids,
				'paged' => $paged,
				'ignore_sticky_posts' => 1,
				'orderby' => $order_by,
				'order' => $order,
			);
			$blog_filter = 'no';
		} else {
			$args = array(
				'post_type' => 'post',
				'post_status'=>'publish',
				'posts_per_page' => $posts_per_page,
				'post__not_in' => $exclude_ids,
				'cat' => $categories,
				'paged' => $paged,
				'ignore_sticky_posts' => 1,
				'orderby' => $order_by,
				'order' => $order,
			);
		}

		$query = new WP_Query( $args );

		$blog_category_ids = array();

		if( ! empty( $categories ) ) {
			$blog_category_ids = explode( ",", $categories );
		}
		if ( 'carousel' != $blog_style ) {
			$allow_filter = 'yes';
		}

		if ( 'masonry' == $blog_style ) {
			$blog_image_mode = $blog_masonry_image_mode;
		}



		$category_prefix = '.category-';

		ob_start();

		if ( $query->have_posts() ) :

?>
		<div class="<?php echo esc_attr( $blog_class_string ); ?>" style="<?php echo $style; ?>" <?php echo $data_string; ?>>
<?php
		//Category Filter
		if ( 'yes' == $blog_filter && 'yes' == $allow_filter ) {

			$category_filter_list = array();
			$category_filter_array = array();
			$all_string =  apply_filters( 'eut_vce_blog_string_all_categories', __( 'All', 'eut-corpus-vc-extension' ) );
			$category_filter_string = '<li data-filter="*" class="selected"><span>' . esc_html( $all_string ) . '</span></li>';
			$category_filter_add = false;
			while ( $query->have_posts() ) : $query->the_post();

				if ( $blog_categories = get_the_terms( get_the_ID(), 'category' ) ) {

					foreach($blog_categories as $category_term){
						$category_filter_add = false;
						if ( !in_array($category_term->term_id, $category_filter_list) ) {
							if( ! empty( $blog_category_ids ) ) {
								if ( in_array($category_term->term_id, $blog_category_ids) ) {
									$category_filter_add = true;
								}
							} else {
								$category_filter_add = true;
							}
							if ( $category_filter_add ) {
								$category_filter_list[] = $category_term->term_id;
								if ( 'title' == $filter_order_by ) {
									$category_filter_array[$category_term->name] = $category_term;
								} elseif ( 'slug' == $filter_order_by )  {
									$category_filter_array[$category_term->slug] = $category_term;
								} else {
									$category_filter_array[$category_term->term_id] = $category_term;
								}
							}
						}
					}
				}

			endwhile;


			if ( count( $category_filter_array ) > 1 ) {
				if ( '' != $filter_order_by ) {
					if ( 'ASC' == $filter_order ) {
						ksort( $category_filter_array );
					} else {
						krsort( $category_filter_array );
					}
				}
				foreach($category_filter_array as $category_filter){
					$term_class = sanitize_html_class( $category_filter->slug, $category_filter->term_id );
					if ( is_numeric( $term_class ) || ! trim( $term_class, '-' ) ) {
						$term_class = $category_filter->term_id;
					}
					$category_filter_string .= '<li data-filter="' . $category_prefix . $term_class . '"><span>' . $category_filter->name . '</span></li>';
				}
		?>
				<div class="eut-filter eut-align-<?php echo esc_attr( $blog_filter_align ); ?>">
					<ul>
						<?php echo $category_filter_string; ?>
					</ul>
				</div>
		<?php
			}
		}
		if ( 'large-media' == $blog_style || 'small-media' == $blog_style ) {
?>
			<div class="eut-standard-container">
<?php
		} else if ( 'carousel' == $blog_style ) {
			$data_string = ' data-items="' . esc_attr( $items_per_page ) . '" data-slider-speed="' . esc_attr( $slideshow_speed ) . '" data-slider-pause="' . esc_attr( $pause_hover ) . '"';
?>
			<?php if ( 0 != $navigation_type ) { ?>
			<div class="eut-carousel-navigation eut-<?php echo esc_attr( $navigation_color ); ?>" data-navigation-type="<?php echo esc_attr( $navigation_type ); ?>">
				<div class="eut-carousel-buttons">
					<div class="eut-carousel-prev eut-icon-nav-left"></div>
					<div class="eut-carousel-next eut-icon-nav-right"></div>
				</div>
			</div>
			<?php } ?>
			<div class="eut-carousel eut-blog eut-carousel-element eut-shadow-mode"<?php echo $data_string; ?>>
<?php
		} else {
?>
			<div class="eut-isotope-container">
<?php
		}

		$eut_isotope_start = $eut_isotope_end = '';
		if ( 'large-media' != $blog_style && 'small-media' != $blog_style ) {
			$eut_isotope_start = '<div class="eut-isotope-item-inner">';
			$eut_isotope_end = '</div>';
		}

		while ( $query->have_posts() ) : $query->the_post();

			$post_format = get_post_format();
			if ( 'link' == $post_format || 'quote' == $post_format ) {
				$eut_post_class = eut_corpus_vce_get_post_class( $blog_style, 'eut-label-post' );
			} else {
				$eut_post_class = eut_corpus_vce_get_post_class( $blog_style );
			}

			if ( 'carousel' == $blog_style ) {

?>
				<div class="eut-carousel-item">
					<article <?php post_class( 'eut-post-item' ); ?> itemscope itemType="http://schema.org/BlogPosting">
						<?php eut_corpus_vce_print_carousel_media(); ?>
						<div class="eut-post-content">
							<?php eut_corpus_vce_print_post_title( $blog_style, $post_format ); ?>
							<?php corpus_ext_vce_print_structured_data(); ?>
							<div class="eut-small-text eut-post-meta">
								<?php eut_corpus_vce_print_post_date(); ?>
							</div>
							<?php eut_corpus_vce_print_post_excerpt( $blog_style, $post_format, $auto_excerpt, $excerpt_length, $excerpt_more ); ?>
						</div>
					</article>
				</div>
<?php
			} else {
?>
			<article id="post-<?php the_ID(); ?>" <?php post_class( $eut_post_class ); ?> itemscope itemType="http://schema.org/BlogPosting">
				<?php echo $eut_isotope_start; ?>
					<?php eut_corpus_vce_print_post_feature_media( $blog_style, $post_format, $blog_image_mode, $blog_image_prio ); ?>

					<?php if ( 'link' != $post_format && 'quote' != $post_format ) { ?>
						<div class="eut-post-content">
							<?php eut_corpus_vce_print_post_title( $blog_style, $post_format ); ?>
							<?php corpus_ext_vce_print_structured_data(); ?>
							<div class="eut-small-text eut-post-meta">
								<?php eut_corpus_vce_print_post_author_by( $blog_style ); ?>
								<?php eut_corpus_vce_print_post_date(); ?>
								<?php
									if( function_exists( 'eut_print_like_counter' ) ) {
										eut_print_like_counter();
									}
								?>
							</div>
							<?php eut_corpus_vce_print_post_excerpt( $blog_style, $post_format, $auto_excerpt, $excerpt_length, $excerpt_more ); ?>
						</div>
					<?php } else { ?>
						<?php eut_corpus_vce_print_post_title( $blog_style, $post_format ); ?>
						<?php corpus_ext_vce_print_structured_data(); ?>
					<?php }?>

				<?php echo $eut_isotope_end; ?>
			</article>

<?php
			}

		endwhile;
?>
			</div>
<?php
			if ( 'yes' != $disable_pagination ) {
				$total = $query->max_num_pages;
				$big = 999999999; // need an unlikely integer
				if( $total > 1 )  {
					 echo '<div class="eut-pagination">';

					 if( get_option('permalink_structure') ) {
						 $format = 'page/%#%/';
					 } else {
						 $format = '&paged=%#%';
					 }
					 echo paginate_links(array(
						'base'			=> str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
						'format'		=> $format,
						'current'		=> max( 1, $paged ),
						'total'			=> $total,
						'mid_size'		=> 2,
						'type'			=> 'list',
						'prev_text'	=> '<i class="eut-icon-nav-left"></i>',
						'next_text'	=> '<i class="eut-icon-nav-right"></i>',
						'add_args' => false,
					 ));
					 echo '</div>';
				}
			}
?>
		</div>
<?php
		else :
		endif;

		wp_reset_postdata();

		return ob_get_clean();


	}
	add_shortcode( 'eut_blog', 'eut_blog_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_blog_shortcode_params' ) ) {
	function eut_corpus_vce_blog_shortcode_params( $tag ) {
		return array(
			"name" => __( "Blog", "eut-corpus-vc-extension" ),
			"description" => __( "Display a Blog element in multiple styles", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-blog",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "dropdown",
					"heading" => __( "Style", "eut-corpus-vc-extension" ),
					"param_name" => "blog_style",
					"admin_label" => true,
					'value' => array(
						__( 'Large Media', 'eut-corpus-vc-extension' ) => 'large-media',
						__( 'Small Media', 'eut-corpus-vc-extension' ) => 'small-media',
						__( 'Masonry' , 'eut-corpus-vc-extension' ) => 'masonry',
						__( 'Grid' , 'eut-corpus-vc-extension' ) => 'grid',
						__( 'Carousel' , 'eut-corpus-vc-extension' ) => 'carousel',
					),
					"description" => __( "Select your Blog Style.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Mode", "eut-corpus-vc-extension" ),
					"param_name" => "blog_mode",
					"admin_label" => true,
					'value' => array(
						__( 'Without Shadow', 'eut-corpus-vc-extension' ) => 'no-shadow-mode',
						__( 'With Shadow', 'eut-corpus-vc-extension' ) => 'shadow-mode',
					),
					"description" => __( "Select your Blog Mode.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Image Mode", "eut-corpus-vc-extension" ),
					"param_name" => "blog_image_mode",
					'value' => array(
						__( 'Auto Crop', 'eut-corpus-vc-extension' ) => '',
						__( 'Resize', 'eut-corpus-vc-extension' ) => 'resize',
						__( 'Resize ( Large )', 'eut-corpus-vc-extension' ) => 'large',
						__( 'Resize ( Medium Large )', 'eut-corpus-vc-extension' ) => 'medium_large',
						__( 'Resize ( Medium )', 'eut-corpus-vc-extension' ) => 'medium',
					),
					"description" => __( "Select your Blog Image Mode.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'large-media', 'small-media', 'grid' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Masonry Image Mode", "eut-corpus-vc-extension" ),
					"param_name" => "blog_masonry_image_mode",
					'value' => array(
						__( 'Resize ( Large )', 'eut-corpus-vc-extension' ) => 'large',
						__( 'Resize ( Medium Large )', 'eut-corpus-vc-extension' ) => 'medium_large',
						__( 'Resize ( Medium )', 'eut-corpus-vc-extension' ) => 'medium',
					),
					"description" => __( "Select your Blog Masonry Image Mode.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'masonry' ) ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Featured Image Priority", "eut-corpus-vc-extension" ),
					"param_name" => "blog_image_prio",
					"description" => __( "Featured image is displayed instead of media element", "eut-corpus-vc-extension" ),
					"value" => Array( __( "Featured Image Priority", "eut-corpus-vc-extension" ) => 'yes' ),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'large-media', 'small-media','grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Columns", "eut-corpus-vc-extension" ),
					"param_name" => "columns",
					"value" => array( '2', '3', '4', '5' ),
					"std" => '4',
					"description" => __( "Select your Blog Columns.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Tablet Landscape Columns", "eut-corpus-vc-extension" ),
					"param_name" => "columns_tablet_landscape",
					"value" => array( '2', '3', '4', '5' ),
					"std" => '2',
					"description" => __( "Select responsive column on tablet devices, landscape orientation.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Tablet Portrait Columns", "eut-corpus-vc-extension" ),
					"param_name" => "columns_tablet_portrait",
					"value" => array( '2', '3', '4', '5' ),
					"std" => '2',
					"description" => __( "Select responsive column on tablet devices, portrait orientation.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Mobile Columns", "eut-corpus-vc-extension" ),
					"param_name" => "columns_mobile",
					"value" => array( '1', '2' ),
					"std" => '1',
					"description" => __( "Select responsive column on mobile devices.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Auto excerpt", "eut-corpus-vc-extension" ),
					"param_name" => "auto_excerpt",
					"description" => __( "Adds automatic excerpt to all posts in Large Media style. If auto excerpt is not selected, blog will show all content, a desired 'cut-off' point can be inserted in each post with more quicktag.", "eut-corpus-vc-extension" ),
					"value" => Array( __( "Activate auto excerpt.", "eut-corpus-vc-extension" ) => 'yes' ),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'large-media' ) ),
				),
				array(
					"type" => 'textfield',
					"heading" => __( "Excerpt length", "eut-corpus-vc-extension" ),
					"param_name" => "excerpt_length",
					"description" => __( "Type how many words you want to display in your post excerpts.", "eut-corpus-vc-extension" ),
					"value" => '55',
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'large-media', 'small-media','grid', 'masonry', 'carousel' ) ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Read more", "eut-corpus-vc-extension" ),
					"param_name" => "excerpt_more",
					"description" => __( "Adds a read more button after the excerpt or more quicktag", "eut-corpus-vc-extension" ),
					"value" => Array( __( "Add more button", "eut-corpus-vc-extension" ) => 'yes' ),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'large-media', 'small-media','grid', 'masonry' ) ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Filter", "eut-corpus-vc-extension" ),
					"param_name" => "blog_filter",
					"description" => __( "If selected, an isotope filter will be displayed.", "eut-corpus-vc-extension" ),
					"value" => Array( __( "Enable Blog Filter ( Only for All or Multiple Categories )", "eut-corpus-vc-extension" ) => 'yes' ),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'large-media', 'small-media','grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Filter Order By", "eut-corpus-vc-extension" ),
					"param_name" => "filter_order_by",
					"value" => array(
						__( "Default ( Unordered )", "eut-corpus-vc-extension" ) => '',
						__( "ID", "eut-corpus-vc-extension" ) => 'id',
						__( "Slug", "eut-corpus-vc-extension" ) => 'slug',
						__( "Title", "eut-corpus-vc-extension" ) => 'title',
					),
					"description" => '',
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'large-media', 'small-media','grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Filter Order", "eut-corpus-vc-extension" ),
					"param_name" => "filter_order",
					"value" => array(
						__( "Ascending", "eut-corpus-vc-extension" ) => 'ASC',
						__( "Descending", "eut-corpus-vc-extension" ) => 'DESC',
					),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'large-media', 'small-media','grid', 'masonry' ) ),
					"description" => '',
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Filter Alignment", "eut-corpus-vc-extension" ),
					"param_name" => "blog_filter_align",
					"value" => array(
						__( "Left", "eut-corpus-vc-extension" ) => 'left',
						__( "Right", "eut-corpus-vc-extension" ) => 'right',
						__( "Center", "eut-corpus-vc-extension" ) => 'center',
					),
					"description" => '',
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'large-media', 'small-media','grid', 'masonry' ) ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Enable Loader", "eut-corpus-vc-extension" ),
					"param_name" => "item_spinner",
					"description" => __( "If selected, this will enable a graphic spinner before load.", "eut-corpus-vc-extension" ),
					"value" => Array( __( "Enable Loader.", "eut-corpus-vc-extension" ) => 'yes' ),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Disable Pagination", "eut-corpus-vc-extension" ),
					"param_name" => "disable_pagination",
					"description" => __( "If selected, pagination will not be shown.", "eut-corpus-vc-extension" ),
					"value" => Array( __( "Disable Pagination.", "eut-corpus-vc-extension" ) => 'yes' ),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'large-media', 'small-media','grid', 'masonry' ) ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Hide Comments", "eut-corpus-vc-extension" ),
					"param_name" => "hide_comments",
					"description" => __( "If selected, blog overview will not show comments.", "eut-corpus-vc-extension" ),
					"value" => Array( __( "Hide Comments.", "eut-corpus-vc-extension" ) => 'yes' ),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'large-media', 'small-media','grid', 'masonry' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Posts per Page", "eut-corpus-vc-extension" ),
					"param_name" => "posts_per_page",
					"value" => "10",
					"description" => __( "Enter how many posts per page you want to display.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				//Gallery ( carousel )
				array(
					"type" => "dropdown",
					"heading" => __( "Items per page", "eut-corpus-vc-extension" ),
					"param_name" => "items_per_page",
					"value" => array( '3', '4', '5' ),
					"description" => __( "Number of items per page", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'carousel' ) ),
					"std" => "4",
				),
				array(
					"type" => "textfield",
					"heading" => __( "Slideshow Speed", "eut-corpus-vc-extension" ),
					"param_name" => "slideshow_speed",
					"value" => '3000',
					"description" => __( "Slideshow Speed in ms.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'carousel' ) ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Pause on Hover", "eut-corpus-vc-extension" ),
					"param_name" => "pause_hover",
					"value" => Array( __( "If selected, carousel will be paused on hover", "eut-corpus-vc-extension" ) => 'yes' ),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'carousel' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Navigation Type", "eut-corpus-vc-extension" ),
					"param_name" => "navigation_type",
					'value' => array(
						__( 'Style 1' , 'eut-corpus-vc-extension' ) => '1',
						__( 'Style 2' , 'eut-corpus-vc-extension' ) => '2',
						__( 'Style 3' , 'eut-corpus-vc-extension' ) => '3',
						__( 'Style 4' , 'eut-corpus-vc-extension' ) => '4',
						__( 'No Navigation' , 'eut-corpus-vc-extension' ) => '0',
					),
					"description" => __( "Select your Navigation type.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'carousel' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Navigation Color", "eut-corpus-vc-extension" ),
					"param_name" => "navigation_color",
					'value' => array(
						__( 'Dark' , 'eut-corpus-vc-extension' ) => 'dark',
						__( 'Light' , 'eut-corpus-vc-extension' ) => 'light',
					),
					"description" => __( "Select the background Navigation color.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "blog_style", 'value' => array( 'carousel' ) ),
				),
				eut_vce_add_order_by(),
				eut_vce_add_order(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
				array(
					"type" => "textfield",
					"heading" => __("Exclude Posts", "eut-corpus-vc-extension" ),
					"param_name" => "exclude_posts",
					"value" => '',
					"description" => __( "Type the post ids you want to exclude separated by comma ( , ).", "eut-corpus-vc-extension" ),
					"group" => __( "Categories", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "eut_multi_checkbox",
					"heading" => __("Categories", "eut-corpus-vc-extension" ),
					"param_name" => "categories",
					"value" => eut_corpus_vce_get_post_categories(),
					"description" => __( "Select all or multiple categories.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
					"group" => __( "Categories", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __("Include Specific Posts", "eut-corpus-vc-extension" ),
					"param_name" => "include_posts",
					"value" => '',
					"description" => __( "Type the specific post ids you want to include separated by comma ( , ). Note: If you define specific post ids, Exclude Posts and Categories will have no effect.", "eut-corpus-vc-extension" ),
					"group" => __( "Categories", "eut-corpus-vc-extension" ),
				),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_blog', 'eut_corpus_vce_blog_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_blog_shortcode_params( 'eut_blog' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
