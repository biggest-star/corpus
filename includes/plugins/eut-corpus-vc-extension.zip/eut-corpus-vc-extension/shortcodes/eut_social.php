<?php
/**
 * Social Shortcode
 */

if( !function_exists( 'eut_corpus_social_shortcode' ) ) {

	function eut_corpus_social_shortcode( $atts, $content ) {

		$output = $data = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'social_facebook' => '',
					'social_twitter' => '',
					'social_linkedin' => '',
					'social_googleplus' => '',
					'social_reddit' => '',
					'eut_likes' => '',
					'animation' => '',
					'align' => 'left',
					'shape_color' => 'primary-1',
					'icon_size' => 'medium',
					'icon_shape' => 'square',
					'shape_type' => 'simple',
					'animation_delay' => '200',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		if ( !empty( $animation ) ) {
			$animation = 'eut-' . $animation;
		}


		$social_classes = array( 'eut-element', 'eut-social', 'eut-align-' . $align );

		if ( !empty( $animation ) ) {
			array_push( $social_classes, 'eut-animated-item' );
			array_push( $social_classes, $animation);
			$data = ' data-delay="' . esc_attr( $animation_delay ) . '"';
		}
		if ( !empty( $el_class ) ) {
			array_push( $social_classes, $el_class);
		}
		$social_class_string = implode( ' ', $social_classes );

		$social_shape_classes = array();

		array_push( $social_shape_classes, 'eut-' . $icon_size );
		array_push( $social_shape_classes, 'eut-' . $icon_shape );
		array_push( $social_shape_classes, 'eut-' . $shape_type );
		array_push( $social_shape_classes, 'eut-bg-' . $shape_color );

		$social_shape_class_string = implode( ' ', $social_shape_classes );

		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		$eut_permalink = esc_url( get_permalink() );
		$eut_title = esc_attr( get_the_title() );

		ob_start();

		?>
			<div class="<?php echo esc_attr( $social_class_string ); ?>" style="<?php echo $style; ?>"<?php echo $data; ?>>
				<ul>

					<?php if ( !empty( $social_facebook ) ) { ?>
					<li><a href="<?php echo $eut_permalink; ?>" title="<?php echo $eut_title; ?>" class="<?php echo esc_attr( $social_shape_class_string ); ?> eut-social-share-facebook"><i class="fa fa-facebook"></i></a></li>
					<?php } ?>
					<?php if ( !empty( $social_twitter ) ) { ?>
					<li><a href="<?php echo $eut_permalink; ?>" title="<?php echo $eut_title; ?>" class="<?php echo esc_attr( $social_shape_class_string ); ?> eut-social-share-twitter"><i class="fa fa-twitter"></i></a></li>
					<?php } ?>
					<?php if ( !empty( $social_linkedin ) ) { ?>
					<li><a href="<?php echo $eut_permalink; ?>" title="<?php echo $eut_title; ?>" class="<?php echo esc_attr( $social_shape_class_string ); ?> eut-social-share-linkedin"><i class="fa fa-linkedin"></i></a></li>
					<?php } ?>
					<?php if ( !empty( $social_googleplus ) ) { ?>
					<li><a href="<?php echo $eut_permalink; ?>" title="<?php echo $eut_title; ?>" class="<?php echo esc_attr( $social_shape_class_string ); ?> eut-social-share-googleplus"><i class="fa fa-google-plus"></i></a></li>
					<?php } ?>
					<?php if ( !empty( $social_reddit ) ) { ?>
					<li><a href="<?php echo $eut_permalink; ?>" title="<?php echo $eut_title; ?>" class="<?php echo esc_attr( $social_shape_class_string ); ?> eut-social-share-reddit"><i class="fa fa-reddit"></i></a></li>
					<?php } ?>

					<?php if ( !empty( $eut_likes ) && function_exists( 'eut_likes' ) ) {
						global $post;
						$post_id = $post->ID;
					?>
					<li><a href="#" class="<?php echo esc_attr( $social_shape_class_string ); ?> eut-like-counter-link" data-post-id="<?php echo $post_id; ?>"><i class="fa fa-heart"></i><span class="eut-like-counter"><?php echo eut_likes( $post_id ); ?></span></a></li>
					<?php } ?>

				</ul>
			</div>
		<?php

		return ob_get_clean();

	}
	add_shortcode( 'eut_social', 'eut_corpus_social_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_social_shortcode_params' ) ) {
	function eut_corpus_vce_social_shortcode_params( $tag ) {
		return array(
			"name" => __( "Social", "eut-corpus-vc-extension" ),
			"description" => __( "Place your preferred social", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-social",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => 'checkbox',
					"heading" => __( "Facebook", "eut-corpus-vc-extension" ),
					"param_name" => "social_facebook",
					"description" => __( "Share in Facebook", "eut-corpus-vc-extension" ),
					"value" => Array( __( "Show Facebook social share", "eut-corpus-vc-extension" ) => 'yes' ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Twitter", "eut-corpus-vc-extension" ),
					"param_name" => "social_twitter",
					"description" => __( "Share in Twitter", "eut-corpus-vc-extension" ),
					"value" => Array( __( "Show Twitter social share", "eut-corpus-vc-extension" ) => 'yes' ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Linkedin", "eut-corpus-vc-extension" ),
					"param_name" => "social_linkedin",
					"description" => __( "Share in Linkedin", "eut-corpus-vc-extension" ),
					"value" => Array( __( "Show Linkedin social share", "eut-corpus-vc-extension" ) => 'yes' ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Google +", "eut-corpus-vc-extension" ),
					"param_name" => "social_googleplus",
					"description" => __( "Share in Google +", "eut-corpus-vc-extension" ),
					"value" => Array( __( "Show Google + social share", "eut-corpus-vc-extension" ) => 'yes' ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "reddit", "eut-corpus-vc-extension" ),
					"param_name" => "social_reddit",
					"description" => __( "Submit in reddit", "eut-corpus-vc-extension" ),
					"value" => Array( __( "Show reddit social share", "eut-corpus-vc-extension" ) => 'yes' ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "(Euthemians) Likes", "eut-corpus-vc-extension" ),
					"param_name" => "eut_likes",
					"description" => __( "(Euthemians) Likes", "eut-corpus-vc-extension" ),
					"value" => Array( __( "Show (Euthemians) Likes", "eut-corpus-vc-extension" ) => 'yes' ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Icon size", "eut-corpus-vc-extension" ),
					"param_name" => "icon_size",
					"value" => array(
						__( "Large", "eut-corpus-vc-extension" ) => 'large',
						__( "Medium", "eut-corpus-vc-extension" ) => 'medium',
						__( "Small", "eut-corpus-vc-extension" ) => 'small',
					),
					"std" => 'medium',
					"description" => '',
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Shape Color", "eut-corpus-vc-extension" ),
					"param_name" => "shape_color",
					"value" => array(
						__( "Primary 1", "eut-corpus-vc-extension" ) => 'primary-1',
						__( "Primary 2", "eut-corpus-vc-extension" ) => 'primary-2',
						__( "Primary 3", "eut-corpus-vc-extension" ) => 'primary-3',
						__( "Primary 4", "eut-corpus-vc-extension" ) => 'primary-4',
						__( "Primary 5", "eut-corpus-vc-extension" ) => 'primary-5',
					),
					"description" => __( "Color of the shape.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Icon shape", "eut-corpus-vc-extension" ),
					"param_name" => "icon_shape",
					"value" => array(
						__( "Square", "eut-corpus-vc-extension" ) => 'square',
						__( "Round", "eut-corpus-vc-extension" ) => 'round',
						__( "Circle", "eut-corpus-vc-extension" ) => 'circle',
					),
					"description" => '',
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Shape type", "eut-corpus-vc-extension" ),
					"param_name" => "shape_type",
					"value" => array(
						__( "Simple", "eut-corpus-vc-extension" ) => 'simple',
						__( "Outline", "eut-corpus-vc-extension" ) => 'outline',
					),
					"description" => __( "Select shape type.", "eut-corpus-vc-extension" ),
				),
				eut_vce_add_align(),
				eut_vce_add_animation(),
				eut_vce_add_animation_delay(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_social', 'eut_corpus_vce_social_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_social_shortcode_params( 'eut_social' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
