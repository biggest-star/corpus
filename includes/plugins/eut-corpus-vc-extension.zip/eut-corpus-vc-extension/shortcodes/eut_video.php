<?php
/**
 * Video Shortcode
 */

if( !function_exists( 'eut_video_shortcode' ) ) {

	function eut_video_shortcode( $atts, $content ) {
		global $wp_embed;
		$output = $class_fullwidth = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'video_link' => '',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		$video_classes = array( 'eut-element', 'eut-video' );

		if ( !empty( $el_class ) ) {
			array_push( $video_classes, $el_class);
		}
		$video_class_string = implode( ' ', $video_classes );


		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		if ( !empty( $video_link ) ) {
			$output .= '<div class="' . esc_attr( $video_class_string ) . '" style="' . $style . '">';
			$output .= $wp_embed->run_shortcode( '[embed]' . $video_link . '[/embed]' );
			$output .= '</div>';
		}

		return $output;
	}
	add_shortcode( 'eut_video', 'eut_video_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_video_shortcode_params' ) ) {
	function eut_corpus_vce_video_shortcode_params( $tag ) {
		return array(
			"name" => __( "Video", "eut-corpus-vc-extension" ),
			"description" => __( "Embed YouTube/Vimeo player", "eut-corpus-vc-extension" ),
			"base" => $tag ,
			"class" => "",
			"icon"      => "icon-wpb-eut-video",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "textfield",
					"heading" => __( "Video Link", "eut-corpus-vc-extension" ),
					"param_name" => "video_link",
					"value" => "",
					"description" => __( "Type Vimeo/YouTube URL.", "eut-corpus-vc-extension" ),
				),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			)
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_video', 'eut_corpus_vce_video_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_video_shortcode_params( 'eut_video' );
	vc_map( $attributes );
}

?>