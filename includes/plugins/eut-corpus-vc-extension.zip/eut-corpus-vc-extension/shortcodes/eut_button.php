<?php
/**
 * Button Shortcode
 */

if( !function_exists( 'eut_button_shortcode' ) ) {

	function eut_button_shortcode( $atts, $content ) {

		$output = $data = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'button_text' => 'Button',
					'button_link' => '',
					'button_type' => 'simple',
					'button_size' => 'medium',
					'button_color' => 'primary-1',
					'button_shape' => 'square',
					'button_class' => '',
					'animation' => '',
					'animation_delay' => '200',
					'align' => 'left',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		if ( !empty( $animation ) ) {
			$animation = 'eut-' . $animation;
		}

		$button_classes = array( 'eut-element', 'eut-align-' . $align );

		if ( !empty( $animation ) ) {
			array_push( $button_classes, 'eut-animated-item' );
			array_push( $button_classes, $animation);
			$data = ' data-delay="' . esc_attr( $animation_delay ) . '"';
		}
		if ( !empty( $el_class ) ) {
			array_push( $button_classes, $el_class);
		}
		$button_class_string = implode( ' ', $button_classes );

		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );
		$button = eut_corpus_vce_get_button( $button_text, $button_link, $button_type, $button_size, $button_color, $button_shape, $button_class, $style );

		$output .= '<div class="' . $button_class_string . '"' . $data . '>';
		$output .= $button;
		$output .= '</div>';

		return $output;
	}
	add_shortcode( 'eut_button', 'eut_button_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_button_shortcode_params' ) ) {
	function eut_corpus_vce_button_shortcode_params( $tag ) {
		return array(
			"name" => __( "Button", "eut-corpus-vc-extension" ),
			"description" => __( "Several styles, sizes and colors for your buttons", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-button",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				eut_vce_add_button_type(),
				eut_vce_add_button_color(),
				eut_vce_add_button_text(),
				eut_vce_add_button_size(),
				eut_vce_add_button_shape(),
				eut_vce_add_button_link(),
				eut_vce_add_button_class(),
				eut_vce_add_align(),
				eut_vce_add_animation(),
				eut_vce_add_animation_delay(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_button', 'eut_corpus_vce_button_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_button_shortcode_params( 'eut_button' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
