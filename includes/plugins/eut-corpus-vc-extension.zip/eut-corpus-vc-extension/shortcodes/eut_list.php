<?php
/**
 * List Shortcode
 */

if( !function_exists( 'eut_list_shortcode' ) ) {

	function eut_list_shortcode( $atts, $content ) {

		$el_class = '';

		extract(
			shortcode_atts(
				array(
					'icon' => 'check',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );
		$content = wpautop(preg_replace('/<\/?p\>/', "\n", $content)."\n");
		return '<div class="eut-element eut-list eut-list-' . esc_attr( $icon ) . ' ' . esc_attr( $el_class ) . '" style="' . $style . '">' . $content . '</div>';
	}
	add_shortcode( 'eut_list', 'eut_list_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_list_shortcode_params' ) ) {
	function eut_corpus_vce_list_shortcode_params( $tag ) {
		return array(
			"name" => __( "List", "eut-corpus-vc-extension" ),
			"description" => __( "Select among several different styles", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-list",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "eut_icon",
					"heading" => __( "Icon", "eut-corpus-vc-extension" ),
					"param_name" => "icon",
					"param_subset" => "list",
					"value" => 'check',
					"description" => __( "Select an icon.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type"			=> "textarea_html",
					"heading"		=> __( "List", "eut-corpus-vc-extension" ),
					"param_name"	=> "content",
					"value"			=> "<ul><li>List 1</li><li>List 2</li><li>List 3</li><li>List 4</li></ul>",
					"description"	=> __( "Insert your unordered list here.", "eut-corpus-vc-extension" ),
				),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_list', 'eut_corpus_vce_list_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_list_shortcode_params( 'eut_list' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
