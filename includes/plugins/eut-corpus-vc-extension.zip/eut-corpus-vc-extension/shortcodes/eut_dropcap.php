<?php
/**
 * Dropcap Shortcode
 */

if( !function_exists( 'eut_dropcap_shortcode' ) ) {

	function eut_dropcap_shortcode( $atts, $content ) {

		$output = $style = $data = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'dropcap_style' => '1',
					'bg_color' => 'primary-1',
					'animation' => '',
					'animation_delay' => '200',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		if ( !empty( $animation ) ) {
			$animation = 'eut-' . $animation;
		}


		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		$dropcap_classes = array( 'eut-element', 'eut-dropcap' );

		if ( !empty( $animation ) ) {
			array_push( $dropcap_classes, 'eut-animated-item' );
			array_push( $dropcap_classes, $animation);
			$data = ' data-delay="' . esc_attr( $animation_delay ) . '"';
		}

		if ( !empty ( $el_class ) ) {
			array_push( $dropcap_classes, $el_class);
		}
		$dropcap_class_string = implode( ' ', $dropcap_classes );

		if ( !empty( $content ) ) {

			$dropcap_char = mb_substr( $content, 0, 1, 'UTF8' );
			$dropcap_content = mb_substr( $content, 1, mb_strlen( $content ) , 'UTF8' );
			$output .= '<div class="' . esc_attr( $dropcap_class_string ) . '" style="' . $style . '"' . $data .'>';
			$output .= '<p><span class="eut-style-' . esc_attr( $dropcap_style ) . ' eut-bg-' . esc_attr( $bg_color ) . '">' . $dropcap_char . '</span>' . $dropcap_content . '</p>';
			$output .= '</div>';

		}


		return $output;
	}
	add_shortcode( 'eut_dropcap', 'eut_dropcap_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_dropcap_shortcode_params' ) ) {
	function eut_corpus_vce_dropcap_shortcode_params( $tag ) {
		return array(
			"name" => __( "Dropcap", "eut-corpus-vc-extension" ),
			"description" => __( "Two separate styles for your dropcaps", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-dropcap",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "dropdown",
					"heading" => __( "Style", "eut-corpus-vc-extension" ),
					"param_name" => "dropcap_style",
					"value" => array(
						__( "Style 1", "eut-corpus-vc-extension" ) => '1',
						__( "Style 2", "eut-corpus-vc-extension" ) => '2',
					),
					"description" => __( "Style of the dropcap.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textarea",
					"heading" => __( "Text", "eut-corpus-vc-extension" ),
					"param_name" => "content",
					"value" => "Sample Text",
					"description" => __( "Type your dropcap text.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Dropcap Color", "eut-corpus-vc-extension" ),
					"param_name" => "bg_color",
					"value" => array(
						__( "Primary 1", "eut-corpus-vc-extension" ) => 'primary-1',
						__( "Primary 2", "eut-corpus-vc-extension" ) => 'primary-2',
						__( "Primary 3", "eut-corpus-vc-extension" ) => 'primary-3',
						__( "Primary 4", "eut-corpus-vc-extension" ) => 'primary-4',
						__( "Primary 5", "eut-corpus-vc-extension" ) => 'primary-5',
						__( "Green", "eut-corpus-vc-extension" ) => 'green',
						__( "Orange", "eut-corpus-vc-extension" ) => 'orange',
						__( "Red", "eut-corpus-vc-extension" ) => 'red',
						__( "Blue", "eut-corpus-vc-extension" ) => 'blue',
						__( "Aqua", "eut-corpus-vc-extension" ) => 'aqua',
						__( "Purple", "eut-corpus-vc-extension" ) => 'purple',
						__( "Black", "eut-corpus-vc-extension" ) => 'black',
						__( "Grey", "eut-corpus-vc-extension" ) => 'grey',
					),
					"description" => __( "First character background color", "eut-corpus-vc-extension" ),
				),
				eut_vce_add_animation(),
				eut_vce_add_animation_delay(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_dropcap', 'eut_corpus_vce_dropcap_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_dropcap_shortcode_params( 'eut_dropcap' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
