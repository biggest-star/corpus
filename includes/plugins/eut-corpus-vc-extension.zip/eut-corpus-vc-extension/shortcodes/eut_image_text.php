<?php
/**
 * Image Text Shortcode
 */

if( !function_exists( 'eut_image_text_shortcode' ) ) {

	function eut_image_text_shortcode( $atts, $content ) {

		$output = $output_image = $data = $retina_data = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'title' => '',
					'heading' => 'h3',
					'image' => '',
					'retina_image' => '',
					'image_align' => 'left',
					'video_popup' => '',
					'video_link' => '',
					'read_more_title' => '',
					'read_more_link' => '',
					'read_more_class' => '',
					'animation' => '',
					'animation_delay' => '200',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		if ( !empty( $animation ) ) {
			$animation = 'eut-' . $animation;
		}

		if ( !empty( $read_more_link ) ){
			$href = vc_build_link( $read_more_link );
			$url = $href['url'];
			if ( !empty( $href['target'] ) ){
				$target = $href['target'];
			} else {
				$target = "_self";
			}
		} else {
			$url = "#";
			$target = "_self";
		}
		$target = trim( $target );

		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		$image_text_classes = array( 'eut-element', 'eut-image-text' );

		if ( !empty( $animation ) ) {
			array_push( $image_text_classes, 'eut-animated-item' );
			array_push( $image_text_classes, $animation);
			$data = ' data-delay="' . esc_attr( $animation_delay ) . '"';
		}
		if ( !empty( $el_class ) ) {
			array_push( $image_text_classes, $el_class);
		}
		$image_text_class_string = implode( ' ', $image_text_classes );


		$output .= '<div class="' . esc_attr( $image_text_class_string ) . '" style="' . $style . '"' . $data . '>';
		if ( !empty( $image ) ) {
			$img_id = preg_replace('/[^\d]/', '', $image);
			$img_src = wp_get_attachment_image_src( $img_id, 'full' );
			$img_url = $img_src[0];
			$image_srcset = '';
			if ( !empty( $retina_image ) ) {
				$img_retina_id = preg_replace('/[^\d]/', '', $retina_image);
				$img_retina_src = wp_get_attachment_image_src( $img_retina_id, 'full' );
				$retina_url = $img_retina_src[0];
				$image_srcset = esc_url( $img_url ) . ' 1x,' . esc_url( $retina_url ) . ' 2x';
				$image_html = wp_get_attachment_image( $img_id, 'full' , '', array( 'srcset'=> $image_srcset ) );
			} else {
				$image_html = wp_get_attachment_image( $img_id, 'full' );
			}


			if ( 'yes' == $video_popup && !empty( $video_link ) ) {
				$output_image .= '<div class="eut-image">';
				$output_image .= '	<a class="eut-vimeo-popup eut-icon-video" href="' . esc_url( $video_link ) . '">';
				$output_image .= $image_html;
				$output_image .= '	</a>';
				$output_image .= '</div>';
			} else {
				$output_image .= '<div class="eut-image">';
				$output_image .= $image_html;
				$output_image .= '</div>';
			}


			if ( 'left' == $image_align ) {
				$output .= $output_image;
			}

			$output .= '  <div class="eut-content eut-align-' . esc_attr( $image_align ) . '">';
			if ( !empty( $title ) ) {
			$output .= '<' . $heading . '>' . $title. '</' . $heading . '>';
			}
			if ( !empty( $content ) ) {
			$output .= '  <p>' . do_shortcode( $content ) . '</p>';
			}
			if ( !empty( $read_more_title ) && !empty( $url ) ) {
				$output .= '    <a href="' . esc_url( $url ) . '" target="' . $target . '" class="eut-read-more ' . esc_attr( $read_more_class ) . '">';
				$output .=  $read_more_title ;
				$output .= '</a>';
			}
			$output .= '  </div>';


			if ( 'right' == $image_align ) {
				$output .= $output_image;
			}

		}
		$output .= '</div>';


		return $output;
	}
	add_shortcode( 'eut_image_text', 'eut_image_text_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_image_text_shortcode_params' ) ) {
	function eut_corpus_vce_image_text_shortcode_params( $tag ) {
		return array(
			"name" => __( "Image Text", "eut-corpus-vc-extension" ),
			"description" => __( "Combine image or video with text and button", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-image-text",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "attach_image",
					"heading" => __( "Image", "eut-corpus-vc-extension" ),
					"param_name" => "image",
					"value" => '',
					"description" => __( "Select an image.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "attach_image",
					"heading" => __( "Retina Image", "eut-corpus-vc-extension" ),
					"param_name" => "retina_image",
					"value" => '',
					"description" => __( "Select a 2x image.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => 'dropdown',
					"heading" => __( "Image align", "eut-corpus-vc-extension" ),
					"param_name" => "image_align",
					"description" => __( "Set the alignment of your image", "eut-corpus-vc-extension" ),
					"value" => array(
						__( "Left", "eut-corpus-vc-extension" ) => 'left',
						__( "Right", "eut-corpus-vc-extension" ) => 'right',
					),
				),
				array(
					"type" => 'dropdown',
					"heading" => __( "Video popup", "eut-corpus-vc-extension" ),
					"param_name" => "video_popup",
					"description" => __( "If selected, a video popup will be appear on click.", "eut-corpus-vc-extension" ),
					"value" => array(
						__( "No", "eut-corpus-vc-extension" ) => '',
						__( "Yes", "eut-corpus-vc-extension" ) => 'yes',
					),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Video Link", "eut-corpus-vc-extension" ),
					"param_name" => "video_link",
					"value" => "",
					"description" => __( "Type video URL e.g Vimeo/YouTube.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "video_popup", 'not_empty' => true ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Title", "eut-corpus-vc-extension" ),
					"param_name" => "title",
					"value" => "",
					"description" => __( "Enter your title.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Heading", "eut-corpus-vc-extension" ),
					"param_name" => "heading",
					"admin_label" => true,
					"value" => array( 'h1', 'h2', 'h3', 'h4' , 'h5', 'h6' ),
					"description" => __( "Heading size", "eut-corpus-vc-extension" ),
					"std" => 'h3',
				),
				array(
					"type" => "textarea",
					"heading" => __( "Text", "eut-corpus-vc-extension" ),
					"param_name" => "content",
					"value" => "",
					"description" => __( "Enter your text.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Read More Title", "eut-corpus-vc-extension" ),
					"param_name" => "read_more_title",
					"value" => "",
					"description" => __( "Enter your title for your link.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "textfield",
					"heading" => __( "Read More Link Class", "eut-corpus-vc-extension" ),
					"param_name" => "read_more_class",
					"value" => "",
					"description" => __( "Enter extra class name for your link.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "vc_link",
					"heading" => __( "Read More Link", "eut-corpus-vc-extension" ),
					"param_name" => "read_more_link",
					"value" => "",
					"description" => __( "Enter read more link.", "eut-corpus-vc-extension" ),
				),
				eut_vce_add_animation(),
				eut_vce_add_animation_delay(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_image_text', 'eut_corpus_vce_image_text_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_image_text_shortcode_params( 'eut_image_text' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
