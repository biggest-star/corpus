<?php
/**
 * Media Box Shortcode
 */

if( !function_exists( 'eut_media_box_shortcode' ) ) {

	function eut_media_box_shortcode( $atts, $content ) {
		global $wp_embed;
		$output = $data = $retina_data = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'title' => '',
					'heading' => 'h3',
					'media_type' => 'image',
					'image' => '',
					'retina_image' => '',
					'video_popup' => '',
					'video_link' => '',
					'map_lat' => '51.516221',
					'map_lng' => '-0.136986',
					'map_height' => '280',
					'map_marker' => '',
					'map_zoom' => '14',
					'title_link' => '',
					'read_more_title' => '',
					'align' => 'left',
					'animation' => '',
					'animation_delay' => '200',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		if ( !empty( $animation ) ) {
			$animation = 'eut-' . $animation;
		}

		if ( !empty( $title_link ) ){
			$href = vc_build_link( $title_link );
			$url = $href['url'];
			if ( !empty( $href['target'] ) ){
				$target = $href['target'];
			} else {
				$target = "_self";
			}
		} else {
			$url = "#";
			$target = "_self";
		}
		$target = trim( $target );

		$media_box_classes = array( 'eut-element', 'eut-box', 'eut-align-' . $align );

		if ( !empty( $animation ) ) {
			array_push( $media_box_classes, 'eut-animated-item' );
			array_push( $media_box_classes, $animation);
			$data = ' data-delay="' . esc_attr( $animation_delay ) . '"';
		}
		if ( !empty( $el_class ) ) {
			array_push( $media_box_classes, $el_class);
		}
		$media_box_classe_string = implode( ' ', $media_box_classes );

		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		$output .= '<div class="' . esc_attr( $media_box_classe_string ) . '" style="' . $style . '"' . $data . '>';


		switch( $media_type ) {
			case 'image':
			case 'image-video-popup':
				if ( !empty( $image ) ) {
					$img_id = preg_replace('/[^\d]/', '', $image);
					$img_src = wp_get_attachment_image_src( $img_id, 'full' );
					$img_url = $img_src[0];
					$image_srcset = '';
					if ( !empty( $retina_image ) ) {
						$img_retina_id = preg_replace('/[^\d]/', '', $retina_image);
						$img_retina_src = wp_get_attachment_image_src( $img_retina_id, 'full' );
						$retina_url = $img_retina_src[0];
						$image_srcset = esc_url( $img_url ) . ' 1x,' . esc_url( $retina_url ) . ' 2x';
						$image_html = wp_get_attachment_image( $img_id, 'full' , '', array( 'srcset'=> $image_srcset ) );
					} else {
						$image_html = wp_get_attachment_image( $img_id, 'full' );
					}

					if ( 'image-video-popup' == $media_type && !empty( $video_link ) ) {
						$output .= '<div class="eut-media">';
						$output .= '	<a class="eut-vimeo-popup eut-icon-video" href="' . esc_url( $video_link ) . '">';
						$output .= $image_html;
						$output .= '	</a>';
						$output .= '</div>';
					} else {
						$output .= '<div class="eut-media">';
						if ( !empty( $title_link ) ) {
							$output .= '<a href="' . esc_url( $url ) . '" target="' . esc_attr( $target ) . '">';
						}
						$output .= $image_html;
						if ( !empty( $title_link ) ) {
							$output .= '</a>';
						}
						$output .= '</div>';
					}
				}
				break;
			case 'video':
				if ( !empty( $video_link ) ) {
					$output .= '<div class="eut-media">';
					$output .= $wp_embed->run_shortcode( '[embed]' . $video_link . '[/embed]' );
					$output .= '</div>';
				}
				break;
			case 'map':
				wp_enqueue_script( 'eut-googleapi-script' );
				wp_enqueue_script( 'eut-maps-script' );
				if ( empty( $map_marker ) ) {
					$map_marker = get_template_directory_uri() . '/images/markers/markers.png';
				} else {
					$id = preg_replace('/[^\d]/', '', $map_marker);
					$full_src = wp_get_attachment_image_src( $id, 'full' );
					$map_marker = $full_src[0];
				}
				$map_title = '';

				$data_map = 'data-lat="' . esc_attr( $map_lat ) . '" data-lng="' . esc_attr( $map_lng ) . '" data-zoom="' . esc_attr( $map_zoom ) . '"';
				$output .= '<div class="eut-media">';
				$output .= '  <div class="eut-map" ' . $data_map . ' style="' . $style . eut_corpus_vce_build_dimension( 'height', $map_height ) . '">';
				$output .= apply_filters( 'eut_privacy_gmap_fallback', '', $map_lat, $map_lng );
				$output .= '</div>';
				$output .= '  <div style="display:none" class="eut-map-point" data-point-lat="' . esc_attr( $map_lat ) . '" data-point-lng="' . esc_attr( $map_lng ) . '" data-point-marker="' . esc_attr( $map_marker ) . '" data-point-title="' . esc_attr( $map_title ) . '"></div>';
				$output .= '</div>';
				break;
			default :
				break;
		}


		$output .= '  <div class="eut-box-content">';
		if ( !empty( $title ) ) {
			if ( !empty( $title_link ) ) {
			$output .= '    <a href="' . esc_url( $url ) . '" target="' . $target . '">';
			}
			$output .= '<' . $heading . ' class="eut-box-title">' . $title. '</' . $heading . '>';
			if ( !empty( $title_link ) ) {
			$output .= '    </a>';
			}
		}

		$output .= '    <p>' . do_shortcode( $content ) . '</p>';
		if ( !empty( $read_more_title ) && !empty( $url ) ) {
		$output .= '    <a href="' . esc_url( $url ) . '" target="' . $target . '" class="eut-read-more">';
		$output .=  $read_more_title ;
		$output .= '</a>';
		}
		$output .= '  </div>';
		$output .= '</div>';

		return $output;
	}
	add_shortcode( 'eut_media_box', 'eut_media_box_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_media_box_shortcode_params' ) ) {
	function eut_corpus_vce_media_box_shortcode_params( $tag ) {
		return array(
			"name" => __( "Media Box", "eut-corpus-vc-extension" ),
			"description" => __( "Image, Video or Map combined with text", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-media-box",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "dropdown",
					"heading" => __( "Media type", "eut-corpus-vc-extension" ),
					"param_name" => "media_type",
					"value" => array(
						__( "Image", "eut-corpus-vc-extension" ) => 'image',
						__( "Image - Video Popup", "eut-corpus-vc-extension" ) => 'image-video-popup',
						__( "Video", "eut-corpus-vc-extension" ) => 'video',
						__( "Map", "eut-corpus-vc-extension" ) => 'map',
					),
					"description" => __( "Select your media type.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "attach_image",
					"heading" => __( "Image", "eut-corpus-vc-extension" ),
					"param_name" => "image",
					"value" => '',
					"description" => __( "Select an image.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "media_type", 'value' => array( 'image', 'image-video-popup' ) ),
				),
				array(
					"type" => "attach_image",
					"heading" => __( "Retina Image", "eut-corpus-vc-extension" ),
					"param_name" => "retina_image",
					"value" => '',
					"description" => __( "Select a 2x image.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "media_type", 'value' => array( 'image', 'image-video-popup' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Video Link", "eut-corpus-vc-extension" ),
					"param_name" => "video_link",
					"value" => "",
					"description" => __( "Type video URL e.g Vimeo/YouTube.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "media_type", 'value' => array( 'image-video-popup', 'video' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Map Latitude", "eut-corpus-vc-extension" ),
					"param_name" => "map_lat",
					"value" => "51.516221",
					"description" => __( "Type map Latitude.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "media_type", 'value' => array( 'map' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Map Longtitude", "eut-corpus-vc-extension" ),
					"param_name" => "map_lng",
					"value" => "-0.136986",
					"description" => __( "Type map Longtitude.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "media_type", 'value' => array( 'map' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Map Zoom", "eut-corpus-vc-extension" ),
					"param_name" => "map_zoom",
					"value" => array( '1', '2', '3' ,'4', '5', '6', '7', '8' ,'9' ,'10' ,'11' ,'12', '13', '14', '15', '16', '17', '18', '19' ),
					"std" => '14',
					"description" => __( "Zoom of the map.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "media_type", 'value' => array( 'map' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Map Height", "eut-corpus-vc-extension" ),
					"param_name" => "map_height",
					"value" => "280",
					"description" => __( "Type map height.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "media_type", 'value' => array( 'map' ) ),
				),
				array(
					"type" => "attach_image",
					"heading" => __( "Custom marker", "eut-corpus-vc-extension" ),
					"param_name" => "map_marker",
					"value" => '',
					"description" => __( "Select an icon for custom marker.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "media_type", 'value' => array( 'map' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Title", "eut-corpus-vc-extension" ),
					"param_name" => "title",
					"value" => "Sample Title",
					"description" => __( "Enter your title.", "eut-corpus-vc-extension" ),
					"save_always" => true,
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Heading", "eut-corpus-vc-extension" ),
					"param_name" => "heading",
					"admin_label" => true,
					"value" => array( 'h1', 'h2', 'h3', 'h4' , 'h5', 'h6' ),
					"description" => __( "Heading size", "eut-corpus-vc-extension" ),
					"std" => "h3",
				),
				array(
					"type" => "textarea",
					"heading" => __( "Text", "eut-corpus-vc-extension" ),
					"param_name" => "content",
					"value" => "Sample Text",
					"description" => __( "Enter your text.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "vc_link",
					"heading" => __( "Title Link", "eut-corpus-vc-extension" ),
					"param_name" => "title_link",
					"value" => "",
					"description" => __( "Enter title link.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Read More Title", "eut-corpus-vc-extension" ),
					"param_name" => "read_more_title",
					"value" => "",
					"description" => __( "Enter your title for your link.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				eut_vce_add_align(),
				eut_vce_add_animation(),
				eut_vce_add_animation_delay(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_media_box', 'eut_corpus_vce_media_box_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_media_box_shortcode_params( 'eut_media_box' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
