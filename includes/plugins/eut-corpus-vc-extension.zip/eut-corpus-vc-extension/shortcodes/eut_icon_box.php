<?php
/**
 * Icon Box Shortcode
 */

if( !function_exists( 'eut_icon_box_shortcode' ) ) {

	function eut_icon_box_shortcode( $atts, $content ) {

		$output = $link_start = $link_end = $retina_data = $text_style_class = $data = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'title' => '',
					'heading' => 'h3',
					'icon_library' => 'fontawesome',
					'icon_fontawesome' => 'fa fa-info-circle',
					'icon_openiconic' => 'vc-oi vc-oi-dial',
					'icon_typicons' => 'typcn typcn-adjust-brightness',
					'icon_entypo' => 'entypo-icon entypo-icon-note',
					'icon_linecons' => 'vc_li vc_li-heart',
					'icon_type' => 'icon',
					'icon_size' => 'medium',
					'icon_shape' => 'no-shape',
					'shape_type' => 'simple',
					'icon_color' => 'primary-1',
					'icon_shape_color' => 'grey',
					'icon_animation' => 'no',
					'icon_char' => 'A',
					'icon_image' => '',
					'retina_icon_image' => '',
					'align' => 'left',
					'text_style' => 'none',
					'link' => '',
					'animation' => '',
					'animation_delay' => '200',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		if ( !empty( $animation ) ) {
			$animation = 'eut-' . $animation;
		}

		$icon_box_classes = array( 'eut-element' );

		array_push( $icon_box_classes, 'eut-box-icon' );
		array_push( $icon_box_classes, 'eut-align-' . $align );
		array_push( $icon_box_classes, 'eut-' . $icon_size );

		if ( !empty( $animation ) ) {
			array_push( $icon_box_classes, 'eut-animated-item' );
			array_push( $icon_box_classes, $animation);
			$data = ' data-delay="' . esc_attr( $animation_delay ) . '"';
		}

		if ( 'yes' == $icon_animation ) {
			array_push( $icon_box_classes, 'eut-advanced-hover' );
		}
		if ( !empty ( $el_class ) ) {
			array_push( $icon_box_classes, $el_class);
		}



		$icon_wrapper_classes = array( 'eut-wrapper-icon' );
		$icon_classes = array();

		if ( 'no-shape' != $icon_shape ) {
			array_push( $icon_wrapper_classes, 'eut-' . $shape_type );
			array_push( $icon_box_classes, 'eut-with-shape' );
		}
		array_push( $icon_wrapper_classes, 'eut-' . $icon_shape );

		if ( 'no-shape' != $icon_shape && 'outline' != $shape_type ) {
			array_push( $icon_wrapper_classes, 'eut-bg-' . $icon_shape_color );
		} else {
			array_push( $icon_wrapper_classes, 'eut-color-' . $icon_shape_color );
		}

		if ( 'icon' == $icon_type ) {

			$icon_class = isset( ${"icon_" . $icon_library} ) ? esc_attr( ${"icon_" . $icon_library} ) : 'fa fa-adjust';
			if ( function_exists( 'vc_icon_element_fonts_enqueue' ) ) {
				vc_icon_element_fonts_enqueue( $icon_library );
			}
			array_push( $icon_classes, $icon_class );
			array_push( $icon_classes, 'eut-color-' . $icon_color );
		}

		if ( 'image' == $icon_type ) {
			array_push( $icon_wrapper_classes, 'eut-image-icon' );
		}

		$icon_box_class_string = implode( ' ', $icon_box_classes );
		$icon_wrapper_class_string = implode( ' ', $icon_wrapper_classes );
		$icon_class_string = implode( ' ', $icon_classes );


		if ( !empty( $link ) ){
			$href = vc_build_link( $link );
			$url = $href['url'];
			if ( !empty( $href['target'] ) ){
				$target = $href['target'];
			} else {
				$target = "_self";
			}
		} else {
			$url = "#";
			$target = "_self";
		}
		$target = trim( $target );
		if ( !empty( $url ) && '#' != $url ) {
			$link_start = '<a href="' . esc_url( $url ) . '" target="' . esc_attr( $target ) . '">';
			$link_end = '</a>';
		}

		// Paragraph
		if ( 'none' != $text_style ) {
			$text_style_class = 'eut-' .$text_style;
		}

		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		$output .= '<div class="' . esc_attr( $icon_box_class_string ) . '" style="' . $style . '"' . $data . '>';

		$output .= $link_start;

		if ( 'image' == $icon_type ) {
			if ( !empty( $icon_image ) ) {
				$img_id = preg_replace('/[^\d]/', '', $icon_image);
				$img_src = wp_get_attachment_image_src( $img_id, 'full' );
				$img_url = $img_src[0];
				$image_srcset = '';
				if ( !empty( $retina_icon_image ) ) {
					$img_retina_id = preg_replace('/[^\d]/', '', $retina_icon_image);
					$img_retina_src = wp_get_attachment_image_src( $img_retina_id, 'full' );
					$retina_url = $img_retina_src[0];
					$image_srcset = esc_url( $img_url ) . ' 1x,' . esc_url( $retina_url ) . ' 2x';
					$image_html = wp_get_attachment_image( $img_id, 'full' , '', array( 'srcset'=> $image_srcset ) );
				} else {
					$image_html = wp_get_attachment_image( $img_id, 'full' );
				}
				$output .= '<div class="eut-image-icon">';
				$output .= $image_html;
				$output .= '</div>';
			}
		} else if( 'char' == $icon_type ) {
			$output .= '  <div class="' . esc_attr( $icon_wrapper_class_string ) . '"><span class="eut-color-' . esc_attr( $icon_color ) . '">'. $icon_char. '</span></div>';
		} else {
			$output .= '  <div class="' . esc_attr( $icon_wrapper_class_string ) . '"><i class="'. esc_attr( $icon_class_string ) . '"></i></div>';
		}

		$output .= $link_end;

		$output .= '  <div class="eut-box-content">';
		if ( !empty( $title ) ) {
		$output .= $link_start;
		$output .= '      <' . $heading . ' class="eut-box-title">' . $title. '</' . $heading . '>';
		$output .= $link_end;
		}
		if ( !empty( $content ) ) {
		$output .= '    <p class="' . esc_attr( $text_style_class ) . '">' . $content . '</p>';
		}
		$output .= '  </div>';
		$output .= '</div>';

		return $output;
	}
	add_shortcode( 'eut_icon_box', 'eut_icon_box_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_icon_box_shortcode_params' ) ) {
	function eut_corpus_vce_icon_box_shortcode_params( $tag ) {
		return array(
			"name" => __( "Icon Box", "eut-corpus-vc-extension" ),
			"description" => __( "Add an icon, character or image with title and text", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-icon-box",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "dropdown",
					"heading" => __( "Icon Box Type", "eut-corpus-vc-extension" ),
					"param_name" => "icon_type",
					"value" => array(
						__( "Icon", "eut-corpus-vc-extension" ) => 'icon',
						__( "Image", "eut-corpus-vc-extension" ) => 'image',
						__( "Character", "eut-corpus-vc-extension" ) => 'char',
					),
					"description" => '',
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Icon size", "eut-corpus-vc-extension" ),
					"param_name" => "icon_size",
					"value" => array(
						__( "Large", "eut-corpus-vc-extension" ) => 'large',
						__( "Medium", "eut-corpus-vc-extension" ) => 'medium',
						__( "Small", "eut-corpus-vc-extension" ) => 'small',
					),
					"std" => 'medium',
					"description" => '',
				),
				eut_vce_add_align(),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Icon library', 'eut-corpus-vc-extension' ),
					'value' => array(
						__( 'Font Awesome', 'eut-corpus-vc-extension' ) => 'fontawesome',
						__( 'Open Iconic', 'eut-corpus-vc-extension' ) => 'openiconic',
						__( 'Typicons', 'eut-corpus-vc-extension' ) => 'typicons',
						__( 'Entypo', 'eut-corpus-vc-extension' ) => 'entypo',
						__( 'Linecons', 'eut-corpus-vc-extension' ) => 'linecons',
					),
					'param_name' => 'icon_library',
					'description' => __( 'Select icon library.', 'eut-corpus-vc-extension' ),
					"dependency" => Array( 'element' => "icon_type", 'value' => array( 'icon' ) ),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'eut-corpus-vc-extension' ),
					'param_name' => 'icon_fontawesome',
					'value' => 'fa fa-info-circle',
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'iconsPerPage' => 200, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'icon_library',
						'value' => 'fontawesome',
					),
					'description' => __( 'Select icon from library.', 'eut-corpus-vc-extension' ),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'eut-corpus-vc-extension' ),
					'param_name' => 'icon_openiconic',
					'value' => 'vc-oi vc-oi-dial',
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'type' => 'openiconic',
						'iconsPerPage' => 200, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'icon_library',
						'value' => 'openiconic',
					),
					'description' => __( 'Select icon from library.', 'eut-corpus-vc-extension' ),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'eut-corpus-vc-extension' ),
					'param_name' => 'icon_typicons',
					'value' => 'typcn typcn-adjust-brightness',
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'type' => 'typicons',
						'iconsPerPage' => 200, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'icon_library',
						'value' => 'typicons',
					),
					'description' => __( 'Select icon from library.', 'eut-corpus-vc-extension' ),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'eut-corpus-vc-extension' ),
					'param_name' => 'icon_entypo',
					'value' => 'entypo-icon entypo-icon-note',
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'type' => 'entypo',
						'iconsPerPage' => 300, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'icon_library',
						'value' => 'entypo',
					),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'eut-corpus-vc-extension' ),
					'param_name' => 'icon_linecons',
					'value' => 'vc_li vc_li-heart',
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'type' => 'linecons',
						'iconsPerPage' => 200, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'icon_library',
						'value' => 'linecons',
					),
					'description' => __( 'Select icon from library.', 'eut-corpus-vc-extension' ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Icon Color", "eut-corpus-vc-extension" ),
					"param_name" => "icon_color",
					"value" => array(
						__( "Primary 1", "eut-corpus-vc-extension" ) => 'primary-1',
						__( "Primary 2", "eut-corpus-vc-extension" ) => 'primary-2',
						__( "Primary 3", "eut-corpus-vc-extension" ) => 'primary-3',
						__( "Primary 4", "eut-corpus-vc-extension" ) => 'primary-4',
						__( "Primary 5", "eut-corpus-vc-extension" ) => 'primary-5',
						__( "Green", "eut-corpus-vc-extension" ) => 'green',
						__( "Orange", "eut-corpus-vc-extension" ) => 'orange',
						__( "Red", "eut-corpus-vc-extension" ) => 'red',
						__( "Blue", "eut-corpus-vc-extension" ) => 'blue',
						__( "Aqua", "eut-corpus-vc-extension" ) => 'aqua',
						__( "Purple", "eut-corpus-vc-extension" ) => 'purple',
						__( "Black", "eut-corpus-vc-extension" ) => 'black',
						__( "Grey", "eut-corpus-vc-extension" ) => 'grey',
						__( "White", "eut-corpus-vc-extension" ) => 'white',
					),
					"description" => __( "Color of the icon.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "icon_type", 'value' => array( 'icon', 'char' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Icon shape", "eut-corpus-vc-extension" ),
					"param_name" => "icon_shape",
					"value" => array(
						__( "None", "eut-corpus-vc-extension" ) => 'no-shape',
						__( "Square", "eut-corpus-vc-extension" ) => 'square',
						__( "Round", "eut-corpus-vc-extension" ) => 'round',
						__( "Circle", "eut-corpus-vc-extension" ) => 'circle',
					),
					"description" => '',
					"admin_label" => true,
					"dependency" => Array( 'element' => "icon_type", 'value' => array( 'icon', 'char' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Shape type", "eut-corpus-vc-extension" ),
					"param_name" => "shape_type",
					"value" => array(
						__( "Simple", "eut-corpus-vc-extension" ) => 'simple',
						__( "Outline", "eut-corpus-vc-extension" ) => 'outline',
					),
					"description" => __( "Select shape type.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "icon_shape", 'value' => array( 'square', 'round', 'circle' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Icon Shape Color", "eut-corpus-vc-extension" ),
					"param_name" => "icon_shape_color",
					"value" => array(
						__( "Primary 1", "eut-corpus-vc-extension" ) => 'primary-1',
						__( "Primary 2", "eut-corpus-vc-extension" ) => 'primary-2',
						__( "Primary 3", "eut-corpus-vc-extension" ) => 'primary-3',
						__( "Primary 4", "eut-corpus-vc-extension" ) => 'primary-4',
						__( "Primary 5", "eut-corpus-vc-extension" ) => 'primary-5',
						__( "Green", "eut-corpus-vc-extension" ) => 'green',
						__( "Orange", "eut-corpus-vc-extension" ) => 'orange',
						__( "Red", "eut-corpus-vc-extension" ) => 'red',
						__( "Blue", "eut-corpus-vc-extension" ) => 'blue',
						__( "Aqua", "eut-corpus-vc-extension" ) => 'aqua',
						__( "Purple", "eut-corpus-vc-extension" ) => 'purple',
						__( "Black", "eut-corpus-vc-extension" ) => 'black',
						__( "Grey", "eut-corpus-vc-extension" ) => 'grey',
						__( "White", "eut-corpus-vc-extension" ) => 'white',
					),
					'std' => 'grey',
					"description" => __( "This affects to the Background of the simple shape type. Alternatively, affects to the line shape type.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "icon_shape", 'value' => array( 'square', 'round', 'circle' ) ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Enable Advanced Hover", "eut-corpus-vc-extension" ),
					"param_name" => "icon_animation",
					"value" => Array( __( "If selected, you will have advanced hover.", "eut-corpus-vc-extension" ) => 'yes' ),
					"dependency" => Array( 'element' => "align", 'value' => array( 'center' ) ),
				),
				array(
					"type" => "attach_image",
					"heading" => __( "Icon Image", "eut-corpus-vc-extension" ),
					"param_name" => "icon_image",
					"value" => '',
					"description" => __( "Select an icon image.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "icon_type", 'value' => array( 'image' ) ),
				),
				array(
					"type" => "attach_image",
					"heading" => __( "Retina Icon Image", "eut-corpus-vc-extension" ),
					"param_name" => "retina_icon_image",
					"value" => '',
					"description" => __( "Select a 2x icon.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "icon_type", 'value' => array( 'image' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Character", "eut-corpus-vc-extension" ),
					"param_name" => "icon_char",
					"value" => "A",
					"description" => __( "Type a single character.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "icon_type", 'value' => array( 'char' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Title", "eut-corpus-vc-extension" ),
					"param_name" => "title",
					"value" => "",
					"description" => __( "Enter icon box title.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Heading", "eut-corpus-vc-extension" ),
					"param_name" => "heading",
					"admin_label" => true,
					"value" => array( 'h1', 'h2', 'h3', 'h4' , 'h5', 'h6' ),
					"description" => __( "Heading size", "eut-corpus-vc-extension" ),
					"std" => 'h3',
				),
				array(
					"type" => "textarea",
					"heading" => __( "Text", "eut-corpus-vc-extension" ),
					"param_name" => "content",
					"value" => "",
					"description" => __( "Enter your content.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Text Style", "eut-corpus-vc-extension" ),
					"param_name" => "text_style",
					"value" => array(
						__( "None", "eut-corpus-vc-extension" ) => '',
						__( "Leader", "eut-corpus-vc-extension" ) => 'leader-text',
						__( "Subtitle", "eut-corpus-vc-extension" ) => 'subtitle',
					),
					"description" => 'Select your text style',
				),
				array(
					"type" => "vc_link",
					"heading" => __( "Link", "eut-corpus-vc-extension" ),
					"param_name" => "link",
					"value" => "",
					"description" => __( "Enter link.", "eut-corpus-vc-extension" ),
				),
				eut_vce_add_animation(),
				eut_vce_add_animation_delay(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_icon_box', 'eut_corpus_vce_icon_box_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_icon_box_shortcode_params( 'eut_icon_box' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
