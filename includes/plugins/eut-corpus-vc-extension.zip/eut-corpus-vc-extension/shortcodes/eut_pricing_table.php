<?php
/**
 * Pricing Table Shortcode
 */

if( !function_exists( 'eut_pricing_table_shortcode' ) ) {

	function eut_pricing_table_shortcode( $atts, $content ) {

		$output = $data = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'title' => '',
					'heading' => 'h3',
					'price' => '',
					'interval' => '',
					'values' => '',
					'table_color' => 'grey',
					'button_text' => '',
					'button_link' => '',
					'button_type' => 'simple',
					'button_size' => 'medium',
					'button_color' => 'primary-1',
					'button_shape' => 'square',
					'button_class' => '',
					'bg_color' => '',
					'animation' => '',
					'animation_delay' => '200',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		if ( !empty( $animation ) ) {
			$animation = 'eut-' . $animation;
		}

		$button = eut_corpus_vce_get_button( $button_text, $button_link, $button_type, $button_size, $button_color, $button_shape, $button_class );

		//Pricing Table Classes
		$pricing_classes = array( 'eut-element', 'eut-pricing-table' );
		if ( !empty( $animation ) ) {
			array_push( $pricing_classes, 'eut-animated-item' );
			array_push( $pricing_classes, $animation);
			$data = ' data-delay="' . esc_attr( $animation_delay ) . '"';
		}

		if ( !empty ( $el_class ) ) {
			array_push( $pricing_classes, $el_class);
		}
		$pricing_class_string = implode( ' ', $pricing_classes );

		//Pricing Lines
		$pricing_lines = explode(",", $values);

		$pricing_lines_data = array();
		foreach ($pricing_lines as $line) {
			$new_line = array();
			$data_line = explode("|", $line);
			$new_line['value1'] = isset( $data_line[0] ) && !empty( $data_line[0] ) ? $data_line[0] : '';
			$new_line['value2'] = isset( $data_line[1] ) && !empty( $data_line[1] ) ? $data_line[1] : '';
			$pricing_lines_data[] = $new_line;
		}

		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		$output .= '<div class="' . $pricing_class_string . '" style="' . $style . '"' . $data . '>';
		$output .= '  <div class="eut-pricing-header">';
		$output .= '    <div class="eut-subtitle eut-pricing-title eut-bg-' . $table_color . '">' . $title . '</div>';
		$output .= '    <' . $heading . ' class="eut-price eut-bg-' . $table_color . '">' . $price . ' <span>' . $interval . '</span></' . $heading . '>';
	    $output .= '  </div>';
	    $output .= '  <ul>';
		foreach($pricing_lines_data as $line) {
			$output .= '<li><strong>' .  $line['value1'] . ' </strong>' .  $line['value2'] . '</li>';
		}
		$output .= '  </ul>';
		$output .= $button;
		$output .= '</div>';

		return $output;
	}
	add_shortcode( 'eut_pricing_table', 'eut_pricing_table_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_pricing_table_shortcode_params' ) ) {
	function eut_corpus_vce_pricing_table_shortcode_params( $tag ) {
		return array(
			"name" => __( "Pricing Table", "eut-corpus-vc-extension" ),
			"description" => __( "Stylish pricing tables", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-pricing-table",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "textfield",
					"heading" => __( "Title", "eut-corpus-vc-extension" ),
					"param_name" => "title",
					"value" => "Title",
					"save_always" => true,
					"description" => __( "Enter your title here.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Heading", "eut-corpus-vc-extension" ),
					"param_name" => "heading",
					"admin_label" => true,
					"value" => array( 'h1', 'h2', 'h3', 'h4' , 'h5', 'h6' ),
					"description" => __( "Heading size", "eut-corpus-vc-extension" ),
					"std" => "h3",
				),
				array(
					"type" => "textfield",
					"heading" => __( "Price", "eut-corpus-vc-extension" ),
					"param_name" => "price",
					"value" => "$0",
					"save_always" => true,
					"description" => __( "Enter your price here. eg $80.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "textfield",
					"heading" => __( "Interval", "eut-corpus-vc-extension" ),
					"param_name" => "interval",
					"value" => "/month",
					"save_always" => true,
					"description" => __( "Enter interval period here. e.g: /month, per month, per year.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "exploded_textarea",
					"heading" => __("Attributes", "eut-corpus-vc-extension"),
					"param_name" => "values",
					"description" => __( "Input attribute values. Divide values with linebreaks (Enter). Example: 100|Users.", "eut-corpus-vc-extension" ),
					"value" => "100|Users,8 Gig|Disc Space,Unlimited|Data Transfer",
					"save_always" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Pricing Table Color", "eut-corpus-vc-extension" ),
					"param_name" => "table_color",
					"value" => array(
						__( "Primary 1", "eut-corpus-vc-extension" ) => 'primary-1',
						__( "Primary 2", "eut-corpus-vc-extension" ) => 'primary-2',
						__( "Primary 3", "eut-corpus-vc-extension" ) => 'primary-3',
						__( "Primary 4", "eut-corpus-vc-extension" ) => 'primary-4',
						__( "Primary 5", "eut-corpus-vc-extension" ) => 'primary-5',
						__( "Green", "eut-corpus-vc-extension" ) => 'green',
						__( "Orange", "eut-corpus-vc-extension" ) => 'orange',
						__( "Red", "eut-corpus-vc-extension" ) => 'red',
						__( "Blue", "eut-corpus-vc-extension" ) => 'blue',
						__( "Aqua", "eut-corpus-vc-extension" ) => 'aqua',
						__( "Purple", "eut-corpus-vc-extension" ) => 'purple',
						__( "Black", "eut-corpus-vc-extension" ) => 'black',
						__( "Grey", "eut-corpus-vc-extension" ) => 'grey',
					),
					'std' => 'grey',
				),
				eut_vce_add_button_text(),
				eut_vce_add_button_link(),
				eut_vce_add_button_type(),
				eut_vce_add_button_color(),
				eut_vce_add_button_size(),
				eut_vce_add_button_shape(),
				eut_vce_add_button_class(),
				eut_vce_add_animation(),
				eut_vce_add_animation_delay(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_pricing_table', 'eut_corpus_vce_pricing_table_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_pricing_table_shortcode_params( 'eut_pricing_table' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
