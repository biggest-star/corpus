<?php
/**
 * Typed Text Shortcode
 */

if( !function_exists( 'eut_typed_text_shortcode' ) ) {

	function eut_typed_text_shortcode( $atts, $content ) {

		$output = $link_start = $link_end = $retina_data = $data = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'typed_prefix' => '',
					'typed_suffix' => '',
					'typed_values' => '',
					'textspeed' => '0',
					'backspeed' => '0',
					'startdelay' => '0',
					'backdelay' => '500',
					'loop' => '',
					'show_cursor' => 'yes',
					'cursor_text' => '|',
					'text_color' => 'primary-1',
					'text_bg_color' => 'none',
					'heading' => 'h3',
					'align' => 'left',
					'animation' => '',
					'animation_delay' => '200',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		if ( !empty( $animation ) ) {
			$animation = 'eut-' . $animation;
		}

		$typed_classes = array( 'eut-element' );

		array_push( $typed_classes, 'eut-typed-text' );
		array_push( $typed_classes, 'eut-align-' . $align );

		if ( !empty( $animation ) ) {
			array_push( $typed_classes, 'eut-animated-item' );
			array_push( $typed_classes, $animation);
			$data = ' data-delay="' . esc_attr( $animation_delay ) . '"';
		}

		if ( !empty ( $el_class ) ) {
			array_push( $typed_classes, $el_class);
		}

		$typed_class_string = implode( ' ', $typed_classes );

		$typed_colors = array( 'eut-animated-text' );

		array_push( $typed_colors, 'eut-color-' . $text_color );
		if ( 'none' != $text_bg_color ) {
			array_push( $typed_colors, 'eut-with-bg eut-bg-' . $text_bg_color );
		}

		$typed_colors_string = implode( ' ', $typed_colors );


		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		$typed_id = uniqid('eut-typed-item-');

		$typed_string_values = '';

		if( !empty( $typed_values ) ) {


			$typed_values_array = explode(",", $typed_values);
			$typed_values_count= count( $typed_values_array );

			$typed_string_values = '[';

			foreach( $typed_values_array as $key => $value ) {
				$typed_string_values .= '"'. trim( htmlspecialchars_decode( strip_tags( $value ) ) ) . '"';
				if( $key != ( $typed_values_count-1 ) ) {
					$typed_string_values .= ',';
				}
			}

			$typed_string_values .= ']';
		}

		$output .= '<' . $heading . ' class="' . esc_attr( $typed_class_string ) . '" style="' . $style . '"' . $data . '>';
		$output .= '    <span class="eut-typed-text-prefix"> ' . $typed_prefix . '</span>';
		$output .= '    <span class="' . esc_attr( $typed_colors_string ) . '">';
		$output .= '    	<span id="' . $typed_id . '"></span>';
		$output .= '    </span>';
		$output .= '    <span class="eut-typed-text-suffix"> ' . $typed_suffix . '</span>';

		$loop = eut_corpus_vce_text_to_bool( $loop );

		$show_cursor = eut_corpus_vce_text_to_bool( $show_cursor );

		$output .= '<script type="text/javascript">
				jQuery(function($){ $("#' . $typed_id . '").typed({
					strings: ' . $typed_string_values . ',
					typeSpeed: ' . $textspeed . ',
					backSpeed: ' . $backspeed . ',
					startDelay: ' . $startdelay . ',
					backDelay: ' . $backdelay . ',
					loop: ' . $loop . ',
					loopCount: false,
					showCursor: ' . $show_cursor . ',
					cursorChar: "' . $cursor_text . '",
					attr: null
				});
			});
		</script>';

		$output .= '</' . $heading . '>';

		return $output;
	}
	add_shortcode( 'eut_typed_text', 'eut_typed_text_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_typed_text_shortcode_params' ) ) {
	function eut_corpus_vce_typed_text_shortcode_params( $tag ) {
		return array(
			"name" => __( "Typed text", "eut-corpus-vc-extension" ),
			"description" => __( "Add a typed text", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-typed-text",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "textfield",
					"heading" => __( "Prefix", "eut-corpus-vc-extension" ),
					"param_name" => "typed_prefix",
					"value" => "",
					"description" => __( "Enter prefix text.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "exploded_textarea",
					"heading" => __("Typed Text", "eut-corpus-vc-extension"),
					"param_name" => "typed_values",
					"description" => __( "Input Typed Text here. Divide values with linebreaks (Enter).", "eut-corpus-vc-extension" ),
					"value" => "These are the default values...,Use your own values!",
					"save_always" => true,
					"admin_label" => true,
				),
				array(
					"type" => "textfield",
					"heading" => __( "Suffix", "eut-corpus-vc-extension" ),
					"param_name" => "typed_suffix",
					"value" => "",
					"description" => __( "Enter suffix text.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Heading", "eut-corpus-vc-extension" ),
					"param_name" => "heading",
					"admin_label" => true,
					"value" => array( 'h1', 'h2', 'h3', 'h4' , 'h5', 'h6' ),
					"description" => __( "Heading size", "eut-corpus-vc-extension" ),
					"std" => "h3",
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Typed Text Color", "eut-corpus-vc-extension" ),
					"param_name" => "text_color",
					"value" => array(
						__( "Primary 1", "eut-corpus-vc-extension" ) => 'primary-1',
						__( "Primary 2", "eut-corpus-vc-extension" ) => 'primary-2',
						__( "Primary 3", "eut-corpus-vc-extension" ) => 'primary-3',
						__( "Primary 4", "eut-corpus-vc-extension" ) => 'primary-4',
						__( "Primary 5", "eut-corpus-vc-extension" ) => 'primary-5',
						__( "Green", "eut-corpus-vc-extension" ) => 'green',
						__( "Orange", "eut-corpus-vc-extension" ) => 'orange',
						__( "Red", "eut-corpus-vc-extension" ) => 'red',
						__( "Blue", "eut-corpus-vc-extension" ) => 'blue',
						__( "Aqua", "eut-corpus-vc-extension" ) => 'aqua',
						__( "Purple", "eut-corpus-vc-extension" ) => 'purple',
						__( "Black", "eut-corpus-vc-extension" ) => 'black',
						__( "Grey", "eut-corpus-vc-extension" ) => 'grey',
						__( "White", "eut-corpus-vc-extension" ) => 'white',
					),
					'std' => 'primary-1',
					"description" => __( "Color of the typed text.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Background Color", "eut-corpus-vc-extension" ),
					"param_name" => "text_bg_color",
					"value" => array(
						__( "None", "eut-corpus-vc-extension" ) => 'none',
						__( "Primary 1", "eut-corpus-vc-extension" ) => 'primary-1',
						__( "Primary 2", "eut-corpus-vc-extension" ) => 'primary-2',
						__( "Primary 3", "eut-corpus-vc-extension" ) => 'primary-3',
						__( "Primary 4", "eut-corpus-vc-extension" ) => 'primary-4',
						__( "Primary 5", "eut-corpus-vc-extension" ) => 'primary-5',
						__( "Green", "eut-corpus-vc-extension" ) => 'green',
						__( "Orange", "eut-corpus-vc-extension" ) => 'orange',
						__( "Red", "eut-corpus-vc-extension" ) => 'red',
						__( "Blue", "eut-corpus-vc-extension" ) => 'blue',
						__( "Aqua", "eut-corpus-vc-extension" ) => 'aqua',
						__( "Purple", "eut-corpus-vc-extension" ) => 'purple',
						__( "Black", "eut-corpus-vc-extension" ) => 'black',
						__( "Grey", "eut-corpus-vc-extension" ) => 'grey',
						__( "White", "eut-corpus-vc-extension" ) => 'white',
					),
					'std' => 'none',
					"description" => __( "Background color for the typed text.", "eut-corpus-vc-extension" ),
				),
				eut_vce_add_align(),
				eut_vce_add_animation(),
				eut_vce_add_animation_delay(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
				array(
					"type" => "textfield",
					"heading" => __( "Text Speed", "eut-corpus-vc-extension" ),
					"param_name" => "textspeed",
					"value" => 0,
					"description" => __( "Enter text speed in ms.", "eut-corpus-vc-extension" ),
					"group" => __( "Extra Settings", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Backspeed", "eut-corpus-vc-extension" ),
					"param_name" => "backspeed",
					"value" => 0,
					"description" => __( "Enter speed of delete in ms.", "eut-corpus-vc-extension" ),
					"group" => __( "Extra Settings", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Start Delay", "eut-corpus-vc-extension" ),
					"param_name" => "startdelay",
					"value" => 0,
					"description" => __( "Enter start delay in ms.", "eut-corpus-vc-extension" ),
					"group" => __( "Extra Settings", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Back Delay", "eut-corpus-vc-extension" ),
					"param_name" => "backdelay",
					"value" => 500,
					"description" => __( "Enter back delay in ms.", "eut-corpus-vc-extension" ),
					"group" => __( "Extra Settings", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Loop", "eut-corpus-vc-extension" ),
					"param_name" => "loop",
					"value" => Array( __( "Enable loop", "eut-corpus-vc-extension" ) => 'yes' ),
					"group" => __( "Extra Settings", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Show Cursor", "eut-corpus-vc-extension" ),
					"param_name" => "show_cursor",
					"value" => Array( __( "Show Cursor", "eut-corpus-vc-extension" ) => 'yes' ),
					"group" => __( "Extra Settings", "eut-corpus-vc-extension" ),
					"std" => 'yes',
				),
				array(
					"type" => "textfield",
					"heading" => __( "Cursor Text", "eut-corpus-vc-extension" ),
					"param_name" => "cursor_text",
					"value" => "|",
					"description" => __( "Enter cursor text.", "eut-corpus-vc-extension" ),
					"group" => __( "Extra Settings", "eut-corpus-vc-extension" ),
				),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_typed_text', 'eut_corpus_vce_typed_text_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_typed_text_shortcode_params( 'eut_typed_text' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
