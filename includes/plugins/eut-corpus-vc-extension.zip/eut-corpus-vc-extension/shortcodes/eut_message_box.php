<?php
/**
 * Message Box Shortcode
 */

if( !function_exists( 'eut_message_box_shortcode' ) ) {

	function eut_message_box_shortcode( $atts, $content ) {

		$output = $data = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'icon_library' => 'fontawesome',
					'icon_fontawesome' => 'fa fa-info-circle',
					'icon_openiconic' => 'vc-oi vc-oi-dial',
					'icon_typicons' => 'typcn typcn-adjust-brightness',
					'icon_entypo' => 'entypo-icon entypo-icon-note',
					'icon_linecons' => 'vc_li vc_li-heart',
					'bg_color' => 'green',
					'remove_close' => '',
					'animation' => '',
					'animation_delay' => '200',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		if ( !empty( $animation ) ) {
			$animation = 'eut-' . $animation;
		}

		$message_box_classes = array( 'eut-element', 'eut-message' );

		array_push( $message_box_classes, 'eut-bg-' . $bg_color );

		if ( !empty( $animation ) ) {
			array_push( $message_box_classes, 'eut-animated-item' );
			array_push( $message_box_classes, $animation);
			$data = ' data-delay="' . esc_attr( $animation_delay ) . '"';
		}

		if ( !empty ( $el_class ) ) {
			array_push( $message_box_classes, $el_class);
		}

		$message_box_class_string = implode( ' ', $message_box_classes );


		$icon_class = isset( ${"icon_" . $icon_library} ) ? esc_attr( ${"icon_" . $icon_library} ) : 'fa fa-adjust';
		if ( function_exists( 'vc_icon_element_fonts_enqueue' ) ) {
			vc_icon_element_fonts_enqueue( $icon_library );
		}

		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		$output .= '<div class="' . esc_attr( $message_box_class_string ) . '" style="' . $style . '"' . $data . '>';
		$output .= '  <i class="eut-icon '. esc_attr( $icon_class ) . '"></i>';
		$output .= '  <p>' . do_shortcode( $content ) . '</p>';
		if ( 'yes' != $remove_close ) {
			$output .= '  <i class="eut-close"></i>';
		}
		$output .= '</div>';

		return $output;
	}
	add_shortcode( 'eut_message_box', 'eut_message_box_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_message_box_shortcode_params' ) ) {
	function eut_corpus_vce_message_box_shortcode_params( $tag ) {
		return array(
			"name" => __( "Message Box", "eut-corpus-vc-extension" ),
			"description" => __( "Info text with icons", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-message-box",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					'type' => 'dropdown',
					'heading' => __( 'Icon library', 'eut-corpus-vc-extension' ),
					'value' => array(
						__( 'Font Awesome', 'eut-corpus-vc-extension' ) => 'fontawesome',
						__( 'Open Iconic', 'eut-corpus-vc-extension' ) => 'openiconic',
						__( 'Typicons', 'eut-corpus-vc-extension' ) => 'typicons',
						__( 'Entypo', 'eut-corpus-vc-extension' ) => 'entypo',
						__( 'Linecons', 'eut-corpus-vc-extension' ) => 'linecons',
					),
					'param_name' => 'icon_library',
					'description' => __( 'Select icon library.', 'eut-corpus-vc-extension' ),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'eut-corpus-vc-extension' ),
					'param_name' => 'icon_fontawesome',
					'value' => 'fa fa-info-circle',
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'iconsPerPage' => 200, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'icon_library',
						'value' => 'fontawesome',
					),
					'description' => __( 'Select icon from library.', 'eut-corpus-vc-extension' ),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'eut-corpus-vc-extension' ),
					'param_name' => 'icon_openiconic',
					'value' => 'vc-oi vc-oi-dial',
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'type' => 'openiconic',
						'iconsPerPage' => 200, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'icon_library',
						'value' => 'openiconic',
					),
					'description' => __( 'Select icon from library.', 'eut-corpus-vc-extension' ),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'eut-corpus-vc-extension' ),
					'param_name' => 'icon_typicons',
					'value' => 'typcn typcn-adjust-brightness',
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'type' => 'typicons',
						'iconsPerPage' => 200, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'icon_library',
						'value' => 'typicons',
					),
					'description' => __( 'Select icon from library.', 'eut-corpus-vc-extension' ),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'eut-corpus-vc-extension' ),
					'param_name' => 'icon_entypo',
					'value' => 'entypo-icon entypo-icon-note',
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'type' => 'entypo',
						'iconsPerPage' => 300, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'icon_library',
						'value' => 'entypo',
					),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'eut-corpus-vc-extension' ),
					'param_name' => 'icon_linecons',
					'value' => 'vc_li vc_li-heart',
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'type' => 'linecons',
						'iconsPerPage' => 200, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'icon_library',
						'value' => 'linecons',
					),
					'description' => __( 'Select icon from library.', 'eut-corpus-vc-extension' ),
				),

				array(
					"type" => "textarea",
					"heading" => __( "Text", "eut-corpus-vc-extension" ),
					"param_name" => "content",
					"value" => "Sample Text",
					"description" => __( "Enter your content.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Background Color", "eut-corpus-vc-extension" ),
					"param_name" => "bg_color",
					"value" => array(
						__( "Primary 1", "eut-corpus-vc-extension" ) => 'primary-1',
						__( "Primary 2", "eut-corpus-vc-extension" ) => 'primary-2',
						__( "Primary 3", "eut-corpus-vc-extension" ) => 'primary-3',
						__( "Primary 4", "eut-corpus-vc-extension" ) => 'primary-4',
						__( "Primary 5", "eut-corpus-vc-extension" ) => 'primary-5',
						__( "Green", "eut-corpus-vc-extension" ) => 'green',
						__( "Orange", "eut-corpus-vc-extension" ) => 'orange',
						__( "Red", "eut-corpus-vc-extension" ) => 'red',
						__( "Blue", "eut-corpus-vc-extension" ) => 'blue',
						__( "Aqua", "eut-corpus-vc-extension" ) => 'aqua',
						__( "Purple", "eut-corpus-vc-extension" ) => 'purple',
						__( "Black", "eut-corpus-vc-extension" ) => 'black',
						__( "Grey", "eut-corpus-vc-extension" ) => 'grey',
						__( "White", "eut-corpus-vc-extension" ) => 'white',
					),
					"description" => __( "Background color of the box.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
					'std' => 'green',
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Remove Close Button", "eut-corpus-vc-extension" ),
					"param_name" => "remove_close",
					"value" => Array( __( "If selected, close button will be removed", "eut-corpus-vc-extension" ) => 'yes' ),
				),
				eut_vce_add_animation(),
				eut_vce_add_animation_delay(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_message_box', 'eut_corpus_vce_message_box_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_message_box_shortcode_params( 'eut_message_box' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
