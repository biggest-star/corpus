<?php
/**
 * Testimonial Shortcode
 */

if( !function_exists( 'eut_testimonial_shortcode' ) ) {

	function eut_testimonial_shortcode( $attr, $content ) {

		$portfolio_row_start = $allow_filter = $class_fullwidth = $slider_data = $output = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'categories' => '',
					'exclude_posts' => '',
					'include_posts' => '',
					'testimonial_type' => 'carousel',
					'testimonial_mode' => 'no-shadow-mode',
					'columns' => '3',
					'columns_tablet_landscape' => '2',
					'columns_tablet_portrait' => '2',
					'columns_mobile' => '1',
					'order_by' => 'date',
					'order' => 'DESC',
					'disable_pagination' => '',
					'items_to_show' => '20',
					'margin_bottom' => '',
					'slideshow_speed' => '3000',
					'pagination_speed' => '400',
					'auto_play' => 'yes',
					'pause_hover' => 'no',
					'auto_height' => 'no',
					'align' => 'left',
					'text_style' => 'none',
					'el_class' => '',
				),
				$attr
			)
		);

		$testimonial_classes = array( 'eut-element' );

		if ( !empty ( $el_class ) ) {
			array_push( $testimonial_classes, $el_class);
		}

		switch( $testimonial_type ) {
			case 'masonry':
				$data_string = ' data-columns="' . esc_attr( $columns ) . '" data-columns-tablet-landscape="' . esc_attr( $columns_tablet_landscape ) . '" data-columns-tablet-portrait="' . esc_attr( $columns_tablet_portrait ) . '" data-columns-mobile="' . esc_attr( $columns_mobile ) . '" data-layout="masonry"';
				if ( 'shadow-mode' == $testimonial_mode ) {
					array_push( $testimonial_classes, 'eut-shadow-mode' );
				} else {
					array_push( $testimonial_classes, 'eut-without-shadow' );
				}

				array_push( $testimonial_classes, 'eut-testimonial-grid' );
				array_push( $testimonial_classes, 'eut-isotope' );
				array_push( $testimonial_classes, 'eut-with-gap' );
				break;
			case 'grid':
				$data_string = ' data-columns="' . esc_attr( $columns ) . '" data-columns-tablet-landscape="' . esc_attr( $columns_tablet_landscape ) . '" data-columns-tablet-portrait="' . esc_attr( $columns_tablet_portrait ) . '" data-columns-mobile="' . esc_attr( $columns_mobile ) . '" data-layout="fitRows"';
				if ( 'shadow-mode' == $testimonial_mode ) {
					array_push( $testimonial_classes, 'eut-shadow-mode' );
				} else {
					array_push( $testimonial_classes, 'eut-without-shadow' );
				}

				array_push( $testimonial_classes, 'eut-testimonial-grid' );
				array_push( $testimonial_classes, 'eut-isotope' );
				array_push( $testimonial_classes, 'eut-with-gap' );
				break;
			case 'carousel':
			default:
				$data_string = ' data-slider-autoplay="' . esc_attr( $auto_play ) . '" data-slider-speed="' . esc_attr( $slideshow_speed ) . '" data-slider-pause="' . esc_attr( $pause_hover ) . '" data-pagination-speed="' . esc_attr( $pagination_speed ) . '"';
				array_push( $testimonial_classes, 'eut-testimonial' );
				array_push( $testimonial_classes, 'eut-carousel-element' );
				array_push( $testimonial_classes, 'eut-align-' . $align );
				if ( 'none' != $text_style ) {
					array_push( $testimonial_classes, 'eut-' . $text_style );
				}
				$disable_pagination = 'yes';
				break;

		}


		$testimonial_class_string = implode( ' ', $testimonial_classes );

		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		$testimonial_cat = "";

		if ( !empty( $categories ) ) {
			$testimonial_category_list = explode( ",", $categories );
			foreach ( $testimonial_category_list as $testimonial_list ) {
				$testimonial_term = get_term( $testimonial_list, 'testimonial_category' );
				$testimonial_cat = $testimonial_cat.$testimonial_term->slug . ', ';
			}
		}

		$paged = 1;

		if ( 'yes' != $disable_pagination ) {
			if ( get_query_var( 'paged' ) ) {
				$paged = get_query_var( 'paged' );
			} elseif ( get_query_var( 'page' ) ) {
				$paged = get_query_var( 'page' );
			}
		}

		$exclude_ids = array();
		if( !empty( $exclude_posts ) ){
			$exclude_ids = explode( ',', $exclude_posts );
		}

		$include_ids = array();
		if( !empty( $include_posts ) ){
			$include_ids = explode( ',', $include_posts );
			$args = array(
				'post_type' => 'testimonial',
				'post_status'=>'publish',
				'paged' => $paged,
				'post__in' => $include_ids,
				'posts_per_page' => $items_to_show,
				'orderby' => $order_by,
				'order' => $order,
			);
		} else {
			$args = array(
				'post_type' => 'testimonial',
				'post_status'=>'publish',
				'paged' => $paged,
				'testimonial_category' => $testimonial_cat,
				'post__not_in' => $exclude_ids,
				'posts_per_page' => $items_to_show,
				'orderby' => $order_by,
				'order' => $order,
			);
		}

		$query = new WP_Query( $args );

		ob_start();

		if ( $query->have_posts() ) :

		?>
			<div class="<?php echo esc_attr( $testimonial_class_string ); ?>" style="<?php echo $style; ?>"<?php echo $data_string; ?>>

				<?php if ( 'carousel' != $testimonial_type ) { ?>
				<div class="eut-isotope-container">
				<?php } ?>

		<?php
		while ( $query->have_posts() ) : $query->the_post();

			$name = get_post_meta( get_the_ID(), 'eut_testimonial_name', true );
			$identity =  get_post_meta( get_the_ID(), 'eut_testimonial_identity', true );

			if ( !empty( $name ) && !empty( $identity ) ) {
				$identity = ', ' . $identity;
			}

			if ( 'carousel' == $testimonial_type ) {

		?>
				<div class="eut-testimonial-element">
					<?php the_content(); ?>
					<?php if ( !empty( $name ) || !empty( $identity ) ) { ?>
					<div class="eut-testimonial-name"><?php echo esc_html( $name . $identity ); ?></div>
					<?php } ?>
				</div>
		<?php
			} else {
		?>
				<div class="eut-isotope-item eut-testimonial-item">
					<div class="eut-isotope-item-inner">
						<div class="eut-testimonial-element eut-style-2">
							<div class="eut-container">
								<?php the_content(); ?>
							</div>
							<div class="eut-testimonial-author eut-border eut-border-top">
								<?php if ( !empty( $name ) || !empty( $identity ) ) { ?>
								<div class="eut-small-text eut-heading-color eut-testimonial-name"><?php echo esc_html( $name . $identity ); ?></div>
								<?php } ?>
							</div>
						</div>
					</div>
				</div>

		<?php
			}
		endwhile;

		?>
				<?php if ( 'carousel' != $testimonial_type ) { ?>
				</div>
				<?php } ?>
<?php
			if ( 'yes' != $disable_pagination ) {
				$total = $query->max_num_pages;
				$big = 999999999; // need an unlikely integer
				if( $total > 1 )  {
					 echo '<div class="eut-pagination">';

					 if( get_option('permalink_structure') ) {
						 $format = 'page/%#%/';
					 } else {
						 $format = '&paged=%#%';
					 }
					 echo paginate_links(array(
						'base'			=> str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
						'format'		=> $format,
						'current'		=> max( 1, $paged ),
						'total'			=> $total,
						'mid_size'		=> 2,
						'type'			=> 'list',
						'prev_text'	=> '<i class="eut-icon-nav-left"></i>',
						'next_text'	=> '<i class="eut-icon-nav-right"></i>',
						'add_args' => false,
					 ));
					 echo '</div>';
				}
			}
?>
			</div>

		<?php
		else :
		endif;
		wp_reset_postdata();

		return ob_get_clean();

	}
	add_shortcode( 'eut_testimonial', 'eut_testimonial_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_testimonial_shortcode_params' ) ) {
	function eut_corpus_vce_testimonial_shortcode_params( $tag ) {
		return array(
			"name" => __( "Testimonial", "eut-corpus-vc-extension" ),
			"description" => __( "Add a captivating testimonial slider", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-testimonial",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "dropdown",
					"heading" => __( "Testimonial type", "eut-corpus-vc-extension" ),
					"param_name" => "testimonial_type",
					"value" => array(
						__( "Carousel", "eut-corpus-vc-extension" ) => 'carousel',
						__( "Grid", "eut-corpus-vc-extension" ) => 'grid',
						__( "Masonry", "eut-corpus-vc-extension" ) => 'masonry',
					),
					"description" => __( "Select your testimonial type.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Mode", "eut-corpus-vc-extension" ),
					"param_name" => "testimonial_mode",
					'value' => array(
						__( 'Without Shadow', 'eut-corpus-vc-extension' ) => 'no-shadow-mode',
						__( 'With Shadow', 'eut-corpus-vc-extension' ) => 'shadow-mode',
					),
					"description" => __( "Select your testimonial Mode.", "eut-corpus-vc-extension" ),
					"dependency" => array( 'element' => "testimonial_type", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Columns", "eut-corpus-vc-extension" ),
					"param_name" => "columns",
					"value" => array( '2', '3', '4', '5' ),
					"std" => '3',
					"description" => __( "Select number of columns.", "eut-corpus-vc-extension" ),
					"dependency" => array( 'element' => "testimonial_type", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Tablet Landscape Columns", "eut-corpus-vc-extension" ),
					"param_name" => "columns_tablet_landscape",
					"value" => array( '2', '3', '4', '5' ),
					"std" => '2',
					"description" => __( "Select responsive column on tablet devices, landscape orientation.", "eut-corpus-vc-extension" ),
					"dependency" => array( 'element' => "testimonial_type", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Tablet Portrait Columns", "eut-corpus-vc-extension" ),
					"param_name" => "columns_tablet_portrait",
					"value" => array( '2', '3', '4', '5' ),
					"std" => '2',
					"description" => __( "Select responsive column on tablet devices, portrait orientation.", "eut-corpus-vc-extension" ),
					"dependency" => array( 'element' => "testimonial_type", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Mobile Columns", "eut-corpus-vc-extension" ),
					"param_name" => "columns_mobile",
					"value" => array( '1', '2', '3' ),
					"std" => '1',
					"description" => __( "Select responsive column on mobile devices.", "eut-corpus-vc-extension" ),
					"dependency" => array( 'element' => "testimonial_type", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Disable Pagination", "eut-corpus-vc-extension" ),
					"param_name" => "disable_pagination",
					"description" => __( "If selected, pagination will not be shown.", "eut-corpus-vc-extension" ),
					"value" => array( __( "Disable Pagination.", "eut-corpus-vc-extension" ) => 'yes' ),
					"dependency" => array( 'element' => "testimonial_type", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Items to show", "eut-corpus-vc-extension" ),
					"param_name" => "items_to_show",
					"value" => '20',
					"description" => __( "Maximum Testimonial Items to Show", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Autoplay", "eut-corpus-vc-extension" ),
					"param_name" => "auto_play",
					"value" => array(
						__( "Yes", "eut-corpus-vc-extension" ) => 'yes',
						__( "No", "eut-corpus-vc-extension" ) => 'no',
					),
					"dependency" => array( 'element' => "testimonial_type", 'value' => array( 'carousel' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Slideshow Speed", "eut-corpus-vc-extension" ),
					"param_name" => "slideshow_speed",
					"value" => '3000',
					"description" => __( "Slideshow Speed in ms.", "eut-corpus-vc-extension" ),
					"dependency" => array( 'element' => "testimonial_type", 'value' => array( 'carousel' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Pagination Speed", "eut-corpus-vc-extension" ),
					"param_name" => "pagination_speed",
					"value" => '400',
					"description" => __( "Pagination Speed in ms.", "eut-corpus-vc-extension" ),
					"dependency" => array( 'element' => "testimonial_type", 'value' => array( 'carousel' ) ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Pause on Hover", "eut-corpus-vc-extension" ),
					"param_name" => "pause_hover",
					"value" => Array( __( "If selected, testimonial will be paused on hover", "eut-corpus-vc-extension" ) => 'yes' ),
					"dependency" => array( 'element' => "testimonial_type", 'value' => array( 'carousel' ) ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Auto Height", "eut-corpus-vc-extension" ),
					"param_name" => "auto_height",
					"value" => array( __( "Select if you want smooth auto height", "eut-corpus-vc-extension" ) => 'yes' ),
					"dependency" => array( 'element' => "testimonial_type", 'value' => array( 'carousel' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Text Style", "eut-corpus-vc-extension" ),
					"param_name" => "text_style",
					"value" => array(
						__( "None", "eut-corpus-vc-extension" ) => '',
						__( "Leader", "eut-corpus-vc-extension" ) => 'leader-text',
						__( "Subtitle", "eut-corpus-vc-extension" ) => 'subtitle',
					),
					"description" => 'Select your text style',
					"dependency" => array( 'element' => "testimonial_type", 'value' => array( 'carousel' ) ),
				),
				eut_vce_add_order_by(),
				eut_vce_add_order(),
				array(
					"type" => "dropdown",
					"heading" => __( "Alignment", "eut-corpus-vc-extension" ),
					"param_name" => "align",
					"value" => array(
						__( "Left", "eut-corpus-vc-extension" ) => 'left',
						__( "Right", "eut-corpus-vc-extension" ) => 'right',
						__( "Center", "eut-corpus-vc-extension" ) => 'center',
					),
					"description" => '',
					"dependency" => array( 'element' => "testimonial_type", 'value' => array( 'carousel' ) ),
				),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
				array(
					"type" => "textfield",
					"heading" => __("Exclude Posts", "eut-corpus-vc-extension" ),
					"param_name" => "exclude_posts",
					"value" => '',
					"description" => __( "Type the post ids you want to exclude separated by comma ( , ).", "eut-corpus-vc-extension" ),
					"group" => __( "Categories", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "eut_multi_checkbox",
					"heading" => __("Testimonial Categories", "eut-corpus-vc-extension" ),
					"param_name" => "categories",
					"value" => eut_corpus_vce_get_testimonial_categories(),
					"description" => __( "Select all or multiple categories.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
					"group" => __( "Categories", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __("Include Specific Posts", "eut-corpus-vc-extension" ),
					"param_name" => "include_posts",
					"value" => '',
					"description" => __( "Type the specific post ids you want to include separated by comma ( , ). Note: If you define specific post ids, Exclude Posts and Categories will have no effect.", "eut-corpus-vc-extension" ),
					"group" => __( "Categories", "eut-corpus-vc-extension" ),
				),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_testimonial', 'eut_corpus_vce_testimonial_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_testimonial_shortcode_params( 'eut_testimonial' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
