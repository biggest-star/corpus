<?php
/**
 * Google Map Shortcode
 */

if( !function_exists( 'eut_gmap_shortcode' ) ) {

	function eut_gmap_shortcode( $atts, $content ) {
		$output = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'map_lat' => '51.516221',
					'map_lng' => '-0.136986',
					'map_height' => '280',
					'map_marker' => '',
					'map_zoom' => '14',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		wp_enqueue_script( 'eut-googleapi-script' );
		wp_enqueue_script( 'eut-maps-script' );

		$gmap_classes = array( 'eut-element', 'eut-map' );

		if ( !empty ( $el_class ) ) {
			array_push( $gmap_classes, $el_class );
		}
		$gmap_class_string = implode( ' ', $gmap_classes );

		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );
		if ( empty( $map_marker ) ) {
			$map_marker = get_template_directory_uri() . '/images/markers/markers.png';
		} else {
			$id = preg_replace('/[^\d]/', '', $map_marker);
			$full_src = wp_get_attachment_image_src( $id, 'full' );
			$map_marker = $full_src[0];
		}

		$map_title = '';

		$data_map = 'data-lat="' . esc_attr( $map_lat ) . '" data-lng="' . esc_attr( $map_lng ) . '" data-zoom="' . esc_attr( $map_zoom ) . '"';
		$output .= '<div class="eut-map-wrapper">';
		$output .= '  <div style="display:none" class="eut-map-point" data-point-lat="' . esc_attr( $map_lat ) . '" data-point-lng="' . esc_attr( $map_lng ) . '" data-point-marker="' . esc_attr( $map_marker ) . '" data-point-title="' . esc_attr( $map_title ) . '"></div>';
		$output .= '  <div class="' . esc_attr( $gmap_class_string ) . '" ' . $data_map . ' style="' . $style . eut_corpus_vce_build_dimension( 'height', $map_height ) . '">';
		$output .= apply_filters( 'eut_privacy_gmap_fallback', '', $map_lat, $map_lng );
		$output .= '</div>';
		$output .= '</div>';


		return $output;
	}
	add_shortcode( 'eut_gmap', 'eut_gmap_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_gmap_shortcode_params' ) ) {
	function eut_corpus_vce_gmap_shortcode_params( $tag ) {
		return array(
			"name" => __( "Google Map", "eut-corpus-vc-extension" ),
			"description" => __( "Freely place your Google Map", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-gmap",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "textfield",
					"heading" => __( "Map Latitude", "eut-corpus-vc-extension" ),
					"param_name" => "map_lat",
					"value" => "51.516221",
					"description" => __( "Type map Latitude.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "textfield",
					"heading" => __( "Map Longtitude", "eut-corpus-vc-extension" ),
					"param_name" => "map_lng",
					"value" => "-0.136986",
					"description" => __( "Type map Longtitude.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Map Zoom", "eut-corpus-vc-extension" ),
					"param_name" => "map_zoom",
					"value" => array( '1', '2', '3' ,'4', '5', '6', '7', '8' ,'9' ,'10' ,'11' ,'12', '13', '14', '15', '16', '17', '18', '19' ),
					"std" => '14',
					"description" => __( "Zoom of the map.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "textfield",
					"heading" => __( "Map Height", "eut-corpus-vc-extension" ),
					"param_name" => "map_height",
					"value" => "280",
					"description" => __( "Type map height.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "attach_image",
					"heading" => __( "Custom marker", "eut-corpus-vc-extension" ),
					"param_name" => "map_marker",
					"value" => '',
					"description" => __( "Select an icon for custom marker.", "eut-corpus-vc-extension" ),
				),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_gmap', 'eut_corpus_vce_gmap_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_gmap_shortcode_params( 'eut_gmap' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
