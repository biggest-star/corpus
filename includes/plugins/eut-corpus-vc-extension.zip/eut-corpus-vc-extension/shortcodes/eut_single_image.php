<?php
/**
* Single Image Shortcode
*/

if( !function_exists( 'eut_single_image_shortcode' ) ) {

	function eut_single_image_shortcode( $attr, $content ) {

		$output = $data = $retina_data = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'image_mode' => '',
					'image' => '',
					'retina_image' => '',
					'image_type' => 'image',
					'image_hover_style' => 'hover-style-1',
					'custom_title' => '',
					'custom_caption' => '',
					'zoom_effect' => 'in',
					'overlay_color' => 'dark',
					'overlay_opacity' => '80',
					'align' => 'center',
					'link' => '',
					'video_link' => '',
					'animation' => '',
					'animation_delay' => '200',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$attr
			)
		);

		if ( !empty( $animation ) ) {
			$animation = 'eut-' . $animation;
		}

		if ( !empty( $link ) ){
			$href = vc_build_link( $link );
			$url = $href['url'];
			if ( !empty( $href['target'] ) ){
				$target = $href['target'];
			} else {
				$target = "_self";
			}
		} else {
			$url = "#";
			$target = "_self";
		}
		$target = trim( $target );

		$single_image_classes = array( 'eut-element', 'eut-image' );

		if ( !empty( $animation ) ) {
			array_push( $single_image_classes, 'eut-animated-item' );
			array_push( $single_image_classes, $animation);
			$data = ' data-delay="' . esc_attr( $animation_delay ) . '"';
		}
		if ( !empty( $el_class ) ) {
			array_push( $single_image_classes, $el_class);
		}
		if ( 'image-caption' != $image_type ) {
			array_push( $single_image_classes, 'eut-align-' . $align );
		}
		$single_image_classe_string = implode( ' ', $single_image_classes );

		$image_mode_size = eut_corpus_vce_get_image_size( $image_mode );

		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		$output .= '<div class="' . esc_attr( $single_image_classe_string ) . '" style="' . $style . '"' . $data . '>';

		if ( !empty( $image ) ) {
			$id = preg_replace('/[^\d]/', '', $image);
			$image_link_href =  wp_get_attachment_url( $id );
			$img_src = wp_get_attachment_image_src( $id, $image_mode_size );
			$img_url = $img_src[0];
			$image_srcset = '';

			$full_src = wp_get_attachment_image_src( $id, 'eut-image-fullscreen' );
			if ( !empty( $retina_image ) && empty( $image_mode ) ) {
				$img_retina_id = preg_replace('/[^\d]/', '', $retina_image);
				$img_retina_src = wp_get_attachment_image_src( $img_retina_id, 'full' );
				$retina_url = $img_retina_src[0];
				$image_srcset = esc_url( $img_url ) . ' 1x,' . esc_url( $retina_url ) . ' 2x';
				$image_html = wp_get_attachment_image( $id, 'full' , "", array( 'srcset'=> $image_srcset ) );
			} else {
				$image_html = wp_get_attachment_image( $id, $image_mode_size );
			}

			if ( 'image-popup' == $image_type ) {
				$output .= '<a class="eut-image-popup" href="' . esc_url( $full_src[0] ) . '">';
				$output .= $image_html;
				$output .= '</a>';
			} else if ( 'image-link' == $image_type ) {
				$output .= '<a href="' . esc_url( $url ) . '" target="' . esc_attr( $target ) . '">';
				$output .= $image_html;
				$output .= '</a>';
			} else if ( 'image-video-popup' == $image_type ) {
				if ( !empty( $video_link ) ) {
					$output .= '<div class="eut-media">';
					$output .= '	<a class="eut-vimeo-popup eut-icon-video" href="' . esc_url( $video_link ) . '">';
					$output .= $image_html;
					$output .= '	</a>';
					$output .= '</div>';
				} else {
					$output .= '<div class="eut-media">';
					$output .= $image_html;
					$output .= '</div>';
				}
			} else if ( 'image-caption' == $image_type ) {
				if ( !empty( $url ) && '#' != $url ) {
				$output .= '<a href="' . esc_url( $url ) . '" target="' . esc_attr( $target ) . '">';
				}
				$output .= '  <figure class="eut-' . esc_attr( $image_hover_style ) . ' eut-image-hover eut-zoom-' . esc_attr( $zoom_effect ) . '">';
				$output .= '    <div class="eut-media eut-' . esc_attr( $overlay_color ) . '-overlay eut-opacity-' . esc_attr( $overlay_opacity ) . '">';
				$output .= $image_html;
				$output .= '    </div>';
				$output .= '      <figcaption>';
					if ( !empty( $custom_title ) ) {
						$output .= '<h6 class="eut-title eut-' . esc_attr( $overlay_color ) . '">' . $custom_title . '</h6>';
					}
					if ( !empty( $custom_caption ) ) {
						$output .= '<span class="eut-caption eut-' . esc_attr( $overlay_color ) . '">' . $custom_caption . '</span>';
					}

				$output .= '      </figcaption>';
				$output .= '  </figure>';
				if ( !empty( $url ) && '#' != $url ) {
				$output .= '</a>';
				}
			} else {
				$output .= $image_html;
			}
		}

		$output .= '</div>';

		return $output;

	}
	add_shortcode( 'eut_single_image', 'eut_single_image_shortcode' );

}

/**
* Add shortcode to Visual Composer
*/

if( !function_exists( 'eut_corpus_vce_single_image_shortcode_params' ) ) {
	function eut_corpus_vce_single_image_shortcode_params( $tag ) {
		return array(
			"name" => __( "Single Image", "eut-corpus-vc-extension" ),
			"description" => __( "Image or Video popup in various uses", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-single-image",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "dropdown",
					"heading" => __( "Type", "eut-corpus-vc-extension" ),
					"param_name" => "image_type",
					"value" => array(
						__( "Image", "eut-corpus-vc-extension" ) => 'image',
						__( "Image Link", "eut-corpus-vc-extension" ) => 'image-link',
						__( "Image Popup", "eut-corpus-vc-extension" ) => 'image-popup',
						__( "Image Video Popup", "eut-corpus-vc-extension" ) => 'image-video-popup',
						__( "Image With Caption", "eut-corpus-vc-extension" ) => 'image-caption',
					),
					"description" => __( "Select your image type.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Image Mode", "eut-corpus-vc-extension" ),
					"param_name" => "image_mode",
					'value' => array(
						__( 'Full ( Custom )', 'eut-corpus-vc-extension' ) => '',
						__( 'Thumbnail', 'eut-corpus-vc-extension' ) => 'thumbnail',
						__( 'Medium ( Resize )', 'eut-corpus-vc-extension' ) => 'medium',
						__( 'Large ( Resize )', 'eut-corpus-vc-extension' ) => 'large',
						__( 'Square ( Crop )', 'eut-corpus-vc-extension' ) => 'square',
						__( 'Landscape ( Crop )', 'eut-corpus-vc-extension' ) => 'landscape',
						__( 'Landscape Wide ( Crop )', 'eut-corpus-vc-extension' ) => 'landscape-wide',
						__( 'Portrait ( Crop )', 'eut-corpus-vc-extension' ) => 'portrait',
					),
					'std' => '',
					"description" => __( "Select your Image Mode.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "attach_image",
					"heading" => __( "Image", "eut-corpus-vc-extension" ),
					"param_name" => "image",
					"value" => '',
					"description" => __( "Select an image.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "attach_image",
					"heading" => __( "Retina Image", "eut-corpus-vc-extension" ),
					"param_name" => "retina_image",
					"value" => '',
					"description" => __( "Select a 2x image.", "eut-corpus-vc-extension" ),
					"dependency" => array( 'element' => "image_mode", 'value' => array( '' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Alignment", "eut-corpus-vc-extension" ),
					"param_name" => "align",
					"value" => array(
						__( "Left", "eut-corpus-vc-extension" ) => 'left',
						__( "Right", "eut-corpus-vc-extension" ) => 'right',
						__( "Center", "eut-corpus-vc-extension" ) => 'center',
					),
					"dependency" => Array( 'element' => "image_type", 'value' => array( 'image', 'image-link', 'image-popup', 'image-video-popup') ),
					"std" => 'center',
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Hover Style", "eut-corpus-vc-extension" ),
					"param_name" => "image_hover_style",
					'value' => array(
						__( 'Style 1' , 'eut-corpus-vc-extension' ) => 'hover-style-1',
						__( 'Style 2' , 'eut-corpus-vc-extension' ) => 'hover-style-2',
					),
					"description" => __( "Select hover style for image items.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "image_type", 'value' => array( 'image-caption' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Title", "eut-corpus-vc-extension" ),
					"param_name" => "custom_title",
					"value" => "",
					"description" => __( "Enter your title.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
					"dependency" => Array( 'element' => "image_type", 'value' => array( 'image-caption' ) ),
				),
				array(
					"type" => "textarea",
					"heading" => __( "Caption", "eut-corpus-vc-extension" ),
					"param_name" => "custom_caption",
					"value" => "",
					"description" => __( "Enter your caption.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "image_type", 'value' => array( 'image-caption' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Image Zoom Effect", "eut-corpus-vc-extension" ),
					"param_name" => "zoom_effect",
					"value" => array(
						__( "Zoom In", "eut-corpus-vc-extension" ) => 'in',
						__( "Zoom Out", "eut-corpus-vc-extension" ) => 'out',
						__( "None", "eut-corpus-vc-extension" ) => 'none',
					),
					"description" => __( "Choose the image zoom effect.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "image_type", 'value' => array( 'image-caption' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Overlay Color", "eut-corpus-vc-extension" ),
					"param_name" => "overlay_color",
					"value" => array(
						__( "Dark", "eut-corpus-vc-extension" ) => 'dark',
						__( "Light", "eut-corpus-vc-extension" ) => 'light',
						__( "Primary 1", "eut-corpus-vc-extension" ) => 'primary-1',
						__( "Primary 2", "eut-corpus-vc-extension" ) => 'primary-2',
						__( "Primary 3", "eut-corpus-vc-extension" ) => 'primary-3',
						__( "Primary 4", "eut-corpus-vc-extension" ) => 'primary-4',
						__( "Primary 5", "eut-corpus-vc-extension" ) => 'primary-5',
					),
					"description" => __( "Choose the image color overlay.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "image_type", 'value' => array( 'image-caption' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Overlay Opacity", "eut-corpus-vc-extension" ),
					"param_name" => "overlay_opacity",
					"value" => array( '0', '10', '20', '30', '40', '50', '60', '70', '80', '90', '100' ),
					"std" => '80',
					"description" => __( "Choose the opacity for the overlay.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "image_type", 'value' => array( 'image-caption' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Video Link", "eut-corpus-vc-extension" ),
					"param_name" => "video_link",
					"value" => "",
					"description" => __( "Type video URL e.g Vimeo/YouTube.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "image_type", 'value' => array( 'image-video-popup') ),
				),
				array(
					"type" => "vc_link",
					"heading" => __( "Link", "eut-corpus-vc-extension" ),
					"param_name" => "link",
					"value" => "",
					"description" => __( "Enter link.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "image_type", 'value' => array( 'image-link', 'image-caption' ) ),
				),
				eut_vce_add_animation(),
				eut_vce_add_animation_delay(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_single_image', 'eut_corpus_vce_single_image_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_single_image_shortcode_params( 'eut_single_image' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
