<?php
/**
 * Slogan Shortcode
 */

if( !function_exists( 'eut_slogan_shortcode' ) ) {

	function eut_slogan_shortcode( $atts, $content ) {

		$output = $data = $el_class = $text_style_class = '';

		extract(
			shortcode_atts(
				array(
					'title' => '',
					'heading' => 'h1',
					'line_type' => 'no-line',
					'subtitle' => '',
					'button_text' => '',
					'button_link' => '',
					'button_type' => 'simple',
					'button_size' => 'medium',
					'button_color' => 'primary-1',
					'button_shape' => 'square',
					'button_class' => '',
					'button2_text' => '',
					'button2_link' => '',
					'button2_type' => 'simple',
					'button2_size' => 'medium',
					'button2_color' => 'primary-1',
					'button2_shape' => 'square',
					'button2_class' => '',
					'text_style' => 'none',
					'align' => 'left',
					'animation' => '',
					'animation_delay' => '200',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		if ( !empty( $animation ) ) {
			$animation = 'eut-' . $animation;
		}

		//Title
		if ( !empty( $title ) ) {
			//Title Classes
			$title_classes = array( 'eut-slogan-title' );

			array_push( $title_classes, 'eut-align-' . $align );
			array_push( $title_classes, 'eut-title-' . $line_type );

			$title_class_string = implode( ' ', $title_classes );
		}

		//Slogan
		$slogan_classes = array( 'eut-element', 'eut-slogan', 'eut-align-' . $align );

		if ( !empty( $animation ) ) {
			array_push( $slogan_classes, 'eut-animated-item' );
			array_push( $slogan_classes, $animation);
			$data = ' data-delay="' . esc_attr( $animation_delay ) . '"';
		}
		if ( !empty( $el_class ) ) {
			array_push( $slogan_classes, $el_class);
		}
		$slogan_class_string = implode( ' ', $slogan_classes );

		// Paragraph
		if ( 'none' != $text_style ) {
			$text_style_class = 'eut-' .$text_style;
		}

		//First Button
		$button1 = eut_corpus_vce_get_button( $button_text, $button_link, $button_type, $button_size, $button_color, $button_shape, $button_class );
		//Second Button
		$button2 = eut_corpus_vce_get_button( $button2_text, $button2_link, $button2_type, $button2_size, $button2_color, $button2_shape, $button2_class );

		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		$output .= '<div class="' . esc_attr( $slogan_class_string ) . '" style="' . $style. '"' . $data . '>';
		if ( !empty( $subtitle ) ) {
			$output .= '<div class="eut-subtitle">' . $subtitle . '</div>';
		}
		if ( !empty( $title ) ) {
			$output .= '<' . $heading . ' class="' . esc_attr( $title_class_string ) . '"><span>' . $title . '</span></' . $heading . '>';
		}
		if ( !empty( $content ) ) {
			$output .= '  <p class="' . esc_attr( $text_style_class ) . '">' . $content . '</p>';
		}

		if ( !empty( $button1 ) || !empty( $button2 ) ) {
			$output .= '<div class="eut-btn-wrapper">';
			$output .= $button1;
			$output .= $button2;
			$output .= '</div>';
		}
		$output .= '</div>';

		return $output;
	}
	add_shortcode( 'eut_slogan', 'eut_slogan_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_slogan_shortcode_params' ) ) {
	function eut_corpus_vce_slogan_shortcode_params( $tag ) {
		return array(
			"name" => __( "Slogan", "eut-corpus-vc-extension" ),
			"description" => __( "Create easily appealing slogans", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-slogan",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "textfield",
					"heading" => __( "Title", "eut-corpus-vc-extension" ),
					"param_name" => "title",
					"value" => "Sample Title",
					"description" => __( "Enter your title here.", "eut-corpus-vc-extension" ),
					"save_always" => true,
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Heading", "eut-corpus-vc-extension" ),
					"param_name" => "heading",
					"admin_label" => true,
					"value" => array( 'h1', 'h2', 'h3', 'h4' , 'h5', 'h6' ),
					"description" => __( "Heading size of the title", "eut-corpus-vc-extension" ),
					"std" => 'h1',
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Line type", "eut-corpus-vc-extension" ),
					"param_name" => "line_type",
					"value" => array(
						__( "None", "eut-corpus-vc-extension" ) => 'no-line',
						__( "Simple", "eut-corpus-vc-extension" ) => 'line',
						__( "Double", "eut-corpus-vc-extension" ) => 'double-line',
						__( "Double Bottom", "eut-corpus-vc-extension" ) => 'double-bottom-line',
					),
					"description" => __( "Line Type of the title.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Sub-Title", "eut-corpus-vc-extension" ),
					"param_name" => "subtitle",
					"value" => "",
					"description" => __( "Enter your sub-title here.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "textarea",
					"heading" => __( "Text", "eut-corpus-vc-extension" ),
					"param_name" => "content",
					"value" => "",
					"description" => __( "Type your text.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Text Style", "eut-corpus-vc-extension" ),
					"param_name" => "text_style",
					"value" => array(
						__( "None", "eut-corpus-vc-extension" ) => '',
						__( "Leader", "eut-corpus-vc-extension" ) => 'leader-text',
						__( "Subtitle", "eut-corpus-vc-extension" ) => 'subtitle',
					),
					"description" => 'Select your text style',
				),
				array(
					"type" => "dropdown",
					"heading" => __( "First Button type", "eut-corpus-vc-extension" ),
					"param_name" => "button_type",
					"value" => array(
						__( "Simple", "eut-corpus-vc-extension" ) => 'simple',
						__( "Outline", "eut-corpus-vc-extension" ) => 'outline',
					),
					"description" => __( "Select button type.", "eut-corpus-vc-extension" ),
					"group" => __( "First Button", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "First Button Color", "eut-corpus-vc-extension" ),
					"param_name" => "button_color",
					"value" => array(
						__( "Primary 1", "eut-corpus-vc-extension" ) => 'primary-1',
						__( "Primary 2", "eut-corpus-vc-extension" ) => 'primary-2',
						__( "Primary 3", "eut-corpus-vc-extension" ) => 'primary-3',
						__( "Primary 4", "eut-corpus-vc-extension" ) => 'primary-4',
						__( "Primary 5", "eut-corpus-vc-extension" ) => 'primary-5',
						__( "Green", "eut-corpus-vc-extension" ) => 'green',
						__( "Orange", "eut-corpus-vc-extension" ) => 'orange',
						__( "Red", "eut-corpus-vc-extension" ) => 'red',
						__( "Blue", "eut-corpus-vc-extension" ) => 'blue',
						__( "Aqua", "eut-corpus-vc-extension" ) => 'aqua',
						__( "Purple", "eut-corpus-vc-extension" ) => 'purple',
						__( "Black", "eut-corpus-vc-extension" ) => 'black',
						__( "Grey", "eut-corpus-vc-extension" ) => 'grey',
						__( "White", "eut-corpus-vc-extension" ) => 'white',
					),
					"description" => __( "Color of the button.", "eut-corpus-vc-extension" ),
					"group" => __( "First Button", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "First Button Text", "eut-corpus-vc-extension" ),
					"param_name" => "button_text",
					"value" => "",
					"description" => __( "Leave this field empty if you don't want to show this button.", "eut-corpus-vc-extension" ),
					"group" => __( "First Button", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "First Button Size", "eut-corpus-vc-extension" ),
					"param_name" => "button_size",
					"value" => array(
						__( "Extra Small", "eut-corpus-vc-extension" ) => 'extrasmall',
						__( "Small", "eut-corpus-vc-extension" ) => 'small',
						__( "Medium", "eut-corpus-vc-extension" ) => 'medium',
						__( "Large", "eut-corpus-vc-extension" ) => 'large',
						__( "Extra Large", "eut-corpus-vc-extension" ) => 'extralarge',
					),
					"description" => '',
					"std" => 'medium',
					"admin_label" => true,
					"group" => __( "First Button", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "First Button Shape", "eut-corpus-vc-extension" ),
					"param_name" => "button_shape",
					"value" => array(
						__( "Square", "eut-corpus-vc-extension" ) => 'square',
						__( "Round", "eut-corpus-vc-extension" ) => 'round',
						__( "Extra Round", "eut-corpus-vc-extension" ) => 'extra-round',
					),
					"description" => '',
					"std" => 'square',
					"group" => __( "First Button", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "vc_link",
					"heading" => __( "First Button Link", "eut-corpus-vc-extension" ),
					"param_name" => "button_link",
					"value" => "",
					"description" => __( "Enter a link for your button.", "eut-corpus-vc-extension" ),
					"group" => __( "First Button", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "First Button class name", "eut-corpus-vc-extension" ),
					"param_name" => "button_class",
					"description" => __( "If you wish to style your button differently, then use this field to add a class name and then refer to it in your css file.", "eut-corpus-vc-extension" ),
					"group" => __( "First Button", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Second Button type", "eut-corpus-vc-extension" ),
					"param_name" => "button2_type",
					"value" => array(
						__( "Simple", "eut-corpus-vc-extension" ) => 'simple',
						__( "Outline", "eut-corpus-vc-extension" ) => 'outline',
					),
					"description" => __( "Select button type.", "eut-corpus-vc-extension" ),
					"group" => __( "Second Button", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Second Button Color", "eut-corpus-vc-extension" ),
					"param_name" => "button2_color",
					"value" => array(
						__( "Primary 1", "eut-corpus-vc-extension" ) => 'primary-1',
						__( "Primary 2", "eut-corpus-vc-extension" ) => 'primary-2',
						__( "Primary 3", "eut-corpus-vc-extension" ) => 'primary-3',
						__( "Primary 4", "eut-corpus-vc-extension" ) => 'primary-4',
						__( "Primary 5", "eut-corpus-vc-extension" ) => 'primary-5',
						__( "Green", "eut-corpus-vc-extension" ) => 'green',
						__( "Orange", "eut-corpus-vc-extension" ) => 'orange',
						__( "Red", "eut-corpus-vc-extension" ) => 'red',
						__( "Blue", "eut-corpus-vc-extension" ) => 'blue',
						__( "Aqua", "eut-corpus-vc-extension" ) => 'aqua',
						__( "Purple", "eut-corpus-vc-extension" ) => 'purple',
						__( "Black", "eut-corpus-vc-extension" ) => 'black',
						__( "Grey", "eut-corpus-vc-extension" ) => 'grey',
						__( "White", "eut-corpus-vc-extension" ) => 'white',
					),
					"description" => __( "Color of the button.", "eut-corpus-vc-extension" ),
					"group" => __( "Second Button", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Second Button Text", "eut-corpus-vc-extension" ),
					"param_name" => "button2_text",
					"value" => "",
					"description" => __( "Leave this field empty if you don't want to show this button.", "eut-corpus-vc-extension" ),
					"group" => __( "Second Button", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Second Button Size", "eut-corpus-vc-extension" ),
					"param_name" => "button2_size",
					"value" => array(
						__( "Extra Small", "eut-corpus-vc-extension" ) => 'extrasmall',
						__( "Small", "eut-corpus-vc-extension" ) => 'small',
						__( "Medium", "eut-corpus-vc-extension" ) => 'medium',
						__( "Large", "eut-corpus-vc-extension" ) => 'large',
						__( "Extra Large", "eut-corpus-vc-extension" ) => 'extralarge',
					),
					"description" => '',
					"std" => 'medium',
					"admin_label" => true,
					"group" => __( "Second Button", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Button Shape", "eut-corpus-vc-extension" ),
					"param_name" => "button2_shape",
					"value" => array(
						__( "Square", "eut-corpus-vc-extension" ) => 'square',
						__( "Round", "eut-corpus-vc-extension" ) => 'round',
						__( "Extra Round", "eut-corpus-vc-extension" ) => 'extra-round',
					),
					"description" => '',
					"std" => 'square',
					"group" => __( "Second Button", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "vc_link",
					"heading" => __( "Second Button Link", "eut-corpus-vc-extension" ),
					"param_name" => "button2_link",
					"value" => "",
					"description" => __( "Enter a link for your button.", "eut-corpus-vc-extension" ),
					"group" => __( "Second Button", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Second Button class name", "eut-corpus-vc-extension" ),
					"param_name" => "button2_class",
					"description" => __( "If you wish to style your button differently, then use this field to add a class name and then refer to it in your css file.", "eut-corpus-vc-extension" ),
					"group" => __( "Second Button", "eut-corpus-vc-extension" ),
				),
				eut_vce_add_align(),
				eut_vce_add_animation(),
				eut_vce_add_animation_delay(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_slogan', 'eut_corpus_vce_slogan_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_slogan_shortcode_params( 'eut_slogan' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
