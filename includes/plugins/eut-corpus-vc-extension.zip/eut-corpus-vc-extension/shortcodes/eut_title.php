<?php
/**
 * Title Shortcode
 */

if( !function_exists( 'eut_title_shortcode' ) ) {

	function eut_title_shortcode( $atts, $content ) {

		$output = $data = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'title' => '',
					'heading' => 'h3',
					'line_type' => 'no-line',
					'align' => 'left',
					'animation' => '',
					'animation_delay' => '200',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		if ( !empty( $animation ) ) {
			$animation = 'eut-' . $animation;
		}

		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		$title_classes = array( 'eut-element' );

		array_push( $title_classes, 'eut-align-' . $align );
		array_push( $title_classes, 'eut-title-' . $line_type );


		if ( !empty( $animation ) ) {
			array_push( $title_classes, 'eut-animated-item' );
			array_push( $title_classes, $animation);
			$data = ' data-delay="' . esc_attr( $animation_delay ) . '"';
		}

		if ( !empty( $el_class ) ) {
			array_push( $title_classes, $el_class );
		}

		$title_class_string = implode( ' ', $title_classes );

		$output .= '<' . $heading . ' class="' . esc_attr( $title_class_string ) . '" style="' . $style . '"' . $data . '><span>' . $title . '</span></' . $heading . '>';

		return $output;
	}
	add_shortcode( 'eut_title', 'eut_title_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_title_shortcode_params' ) ) {
	function eut_corpus_vce_title_shortcode_params( $tag ) {
		return array(
			"name" => __( "Title", "eut-corpus-vc-extension" ),
			"description" => __( "Add a title in many and diverse ways", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-title",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "textfield",
					"heading" => __( "Title", "eut-corpus-vc-extension" ),
					"param_name" => "title",
					"value" => "Sample Title",
					"description" => __( "Enter your title here.", "eut-corpus-vc-extension" ),
					"save_always" => true,
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Heading", "eut-corpus-vc-extension" ),
					"param_name" => "heading",
					"admin_label" => true,
					"value" => array( 'h1', 'h2', 'h3', 'h4' , 'h5', 'h6' ),
					"description" => __( "Heading size", "eut-corpus-vc-extension" ),
					"std" => "h3",
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Line type", "eut-corpus-vc-extension" ),
					"param_name" => "line_type",
					"value" => array(
						__( "None", "eut-corpus-vc-extension" ) => 'no-line',
						__( "Simple", "eut-corpus-vc-extension" ) => 'line',
						__( "Double", "eut-corpus-vc-extension" ) => 'double-line',
						__( "Double Bottom", "eut-corpus-vc-extension" ) => 'double-bottom-line',
					),
					"description" => '',
				),
				eut_vce_add_align(),
				eut_vce_add_animation(),
				eut_vce_add_animation_delay(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_title', 'eut_corpus_vce_title_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_title_shortcode_params( 'eut_title' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
