<?php
/**
 * Callout Shortcode
 */

if( !function_exists( 'eut_calout_shortcode' ) ) {

	function eut_calout_shortcode( $atts, $content ) {

		$output = $button = $data = $class_leader = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'title' => '',
					'heading' => 'h3',
					'button_text' => '',
					'button_link' => '',
					'button_type' => 'simple',
					'btn_position' => 'btn-right',
					'button_size' => 'medium',
					'button_color' => 'primary-1',
					'button_shape' => 'square',
					'button_class' => '',
					'leader_text' => '',
					'animation' => '',
					'animation_delay' => '200',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		if ( !empty( $animation ) ) {
			$animation = 'eut-' . $animation;
		}

		if ( 'yes' == $leader_text ) {
			$class_leader = 'eut-leader-text';
		}

		//Button
		$button = eut_corpus_vce_get_button( $button_text, $button_link, $button_type, $button_size, $button_color, $button_shape, $button_class );

		$callout_classes = array( 'eut-element', 'eut-callout' );

		if ( !empty( $animation ) ) {
			array_push( $callout_classes, 'eut-animated-item' );
			array_push( $callout_classes, $animation);
			$data = ' data-delay="' . esc_attr( $animation_delay ) . '"';
		}

		if ( !empty ( $el_class ) ) {
			array_push( $callout_classes, $el_class);
		}

		array_push( $callout_classes, 'eut-' . $btn_position );

		$callout_class_string = implode( ' ', $callout_classes );

		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		$output .= '<div class="' . esc_attr( $callout_class_string ) . '" style="' . $style . '">';
		$output .= '  <div class="eut-callout-wrapper">';
		if ( !empty( $title ) ) {
			$output .= '<' . $heading . ' class="eut-callout-content">' . $title . '</' . $heading . '>';
		}
		if ( !empty( $content ) ) {
		$output .= '    <p class="'. esc_attr( $class_leader ) . '">' . $content. '</p>';
		}
		$output .= '  </div>';
		$output .= '  <div class="eut-button-wrapper">';
		$output .= $button;
		$output .= '  </div>';
		$output .= '</div>';

		return $output;
	}
	add_shortcode( 'eut_callout', 'eut_calout_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_callout_shortcode_params' ) ) {
	function eut_corpus_vce_callout_shortcode_params( $tag ) {
		return array(
			"name" => __( "Callout", "eut-corpus-vc-extension" ),
			"description" => __( "Two different styles for interesting callouts", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-callout",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "textfield",
					"heading" => __( "Title", "eut-corpus-vc-extension" ),
					"param_name" => "title",
					"value" => "",
					"description" => __( "Enter your title.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Heading", "eut-corpus-vc-extension" ),
					"param_name" => "heading",
					"admin_label" => true,
					"value" => array( 'h1', 'h2', 'h3', 'h4' , 'h5', 'h6' ),
					"std" => "h3",
					"description" => __( "Heading size", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textarea",
					"heading" => __( "Text", "eut-corpus-vc-extension" ),
					"param_name" => "content",
					"value" => "",
					"description" => __( "Enter your text.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "callout_style", 'value' => array( '1' ) ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Leader Text", "eut-corpus-vc-extension" ),
					"param_name" => "leader_text",
					"description" => __( "If selected, text will be shown as leader", "eut-corpus-vc-extension" ),
					"value" => Array( __( "Make text leader", "eut-corpus-vc-extension" ) => 'yes' ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Button Position", "eut-corpus-vc-extension" ),
					"param_name" => "btn_position",
					"value" => array(
						__( "Right", "eut-corpus-vc-extension" ) => 'btn-right',
						__( "Bottom", "eut-corpus-vc-extension" ) => 'btn-bottom',
					),
					"description" => __( "Select the position of the button.", "eut-corpus-vc-extension" ),
					"group" => __( "Button", "eut-corpus-vc-extension" ),
				),
				eut_vce_add_button_type(),
				eut_vce_add_button_color(),
				eut_vce_add_button_text(),
				eut_vce_add_button_size(),
				eut_vce_add_button_shape(),
				eut_vce_add_button_link(),
				eut_vce_add_button_class(),
				eut_vce_add_animation(),
				eut_vce_add_animation_delay(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_callout', 'eut_corpus_vce_callout_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_callout_shortcode_params( 'eut_callout' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
