<?php
/**
 * Slider Shortcode
 */

if( !function_exists( 'eut_slider_shortcode' ) ) {

	function eut_slider_shortcode( $attr, $content ) {

		$output = $class_fullwidth = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'ids' => '',
					'image_mode' => 'resize',
					'slideshow_speed' => '3500',
					'navigation_type' => '1',
					'navigation_color' => 'dark',
					'pause_hover' => 'no',
					'auto_play' => 'yes',
					'auto_height' => 'no',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$attr
			)
		);

		$attachments = explode( ",", $ids );

		if ( empty( $attachments ) ) {
			return '';
		}

		$image_size = 'eut-image-fullscreen';
		if ( 'autocrop' == $image_mode ) {
			$image_size = 'eut-image-large-rect-horizontal';
		} elseif ( 'landscape-wide' == $image_mode ) {
			$image_size = 'eut-image-small-rect-horizontal-wide';
		} elseif ( 'large' == $image_mode ) {
			$image_size = 'large';
		}

		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		$slider_data = '';
		$slider_data .= ' data-slider-speed="' . esc_attr( $slideshow_speed ) . '"';
		$slider_data .= ' data-slider-pause="' . esc_attr( $pause_hover ) . '"';
		$slider_data .= ' data-navigation-type="' . esc_attr( $navigation_type ) . '"';
		$slider_data .= ' data-slider-autoplay="' . esc_attr( $auto_play ) . '"';
		$slider_data .= ' data-slider-autoheight="' . esc_attr( $auto_height ) . '"';

		$output .= '<div class="eut-element eut-carousel-wrapper"  style="' . $style . ' ">';

		if ( 0 != $navigation_type ) {
			$output .= '<div class="eut-carousel-navigation eut-' . esc_attr( $navigation_color ) . '" data-navigation-type="' . esc_attr( $navigation_type ) . '">';
			$output .= '	<div class="eut-carousel-buttons">';
			$output .= '		<div class="eut-carousel-prev eut-icon-nav-left"></div>';
			$output .= '		<div class="eut-carousel-next eut-icon-nav-right"></div>';
			$output .= '	</div>';
			$output .= '</div>';
		}

		$output .= '<div class="eut-slider eut-carousel-element ' . esc_attr( $el_class ) . '"' . $slider_data . '>';

		foreach ( $attachments as $id ) {
			$image_link_href =  wp_get_attachment_url( $id );

			$output .= '<div class="eut-slider-item">';
			$output .= '<figure>';
			$output .= '<div class="eut-media">';
			$output .= wp_get_attachment_image( $id, $image_size );
			$output .= '</div>';
			$output .= '</figure>';
			$output .= '</div>';
		}
		$output .= '	</div>';
		$output .= '</div>';

		return $output;

	}
	add_shortcode( 'eut_slider', 'eut_slider_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_slider_shortcode_params' ) ) {
	function eut_corpus_vce_slider_shortcode_params( $tag ) {
		return array(
			"name" => __( "Slider", "eut-corpus-vc-extension" ),
			"description" => __( "Create a simple slider", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-slider",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type"			=> "attach_images",
					"admin_label"	=> true,
					"class"			=> "",
					"heading"		=> __( "Attach Images", "eut-corpus-vc-extension" ),
					"param_name"	=> "ids",
					"value" => '',
					"description"	=> __( "Select your slider images.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Image Mode", "eut-corpus-vc-extension" ),
					"param_name" => "image_mode",
					'value' => array(
						__( 'Resize ( Fullscreen )', 'eut-corpus-vc-extension' ) => 'resize',
						__( 'Resize ( Large )', 'eut-corpus-vc-extension' ) => 'large',
						__( 'Landscape Wide Large', 'eut-corpus-vc-extension' ) => 'autocrop',
						__( 'Landscape Wide', 'eut-corpus-vc-extension' ) => 'landscape-wide',
					),
					"description" => __( "Select your slider image mode.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Autoplay", "eut-corpus-vc-extension" ),
					"param_name" => "auto_play",
					"value" => array(
						__( "Yes", "eut-corpus-vc-extension" ) => 'yes',
						__( "No", "eut-corpus-vc-extension" ) => 'no',
					),
				),
				eut_vce_add_slideshow_speed(),
				array(
					"type" => 'checkbox',
					"heading" => __( "Pause on Hover", "eut-corpus-vc-extension" ),
					"param_name" => "pause_hover",
					"value" => Array( __( "If selected, slider will be paused on hover", "eut-corpus-vc-extension" ) => 'yes' ),
				),
				eut_vce_add_auto_height(),
				eut_vce_add_navigation_type(),
				eut_vce_add_navigation_color(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_slider', 'eut_corpus_vce_slider_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_slider_shortcode_params( 'eut_slider' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
