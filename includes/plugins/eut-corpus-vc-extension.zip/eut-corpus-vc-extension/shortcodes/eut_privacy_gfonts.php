<?php
/**
 * Privacy Google Fonts Shortcode
 */

if( !function_exists( 'eut_privacy_gfonts_shortcode' ) ) {

	function eut_privacy_gfonts_shortcode( $atts, $content ) {

		$output = '';

		if( empty( $content ) ) {
			$content = "Click to enable/disable Google Fonts.";
		}

		if ( function_exists( 'eut_get_privacy_switch' ) ) {
			$output .= eut_get_privacy_switch ( 'eut-privacy-content-gfonts' , $content );
		}

		return $output;
	}
	add_shortcode( 'eut_privacy_gfonts', 'eut_privacy_gfonts_shortcode' );

}

//Omit closing PHP tag to avoid accidental whitespace output errors.
