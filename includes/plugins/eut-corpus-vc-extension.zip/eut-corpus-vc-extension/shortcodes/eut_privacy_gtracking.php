<?php
/**
 * Privacy Google Tracking Code Shortcode
 */

if( !function_exists( 'eut_privacy_gtracking_shortcode' ) ) {

	function eut_privacy_gtracking_shortcode( $atts, $content ) {

		$output = '';

		if( empty( $content ) ) {
			$content = "Click to enable/disable Google Analytics tracking code.";
		}

		if ( function_exists( 'eut_get_privacy_switch' ) ) {
			$output .= eut_get_privacy_switch ( 'eut-privacy-content-gtracking' , $content );
		}

		return $output;
	}
	add_shortcode( 'eut_privacy_gtracking', 'eut_privacy_gtracking_shortcode' );

}

//Omit closing PHP tag to avoid accidental whitespace output errors.
