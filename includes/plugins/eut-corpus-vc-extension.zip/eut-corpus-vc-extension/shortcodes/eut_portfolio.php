<?php
/**
 * Portfolio Shortcode
 */

if( !function_exists( 'eut_portfolio_shortcode' ) ) {

	function eut_portfolio_shortcode( $attr, $content ) {

		$portfolio_row_start = $allow_filter = $class_fullwidth = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'categories' => '',
					'exclude_posts' => '',
					'include_posts' => '',
					'portfolio_style' => 'grid',
					'columns' => '3',
					'columns_tablet_landscape' => '2',
					'columns_tablet_portrait' => '2',
					'columns_mobile' => '1',
					'grid_image_mode' => 'landscape',
					'masonry_image_mode' => '',
					'carousel_image_mode' => 'landscape',
					'portfolio_image_mode' => '',
					'portfolio_link_type' => 'item',
					'portfolio_link_type_title' => 'More Details',
					'portfolio_filter' => '',
					'portfolio_filter_align' => 'left',
					'filter_order_by' => '',
					'filter_order' => 'ASC',
					'item_gutter' => 'yes',
					'item_spinner' => 'no',
					'items_per_page' => '4',
					'items_to_show' => '12',
					'hide_portfolio_title' => '',
					'hide_portfolio_caption' => '',
					'hide_portfolio_like' => '',
					'portfolio_hover_style' => 'hover-style-1',
					'zoom_effect' => 'none',
					'overlay_color' => 'light',
					'overlay_opacity' => '90',
					'order_by' => 'date',
					'order' => 'DESC',
					'disable_pagination' => '',
					'slideshow_speed' => '3000',
					'auto_play' => 'yes',
					'navigation_type' => '1',
					'navigation_color' => 'dark',
					'pause_hover' => 'no',

					'margin_bottom' => '',
					'el_class' => '',
				),
				$attr
			)
		);

		$portfolio_classes = array( 'eut-element' );
		$data_string = '';

		switch( $portfolio_style ) {
			case 'carousel':
				$data_string = ' data-items="' . esc_attr( $items_per_page ) . '" data-slider-autoplay="' . esc_attr( $auto_play ) . '" data-slider-speed="' . esc_attr( $slideshow_speed ) . '" data-slider-pause="' . esc_attr( $pause_hover ) . '"';
				array_push( $portfolio_classes, 'eut-carousel-wrapper' );
				if ( 'popup' == $portfolio_link_type ) {
					array_push( $portfolio_classes, 'eut-gallery-popup' );
				}
				$disable_pagination = 'yes';
				break;
			case 'masonry':
				$portfolio_row_start = '<div class="eut-isotope-container">';
				if ( 'popup' == $portfolio_link_type ) {
					$portfolio_row_start = '<div class="eut-isotope-container eut-gallery-popup">';
				}
				$data_string = ' data-spinner="' . esc_attr( $item_spinner ) . '" data-columns="' . esc_attr( $columns ) . '" data-columns-tablet-landscape="' . esc_attr( $columns_tablet_landscape ) . '" data-columns-tablet-portrait="' . esc_attr( $columns_tablet_portrait ) . '" data-columns-mobile="' . esc_attr( $columns_mobile ) . '" data-layout="masonry"';
				if ( 'yes' == $item_gutter ) {
					array_push( $portfolio_classes, 'eut-with-gap' );
				}
				array_push( $portfolio_classes, 'eut-portfolio' );
				array_push( $portfolio_classes, 'eut-isotope' );
				$allow_filter = 'yes';
				break;
			case 'small-media':
				$portfolio_row_start = '<div class="eut-standard-container">';
				array_push( $portfolio_classes, 'eut-portfolio' );
				array_push( $portfolio_classes, 'eut-blog' );
				array_push( $portfolio_classes, 'eut-small-media' );
				array_push( $portfolio_classes, 'eut-non-isotope' );
				$allow_filter = 'yes';
				$portfolio_link_type = 'item';
				break;
			case 'grid':
			default:
				$portfolio_row_start = '<div class="eut-isotope-container">';
				if ( 'popup' == $portfolio_link_type ) {
					$portfolio_row_start = '<div class="eut-isotope-container eut-gallery-popup">';
				}
				$data_string = ' data-gutter="' . esc_attr( $item_gutter ) . '" data-spinner="' . esc_attr( $item_spinner ) . '" data-columns="' . esc_attr( $columns ) . '" data-columns-tablet-landscape="' . esc_attr( $columns_tablet_landscape ) . '" data-columns-tablet-portrait="' . esc_attr( $columns_tablet_portrait ) . '" data-columns-mobile="' . esc_attr( $columns_mobile ) . '" data-layout="fitRows"';
				if ( 'yes' == $item_gutter ) {
					array_push( $portfolio_classes, 'eut-with-gap' );
				}
				array_push( $portfolio_classes, 'eut-portfolio' );
				array_push( $portfolio_classes, 'eut-isotope' );
				$allow_filter = 'yes';
				break;
		}


		if ( !empty ( $el_class ) ) {
			array_push( $portfolio_classes, $el_class);
		}
		$portfolio_class_string = implode( ' ', $portfolio_classes );

		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );

		$portfolio_cat = "";
		$portfolio_category_ids = array();

		if( ! empty( $categories ) ) {
			$portfolio_category_ids = explode( ",", $categories );
			foreach ( $portfolio_category_ids as $category_id ) {
				$category_term = get_term( $category_id, 'portfolio_category' );
				if ( isset( $category_term) ) {
					$portfolio_cat = $portfolio_cat.$category_term->slug . ', ';
				}
			}
		}

		$paged = 1;

		if ( 'yes' != $disable_pagination ) {
			if ( get_query_var( 'paged' ) ) {
				$paged = get_query_var( 'paged' );
			} elseif ( get_query_var( 'page' ) ) {
				$paged = get_query_var( 'page' );
			}
		}

		$exclude_ids = array();
		if( !empty( $exclude_posts ) ){
			$exclude_ids = explode( ',', $exclude_posts );
		}

		$include_ids = array();
		if( !empty( $include_posts ) ){
			$include_ids = explode( ',', $include_posts );
			$args = array(
				'post_type' => 'portfolio',
				'post_status'=>'publish',
				'paged' => $paged,
				'post__in' => $include_ids,
				'posts_per_page' => $items_to_show,
				'orderby' => $order_by,
				'order' => $order,
			);
			$portfolio_filter = 'no';
		} else {
			$args = array(
				'post_type' => 'portfolio',
				'post_status'=>'publish',
				'paged' => $paged,
				'portfolio_category' => $portfolio_cat,
				'post__not_in' => $exclude_ids,
				'posts_per_page' => $items_to_show,
				'orderby' => $order_by,
				'order' => $order,
			);
		}

		$query = new WP_Query( $args );
		ob_start();
		if ( $query->have_posts() ) :
		?>
			<div class="<?php echo esc_attr( $portfolio_class_string ); ?>" style="<?php echo $style; ?>"<?php echo $data_string; ?>>
		<?php

		if ( 'yes' == $portfolio_filter && 'yes' == $allow_filter ) {

			$category_prefix = '.portfolio_category-';
			$category_filter_list = array();
			$category_filter_array = array();
			$all_string =  apply_filters( 'eut_vce_portfolio_string_all_categories', __( 'All', 'eut-corpus-vc-extension' ) );
			$category_filter_string = '<li data-filter="*" class="selected"><span>' . esc_html( $all_string ) . '</span></li>';
			$category_filter_add = false;
			while ( $query->have_posts() ) : $query->the_post();

				if ( $portfolio_categories = get_the_terms( get_the_ID(), 'portfolio_category' ) ) {

					foreach($portfolio_categories as $category_term){
						$category_filter_add = false;
						if ( !in_array($category_term->term_id, $category_filter_list) ) {
							if( ! empty( $portfolio_category_ids ) ) {
								if ( in_array($category_term->term_id, $portfolio_category_ids) ) {
									$category_filter_add = true;
								}
							} else {
								$category_filter_add = true;
							}
							if ( $category_filter_add ) {
								$category_filter_list[] = $category_term->term_id;
								if ( 'title' == $filter_order_by ) {
									$category_filter_array[$category_term->name] = $category_term;
								} elseif ( 'slug' == $filter_order_by )  {
									$category_filter_array[$category_term->slug] = $category_term;
								} else {
									$category_filter_array[$category_term->term_id] = $category_term;
								}
							}
						}
					}
				}

			endwhile;


			if ( count( $category_filter_array ) > 1 ) {
				if ( '' != $filter_order_by ) {
					if ( 'ASC' == $filter_order ) {
						ksort( $category_filter_array );
					} else {
						krsort( $category_filter_array );
					}
				}
				foreach($category_filter_array as $category_filter){
					$term_class = sanitize_html_class( $category_filter->slug, $category_filter->term_id );
					if ( is_numeric( $term_class ) || ! trim( $term_class, '-' ) ) {
						$term_class = $category_filter->term_id;
					}
					$category_filter_string .= '<li data-filter="' . $category_prefix . $term_class . '"><span>' . $category_filter->name . '</span></li>';
				}
		?>
				<div class="eut-filter eut-align-<?php echo esc_attr( $portfolio_filter_align ); ?>">
					<ul>
						<?php echo $category_filter_string; ?>
					</ul>
				</div>
		<?php
			}
		}
		?>

			<?php echo $portfolio_row_start; ?>

		<?php

		if ( 'carousel' == $portfolio_style ) {
?>
			<?php if ( 0 != $navigation_type ) { ?>
			<div class="eut-carousel-navigation eut-<?php echo esc_attr( $navigation_color ); ?>" data-navigation-type="<?php echo esc_attr( $navigation_type ); ?>">
				<div class="eut-carousel-buttons">
					<div class="eut-carousel-prev eut-icon-nav-left"></div>
					<div class="eut-carousel-next eut-icon-nav-right"></div>
				</div>
			</div>
			<?php } ?>
			<div class="eut-carousel eut-carousel-element eut-portfolio"<?php echo $data_string; ?>>
<?php
		}

		$portfolio_index = 0;

		while ( $query->have_posts() ) : $query->the_post();
			$image_size = 'eut-image-small-rect-horizontal';
			$portfolio_index++;
			$portfolio_extra_class = '';

			$caption = get_post_meta( get_the_ID(), 'eut_portfolio_description', true );
			$details = get_post_meta( get_the_ID(), 'eut_portfolio_details', true );
			$link_mode = get_post_meta( get_the_ID(), 'eut_portfolio_link_mode', true );
			$link_url = get_post_meta( get_the_ID(), 'eut_portfolio_link_url', true );
			$new_window = get_post_meta( get_the_ID(), 'eut_portfolio_link_new_window', true );
			$link_class = get_post_meta( get_the_ID(), 'eut_portfolio_link_extra_class', true );


			if ( 'carousel' != $portfolio_style ) {
				$image_size = 'eut-image-small-square';
				$portfolio_extra_class = 'eut-isotope-item eut-portfolio-item ';

				if ( 'masonry' == $portfolio_style ) {
					//Masonry
					if ( 'resize' == $masonry_image_mode || 'large' == $masonry_image_mode ) {
						$portfolio_extra_class .= 'eut-masonry-image';
						$image_size = 'large';
					} elseif( 'medium_large' == $masonry_image_mode ) {
						$portfolio_extra_class .= 'eut-masonry-image';
						$image_size = 'medium_large';
					} elseif( 'medium' == $masonry_image_mode ) {
						$portfolio_extra_class .= 'eut-masonry-image';
						$image_size = 'medium';
					} elseif( 'custom' == $masonry_image_mode ) {
						$masonry_size = get_post_meta( get_the_ID(), 'eut_portfolio_media_masonry_size', true );
						$eut_masonry_data = eut_corpus_vce_get_custom_masonry_data( $masonry_size );
						$portfolio_extra_class .= $eut_masonry_data['class'];
						$image_size = $eut_masonry_data['image_size'];
					} else {
						$eut_masonry_data = eut_corpus_vce_get_masonry_data( $portfolio_index, $columns );
						$portfolio_extra_class .= $eut_masonry_data['class'];
						$image_size = $eut_masonry_data['image_size'];
					}
				} elseif ( 'small-media' == $portfolio_style ) {
					//Small Media
					$portfolio_extra_class = 'eut-non-isotope-item eut-blog-item eut-small-post';
					if ( 'resize' == $portfolio_image_mode || 'large' == $portfolio_image_mode ) {
						$image_size = 'large';
					} elseif( 'medium_large' == $portfolio_image_mode ) {
						$image_size = 'medium_large';
					} elseif( 'medium' == $portfolio_image_mode ) {
						$image_size = 'medium';
					} else {
						$image_size = 'eut-image-small-rect-horizontal';
					}
				} else {
					//Grid - Default
					if ( 'resize' == $grid_image_mode || 'large' == $grid_image_mode ) {
						$image_size = 'large';
					} elseif( 'medium_large' == $grid_image_mode ) {
						$image_size = 'medium_large';
					} elseif( 'medium' == $grid_image_mode ) {
						$image_size = 'medium';
					} elseif( 'square' == $grid_image_mode ) {
						$image_size = 'eut-image-small-square';
					} elseif( 'portrait' == $grid_image_mode ) {
						$image_size = 'eut-image-small-rect-vertical';
					} else {
						$image_size = 'eut-image-small-rect-horizontal';
					}
				}
			} else {
				if( 'square' == $carousel_image_mode ) {
					$image_size = 'eut-image-small-square';
				} elseif( 'portrait' == $carousel_image_mode ) {
					$image_size = 'eut-image-small-rect-vertical';
				} elseif( 'medium' == $carousel_image_mode ) {
					$image_size = 'medium';
				} else {
					$image_size = 'eut-image-small-rect-horizontal';
				}
				$portfolio_extra_class = 'eut-portfolio-item';
				echo '<div class="eut-carousel-item">';
			}

			//Portfolio Link

			$portfolio_link_exists = true;
			$eut_target = '_self';
			if( !empty( $new_window ) ) {
				$eut_target = '_blank';
			}

			ob_start();
			if ( 'small-media' == $portfolio_style ) {
				?>
					<a href="<?php echo esc_url( get_permalink() ); ?>">
				<?php
			} else {
				if ( 'popup' == $portfolio_link_type ) {
				?>
					<a href="<?php eut_corpus_vce_print_portfolio_image( 'full', 'link' ); ?>">
				<?php
				}  else if ( 'custom-link' == $portfolio_link_type ) {
					if ( '' == $link_mode )	{
				?>
					<a href="<?php echo esc_url( get_permalink() ); ?>">
				<?php
					} else if ( 'link' == $link_mode && !empty( $link_url ) ) {
				?>
					<a class="<?php echo esc_attr( $link_class ); ?>" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $eut_target ); ?>">
				<?php
					} else {
						$portfolio_link_exists = false;
					}
				} else {
				?>
					<a href="<?php echo esc_url( get_permalink() ); ?>">
				<?php
				}
			}

			$link_start = ob_get_clean();

			if ( $portfolio_link_exists ) {
				$link_end = '</a>';
			} else {
				$link_end = '';
			}

?>
					<article id="portfolio-<?php the_ID(); ?><?php echo uniqid('-'); ?>" <?php post_class( $portfolio_extra_class ); ?>>
						<?php
						if ( 'carousel' == $portfolio_style ) {
						?>
							<figure class="eut-hover-style-1 eut-image-hover eut-zoom-<?php echo esc_attr( $zoom_effect ); ?> eut-<?php echo esc_attr( $overlay_color ); ?>">

								<div class="eut-media eut-<?php echo esc_attr( $overlay_color ); ?>-overlay eut-opacity-<?php echo esc_attr( $overlay_opacity ); ?>">
									<?php eut_corpus_vce_print_portfolio_image( $image_size ); ?>
								</div>
								<figcaption>
									<?php
										if( function_exists( 'eut_print_portfolio_like_counter' ) && 'yes' != $hide_portfolio_like ) {
											eut_print_portfolio_like_counter();
										}
									?>
									<?php if ( 'yes' != $hide_portfolio_title  ) { ?>
									<h5 class="eut-title eut-<?php echo esc_attr( $overlay_color ); ?>"><?php the_title(); ?></h5>
									<?php } ?>
									<?php if ( !empty( $caption ) && 'yes' != $hide_portfolio_caption  ) { ?>
									<span class="eut-caption eut-<?php echo esc_attr( $overlay_color ); ?>"><?php echo wp_kses_post( $caption ); ?></span>
									<?php } ?>

									<?php
										if ( 'popup' == $portfolio_link_type ) {
									?>
										<a title="<?php the_title(); ?>" class="eut-portfolio-btns" href="<?php eut_corpus_vce_print_portfolio_image( 'full', 'link' ); ?>"><?php echo $portfolio_link_type_title; ?></a>
									<?php
										} elseif ( $portfolio_link_exists ) {
											if ( 'custom-link' == $portfolio_link_type && 'link' == $link_mode) {
									?>
										<a class="eut-portfolio-btns" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $eut_target ); ?>"><?php echo esc_html( $portfolio_link_type_title ); ?></a>
									<?php
											} else {
									?>
										<a class="eut-portfolio-btns" href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html( $portfolio_link_type_title ); ?></a>
									<?php
											}
										}
									?>
								</figcaption>
							</figure>
						<?php

						} elseif( 'small-media' == $portfolio_style ) {
						?>
							<div class="eut-media eut-image-hover">
								<?php echo $link_start; ?><?php eut_corpus_vce_print_portfolio_image( $image_size ); ?><?php echo $link_end; ?>
							</div>
							<div class="eut-post-content">
								<?php if ( 'yes' != $hide_portfolio_title  ) { ?>
								<?php echo $link_start; ?><h5 class="eut-title"><?php the_title(); ?></h5><?php echo $link_end; ?>
								<?php } ?>
								<div class="eut-subtitle eut-post-meta">
									<?php if ( !empty( $caption ) && 'yes' != $hide_portfolio_caption  ) { ?>
									<span class="eut-caption"><?php echo wp_kses_post( $caption ); ?></span>
									<?php } ?>
								</div>
								<?php if ( !empty( $details ) ) { ?>
									<p><?php echo $details; ?></p>
								<?php } ?>
									<a class="eut-read-more" href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html( $portfolio_link_type_title ); ?></a>
							</div>
						<?php
						} else {

							if ( 'hover-style-2' == $portfolio_hover_style ) {
						?>
							<?php echo $link_start; ?>
							<figure class="eut-hover-style-2 eut-image-hover eut-<?php echo esc_attr( $overlay_color ); ?>">
								<div class="eut-media eut-<?php echo esc_attr( $overlay_color ); ?>-overlay eut-opacity-<?php echo esc_attr( $overlay_opacity ); ?>">
									<?php eut_corpus_vce_print_portfolio_image( $image_size ); ?>
								</div>
								<?php
									if( function_exists( 'eut_print_portfolio_like_counter' ) && 'yes' != $hide_portfolio_like ) {
										eut_print_portfolio_like_counter();
									}
								?>
								<figcaption>
									<?php if ( 'yes' != $hide_portfolio_title  ) { ?>
									<h5 class="eut-title eut-light"><?php the_title(); ?></h5>
									<?php } ?>
									<?php if ( !empty( $caption ) && 'yes' != $hide_portfolio_caption  ) { ?>
									<span class="eut-subtitle eut-caption eut-light"><?php echo wp_kses_post( $caption ); ?></span>
									<?php } ?>
								</figcaption>
							</figure>
							<?php echo $link_end; ?>
						<?php
							} else {
							//Default Hover Style 1
						?>
							<?php echo $link_start; ?>
							<figure class="eut-hover-style-1 eut-image-hover eut-zoom-<?php echo esc_attr( $zoom_effect ); ?> eut-<?php echo esc_attr( $overlay_color ); ?>">

								<div class="eut-media eut-<?php echo esc_attr( $overlay_color ); ?>-overlay eut-opacity-<?php echo esc_attr( $overlay_opacity ); ?>">
									<?php eut_corpus_vce_print_portfolio_image( $image_size ); ?>
								</div>
								<figcaption>
									<?php
										if( function_exists( 'eut_print_portfolio_like_counter' ) && 'yes' != $hide_portfolio_like ) {
											eut_print_portfolio_like_counter();
										}
									?>
									<?php if ( 'yes' != $hide_portfolio_title  ) { ?>
									<h5 class="eut-title eut-<?php echo esc_attr( $overlay_color ); ?>"><?php the_title(); ?></h5>
									<?php } ?>
									<?php if ( !empty( $caption ) && 'yes' != $hide_portfolio_caption  ) { ?>
									<span class="eut-caption eut-<?php echo esc_attr( $overlay_color ); ?>"><?php echo wp_kses_post( $caption ); ?></span>
									<?php } ?>
									<?php if ( $portfolio_link_exists ) { ?>
									<span class="eut-portfolio-btns"><?php echo esc_html( $portfolio_link_type_title ); ?></span>
									<?php } ?>
								</figcaption>
							</figure>
							<?php echo $link_end; ?>
						<?php
							}
						}
						?>

					</article>
<?php
			if ( 'carousel' == $portfolio_style ) {
				echo '</div>';
			}

		endwhile;

		?>
				</div>
<?php
			if ( 'yes' != $disable_pagination ) {
				$total = $query->max_num_pages;
				$big = 999999999; // need an unlikely integer
				if( $total > 1 )  {
					 echo '<div class="eut-pagination">';

					 if( get_option('permalink_structure') ) {
						 $format = 'page/%#%/';
					 } else {
						 $format = '&paged=%#%';
					 }
					 echo paginate_links(array(
						'base'			=> str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
						'format'		=> $format,
						'current'		=> max( 1, $paged ),
						'total'			=> $total,
						'mid_size'		=> 2,
						'type'			=> 'list',
						'prev_text'	=> '<i class="eut-icon-nav-left"></i>',
						'next_text'	=> '<i class="eut-icon-nav-right"></i>',
						'add_args' => false,
					 ));
					 echo '</div>';
				}
			}
?>
			</div>

		<?php

		else :
		endif;
		wp_reset_postdata();

		return ob_get_clean();

	}
	add_shortcode( 'eut_portfolio', 'eut_portfolio_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_portfolio_shortcode_params' ) ) {
	function eut_corpus_vce_portfolio_shortcode_params( $tag ) {
		return array(
			"name" => __( "Portfolio", "eut-corpus-vc-extension" ),
			"description" => __( "Display Portfolio element in multiple styles", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-portfolio",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "dropdown",
					"heading" => __( "Style", "eut-corpus-vc-extension" ),
					"param_name" => "portfolio_style",
					"admin_label" => true,
					'value' => array(
						__( 'Grid' , 'eut-corpus-vc-extension' ) => 'grid',
						__( 'Masonry' , 'eut-corpus-vc-extension' ) => 'masonry',
						__( 'Small Media' , 'eut-corpus-vc-extension' ) => 'small-media',
						__( 'Carousel' , 'eut-corpus-vc-extension' ) => 'carousel',
					),
					"description" => __( "Select a style for your portfolio", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Image Mode", "eut-corpus-vc-extension" ),
					"param_name" => "portfolio_image_mode",
					'value' => array(
						__( 'Auto Crop', 'eut-corpus-vc-extension' ) => '',
						__( 'Resize ( Large )', 'eut-corpus-vc-extension' ) => 'resize',
						__( 'Resize ( Medium Large )', 'eut-corpus-vc-extension' ) => 'medium_large',
						__( 'Resize ( Medium )', 'eut-corpus-vc-extension' ) => 'medium',
					),
					"description" => __( "Select your Portfolio Image Mode.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'small-media' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Grid Image Mode", "eut-corpus-vc-extension" ),
					"param_name" => "grid_image_mode",
					'value' => array(
						__( 'Square Crop', 'eut-corpus-vc-extension' ) => 'square',
						__( 'Landscape Crop', 'eut-corpus-vc-extension' ) => 'landscape',
						__( 'Portrait Crop', 'eut-corpus-vc-extension' ) => 'portrait',
						__( 'Resize ( Large )', 'eut-corpus-vc-extension' ) => 'resize',
						__( 'Resize ( Medium Large )', 'eut-corpus-vc-extension' ) => 'medium_large',
						__( 'Resize ( Medium )', 'eut-corpus-vc-extension' ) => 'medium',
					),
					'std' => 'landscape',
					"description" => __( "Select your Grid Image Mode.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'grid' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Masonry Image Mode", "eut-corpus-vc-extension" ),
					"param_name" => "masonry_image_mode",
					'value' => array(
						__( 'Auto Crop', 'eut-corpus-vc-extension' ) => '',
						__( 'Resize ( Large )', 'eut-corpus-vc-extension' ) => 'resize',
						__( 'Resize ( Medium Large )', 'eut-corpus-vc-extension' ) => 'medium_large',
						__( 'Resize ( Medium )', 'eut-corpus-vc-extension' ) => 'medium',
						__( 'Custom', 'eut-corpus-vc-extension' ) => 'custom',
					),
					"description" => __( "Select your Masonry Image Mode.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Carousel Image Mode", "eut-corpus-vc-extension" ),
					"param_name" => "carousel_image_mode",
					'value' => array(
						__( 'Square Crop', 'eut-corpus-vc-extension' ) => 'square',
						__( 'Landscape Crop', 'eut-corpus-vc-extension' ) => 'landscape',
						__( 'Portrait Crop', 'eut-corpus-vc-extension' ) => 'portrait',
						__( 'Resize ( Medium )', 'eut-corpus-vc-extension' ) => 'medium',
					),
					'std' => 'landscape',
					"description" => __( "Select your Carousel Image Mode.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'carousel' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Columns", "eut-corpus-vc-extension" ),
					"param_name" => "columns",
					"value" => array( '2', '3', '4', '5' ),
					"std" => '3',
					"description" => __( "Select your Porfolio Columns.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Tablet Landscape Columns", "eut-corpus-vc-extension" ),
					"param_name" => "columns_tablet_landscape",
					"value" => array( '2', '3', '4', '5' ),
					"std" => '2',
					"description" => __( "Select responsive column on tablet devices, landscape orientation.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Tablet Portrait Columns", "eut-corpus-vc-extension" ),
					"param_name" => "columns_tablet_portrait",
					"value" => array( '2', '3', '4', '5' ),
					"std" => '2',
					"description" => __( "Select responsive column on tablet devices, portrait orientation.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Mobile Columns", "eut-corpus-vc-extension" ),
					"param_name" => "columns_mobile",
					"value" => array( '1', '2' ),
					"std" => '1',
					"description" => __( "Select responsive column on mobile devices.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Link Type", "eut-corpus-vc-extension" ),
					"param_name" => "portfolio_link_type",
					"admin_label" => true,
					'value' => array(
						__( 'Classic Portfolio' , 'eut-corpus-vc-extension' ) => 'item',
						__( 'Gallery Usage' , 'eut-corpus-vc-extension' ) => 'popup',
						__( 'Custom Link' , 'eut-corpus-vc-extension' ) => 'custom-link',
					),
					"description" => __( "Select the link type of your portfolio items.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'grid', 'masonry', 'carousel' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Link Title", "eut-corpus-vc-extension" ),
					"param_name" => "portfolio_link_type_title",
					"value" => "More Details",
					"description" => __( "Enter your title for your link.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Filter", "eut-corpus-vc-extension" ),
					"param_name" => "portfolio_filter",
					"description" => __( "If selected, an isotope filter will be displayed.", "eut-corpus-vc-extension" ),
					"value" => Array( __( "Enable Portfolio Filter ( Only for All or Multiple Categories )", "eut-corpus-vc-extension" ) => 'yes' ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'grid', 'masonry', 'small-media' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Filter Order By", "eut-corpus-vc-extension" ),
					"param_name" => "filter_order_by",
					"value" => array(
						__( "Default ( Unordered )", "eut-corpus-vc-extension" ) => '',
						__( "ID", "eut-corpus-vc-extension" ) => 'id',
						__( "Slug", "eut-corpus-vc-extension" ) => 'slug',
						__( "Title", "eut-corpus-vc-extension" ) => 'title',
					),
					"description" => '',
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'grid', 'masonry', 'small-media' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Filter Order", "eut-corpus-vc-extension" ),
					"param_name" => "filter_order",
					"value" => array(
						__( "Ascending", "eut-corpus-vc-extension" ) => 'ASC',
						__( "Descending", "eut-corpus-vc-extension" ) => 'DESC',
					),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'grid', 'masonry', 'small-media' ) ),
					"description" => '',
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Filter Alignment", "eut-corpus-vc-extension" ),
					"param_name" => "portfolio_filter_align",
					"value" => array(
						__( "Left", "eut-corpus-vc-extension" ) => 'left',
						__( "Right", "eut-corpus-vc-extension" ) => 'right',
						__( "Center", "eut-corpus-vc-extension" ) => 'center',
					),
					"description" => '',
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'grid', 'masonry', 'small-media' ) ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Enable Loader", "eut-corpus-vc-extension" ),
					"param_name" => "item_spinner",
					"description" => __( "If selected, this will enable a graphic spinner before load.", "eut-corpus-vc-extension" ),
					"value" => Array( __( "Enable Loader.", "eut-corpus-vc-extension" ) => 'yes' ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Disable Pagination", "eut-corpus-vc-extension" ),
					"param_name" => "disable_pagination",
					"description" => __( "If selected, pagination will not be shown.", "eut-corpus-vc-extension" ),
					"value" => Array( __( "Disable Pagination.", "eut-corpus-vc-extension" ) => 'yes' ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'grid', 'masonry', 'small-media' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Items per page", "eut-corpus-vc-extension" ),
					"param_name" => "items_per_page",
					"value" => array( '3', '4', '5' ),
					"description" => __( "Number of images per page", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'carousel' ) ),
					"std" => "4",
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Gutter between images", "eut-corpus-vc-extension" ),
					"param_name" => "item_gutter",
					"value" => array(
						__( "Yes", "eut-corpus-vc-extension" ) => 'yes',
						__( "No", "eut-corpus-vc-extension" ) => 'no',
					),
					"description" => __( "Add gutter among images.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Items to show", "eut-corpus-vc-extension" ),
					"param_name" => "items_to_show",
					"value" => '12',
					"description" => __( "Maximum Portfolio Items to Show", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Hide Portfolio Title", "eut-corpus-vc-extension" ),
					"param_name" => "hide_portfolio_title",
					"value" => Array( __( "If selected, portfolio title will be hidden", "eut-corpus-vc-extension" ) => 'yes' ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Hide Portfolio Description", "eut-corpus-vc-extension" ),
					"param_name" => "hide_portfolio_caption",
					"value" => Array( __( "If selected, portfolio description will be hidden", "eut-corpus-vc-extension" ) => 'yes' ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Hide Portfolio Likes", "eut-corpus-vc-extension" ),
					"param_name" => "hide_portfolio_like",
					"value" => Array( __( "If selected, portfolio likes will be hidden", "eut-corpus-vc-extension" ) => 'yes' ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'grid', 'masonry', 'carousel' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Hover Style", "eut-corpus-vc-extension" ),
					"param_name" => "portfolio_hover_style",
					'value' => array(
						__( 'Style 1' , 'eut-corpus-vc-extension' ) => 'hover-style-1',
						__( 'Style 2' , 'eut-corpus-vc-extension' ) => 'hover-style-2',
					),
					"description" => __( "Select hover style for portfolio items.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'grid', 'masonry' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Image Zoom Effect", "eut-corpus-vc-extension" ),
					"param_name" => "zoom_effect",
					"value" => array(
						__( "Zoom In", "eut-corpus-vc-extension" ) => 'in',
						__( "Zoom Out", "eut-corpus-vc-extension" ) => 'out',
						__( "None", "eut-corpus-vc-extension" ) => 'none',
					),
					"description" => __( "Choose the image zoom effect.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "portfolio_hover_style", 'value' => array( 'hover-style-1' ) ),
					'std' => 'none',
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Overlay Color", "eut-corpus-vc-extension" ),
					"param_name" => "overlay_color",
					"value" => array(
						__( "Light", "eut-corpus-vc-extension" ) => 'light',
						__( "Dark", "eut-corpus-vc-extension" ) => 'dark',
						__( "Primary 1", "eut-corpus-vc-extension" ) => 'primary-1',
						__( "Primary 2", "eut-corpus-vc-extension" ) => 'primary-2',
						__( "Primary 3", "eut-corpus-vc-extension" ) => 'primary-3',
						__( "Primary 4", "eut-corpus-vc-extension" ) => 'primary-4',
						__( "Primary 5", "eut-corpus-vc-extension" ) => 'primary-5',
					),
					"description" => __( "Choose the image color overlay.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'grid', 'masonry', 'carousel' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Overlay Opacity", "eut-corpus-vc-extension" ),
					"param_name" => "overlay_opacity",
					"value" => array( '0', '10', '20', '30', '40', '50', '60', '70', '80', '90', '100' ),
					"std" => '90',
					"description" => __( "Choose the opacity for the overlay.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'grid', 'masonry', 'carousel' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Autoplay", "eut-corpus-vc-extension" ),
					"param_name" => "auto_play",
					"value" => array(
						__( "Yes", "eut-corpus-vc-extension" ) => 'yes',
						__( "No", "eut-corpus-vc-extension" ) => 'no',
					),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'carousel' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Slideshow Speed", "eut-corpus-vc-extension" ),
					"param_name" => "slideshow_speed",
					"value" => '3000',
					"description" => __( "Slideshow Speed in ms.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'carousel' ) ),
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Pause on Hover", "eut-corpus-vc-extension" ),
					"param_name" => "pause_hover",
					"value" => Array( __( "If selected, carousel will be paused on hover", "eut-corpus-vc-extension" ) => 'yes' ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'carousel' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Navigation Type", "eut-corpus-vc-extension" ),
					"param_name" => "navigation_type",
					'value' => array(
						__( 'Style 1' , 'eut-corpus-vc-extension' ) => '1',
						__( 'Style 2' , 'eut-corpus-vc-extension' ) => '2',
						__( 'Style 3' , 'eut-corpus-vc-extension' ) => '3',
						__( 'Style 4' , 'eut-corpus-vc-extension' ) => '4',
						__( 'No Navigation' , 'eut-corpus-vc-extension' ) => '0',
					),
					"description" => __( "Select your Navigation type.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'carousel' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Navigation Color", "eut-corpus-vc-extension" ),
					"param_name" => "navigation_color",
					'value' => array(
						__( 'Dark' , 'eut-corpus-vc-extension' ) => 'dark',
						__( 'Light' , 'eut-corpus-vc-extension' ) => 'light',
					),
					"description" => __( "Select the background Navigation color.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "portfolio_style", 'value' => array( 'carousel' ) ),
				),
				eut_vce_add_order_by(),
				eut_vce_add_order(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
				array(
					"type" => "textfield",
					"heading" => __("Exclude Posts", "eut-corpus-vc-extension" ),
					"param_name" => "exclude_posts",
					"value" => '',
					"description" => __( "Type the post ids you want to exclude separated by comma ( , ).", "eut-corpus-vc-extension" ),
					"group" => __( "Categories", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "eut_multi_checkbox",
					"heading" => __("Portfolio Categories", "eut-corpus-vc-extension" ),
					"param_name" => "categories",
					"value" => eut_corpus_vce_get_portfolio_categories(),
					"description" => __( "Select all or multiple categories.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
					"group" => __( "Categories", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __("Include Specific Posts", "eut-corpus-vc-extension" ),
					"param_name" => "include_posts",
					"value" => '',
					"description" => __( "Type the specific post ids you want to include separated by comma ( , ). Note: If you define specific post ids, Exclude Posts and Categories will have no effect.", "eut-corpus-vc-extension" ),
					"group" => __( "Categories", "eut-corpus-vc-extension" ),
				),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_portfolio', 'eut_corpus_vce_portfolio_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_portfolio_shortcode_params( 'eut_portfolio' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
