<?php
/**
 * Counter Shortcode
 */

if( !function_exists( 'eut_counter_shortcode' ) ) {

	function eut_counter_shortcode( $atts, $content ) {

		$output = $link_start = $link_end = $retina_data = $data = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'counter_start_val' => '0',
					'counter_end_val' => '100',
					'counter_prefix' => '',
					'counter_suffix' => '',
					'counter_decimal_points' => '0',
					'counter_decimal_separator' => '.',
					'counter_color' => 'primary-1',
					'counter_size' => 'small',
					'counter_thousands_separator_vis' => '',
					'counter_thousands_separator' => ',',
					'title' => '',
					'heading' => 'h3',
					'icon_library' => 'fontawesome',
					'icon_fontawesome' => 'fa fa-info-circle',
					'icon_openiconic' => 'vc-oi vc-oi-dial',
					'icon_typicons' => 'typcn typcn-adjust-brightness',
					'icon_entypo' => 'entypo-icon entypo-icon-note',
					'icon_linecons' => 'vc_li vc_li-heart',
					'icon_type' => '',
					'icon_size' => 'medium',
					'icon_color' => 'primary-1',
					'animation' => '',
					'animation_delay' => '200',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		if ( !empty( $animation ) ) {
			$animation = 'eut-' . $animation;
		}

		$counter_classes = array( 'eut-element' );

		array_push( $counter_classes, 'eut-counter' );
		array_push( $counter_classes, 'eut-align-center' );

		if ( !empty( $animation ) ) {
			array_push( $counter_classes, 'eut-animated-item' );
			array_push( $counter_classes, $animation);
			$data = ' data-delay="' . esc_attr( $animation_delay ) . '"';
		}

		if ( !empty ( $el_class ) ) {
			array_push( $counter_classes, $el_class);
		}

		$counter_class_string = implode( ' ', $counter_classes );


		$icon_classes = array();

		if ( 'icon' == $icon_type ) {

			$icon_class = isset( ${"icon_" . $icon_library} ) ? esc_attr( ${"icon_" . $icon_library} ) : 'fa fa-adjust';
			if ( function_exists( 'vc_icon_element_fonts_enqueue' ) ) {
				vc_icon_element_fonts_enqueue( $icon_library );
			}
			array_push( $icon_classes, $icon_class );
			array_push( $icon_classes, 'eut-color-' . $icon_color );
			array_push( $icon_classes, 'eut-' . $icon_size );
		}

		$icon_class_string = implode( ' ', $icon_classes );


		$style = eut_corpus_vce_build_margin_bottom_style( $margin_bottom );


		$output .= '<div class="' . esc_attr( $counter_class_string ) . '" style="' . $style . '"' . $data . '>';

		if ( 'icon' == $icon_type ) {
			$output .= '  <div class="eut-counter-icon">';
			$output .= '  <i class="' . esc_attr( $icon_class_string ) . '"></i>';
			$output .= '  </div>';
		}

		$output .= '  <div class="eut-counter-content">';
		$output .= '    <div class="eut-counter-item eut-color-' . esc_attr( $counter_color ) . ' eut-' . esc_attr( $counter_size ) . '">';
		$output .= '      <span data-thousands-separator-vis="' . esc_attr( $counter_thousands_separator_vis ) . '" data-thousands-separator="' . esc_attr( $counter_thousands_separator ) . '" data-prefix="' . esc_attr( $counter_prefix ) . '" data-suffix="' . esc_attr( $counter_suffix ) . '" data-start-val="' . esc_attr( $counter_start_val ) . '" data-end-val="' . esc_attr( $counter_end_val ) . '" data-decimal-points="' . esc_attr( $counter_decimal_points ) . '" data-decimal-separator="' . esc_attr( $counter_decimal_separator ) . '">' . $counter_start_val. '</span>';
		$output .= '    </div>';
		$output .= '	<' . $heading . ' class="eut-counter-title">' . $title. '</' . $heading . '>';
		$output .= '  </div>';

		$output .= '</div>';

		return $output;
	}
	add_shortcode( 'eut_counter', 'eut_counter_shortcode' );

}

/**
 * Add shortcode to Visual Composer
 */

if( !function_exists( 'eut_corpus_vce_counter_shortcode_params' ) ) {
	function eut_corpus_vce_counter_shortcode_params( $tag ) {
		return array(
			"name" => __( "Counter", "eut-corpus-vc-extension" ),
			"description" => __( "Add a counter with icon and title", "eut-corpus-vc-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "icon-wpb-eut-counter",
			"category" => __( "Content", "js_composer" ),
			"params" => array(
				array(
					"type" => "textfield",
					"heading" => __( "Counter Start Number", "eut-corpus-vc-extension" ),
					"param_name" => "counter_start_val",
					"value" => "0",
					"description" => __( "Enter counter start number.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "textfield",
					"heading" => __( "Counter End Number", "eut-corpus-vc-extension" ),
					"param_name" => "counter_end_val",
					"value" => "100",
					"description" => __( "Enter counter end number.", "eut-corpus-vc-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => 'checkbox',
					"heading" => __( "Counter Thousands Separator Visiblility", "eut-corpus-vc-extension" ),
					"param_name" => "counter_thousands_separator_vis",
					"description" => __( "If selected, thousands separator will not be shown.", "eut-corpus-vc-extension" ),
					"value" => Array( __( "Disable Thousands Separator.", "eut-corpus-vc-extension" ) => 'yes' ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Counter Thousands Separator", "eut-corpus-vc-extension" ),
					"param_name" => "counter_thousands_separator",
					"value" => ",",
					"description" => __( "Enter thousands separator.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Counter Decimal Points", "eut-corpus-vc-extension" ),
					"param_name" => "counter_decimal_points",
					"value" => "0",
					"description" => __( "Number of decimal points.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Counter Decimal Separator", "eut-corpus-vc-extension" ),
					"param_name" => "counter_decimal_separator",
					"value" => ".",
					"description" => __( "Enter decimal separator.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Counter Prefix", "eut-corpus-vc-extension" ),
					"param_name" => "counter_prefix",
					"value" => "",
					"description" => __( "Enter counter prefix.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Counter Suffix", "eut-corpus-vc-extension" ),
					"param_name" => "counter_suffix",
					"value" => "",
					"description" => __( "Enter counter suffix.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Counter Color", "eut-corpus-vc-extension" ),
					"param_name" => "counter_color",
					"value" => array(
						__( "Primary 1", "eut-corpus-vc-extension" ) => 'primary-1',
						__( "Primary 2", "eut-corpus-vc-extension" ) => 'primary-2',
						__( "Primary 3", "eut-corpus-vc-extension" ) => 'primary-3',
						__( "Primary 4", "eut-corpus-vc-extension" ) => 'primary-4',
						__( "Primary 5", "eut-corpus-vc-extension" ) => 'primary-5',
						__( "Green", "eut-corpus-vc-extension" ) => 'green',
						__( "Orange", "eut-corpus-vc-extension" ) => 'orange',
						__( "Red", "eut-corpus-vc-extension" ) => 'red',
						__( "Blue", "eut-corpus-vc-extension" ) => 'blue',
						__( "Aqua", "eut-corpus-vc-extension" ) => 'aqua',
						__( "Purple", "eut-corpus-vc-extension" ) => 'purple',
						__( "Black", "eut-corpus-vc-extension" ) => 'black',
						__( "Grey", "eut-corpus-vc-extension" ) => 'grey',
						__( "White", "eut-corpus-vc-extension" ) => 'white',
					),
					"description" => __( "Color of the counter.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Counter Text Size", "eut-corpus-vc-extension" ),
					"param_name" => "counter_size",
					"value" => array(
						__( "Small", "eut-corpus-vc-extension" ) => 'small',
						__( "Medium", "eut-corpus-vc-extension" ) => 'medium',
						__( "Large", "eut-corpus-vc-extension" ) => 'large',
					),
					"description" => __( "Select counter text size.", "eut-corpus-vc-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Icon type", "eut-corpus-vc-extension" ),
					"param_name" => "icon_type",
					"value" => array(
						__( "No Icon", "eut-corpus-vc-extension" ) => '',
						__( "Icon", "eut-corpus-vc-extension" ) => 'icon',
					),
					"description" => '',
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Icon size", "eut-corpus-vc-extension" ),
					"param_name" => "icon_size",
					"value" => array(
						__( "Large", "eut-corpus-vc-extension" ) => 'large',
						__( "Medium", "eut-corpus-vc-extension" ) => 'medium',
						__( "Small", "eut-corpus-vc-extension" ) => 'small',
					),
					"std" => 'medium',
					"description" => '',
					"dependency" => Array( 'element' => "icon_type", 'value' => array( 'icon' ) ),
				),
				array(
					'type' => 'dropdown',
					'heading' => __( 'Icon library', 'eut-corpus-vc-extension' ),
					'value' => array(
						__( 'Font Awesome', 'eut-corpus-vc-extension' ) => 'fontawesome',
						__( 'Open Iconic', 'eut-corpus-vc-extension' ) => 'openiconic',
						__( 'Typicons', 'eut-corpus-vc-extension' ) => 'typicons',
						__( 'Entypo', 'eut-corpus-vc-extension' ) => 'entypo',
						__( 'Linecons', 'eut-corpus-vc-extension' ) => 'linecons',
					),
					'param_name' => 'icon_library',
					'description' => __( 'Select icon library.', 'eut-corpus-vc-extension' ),
					"dependency" => Array( 'element' => "icon_type", 'value' => array( 'icon' ) ),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'eut-corpus-vc-extension' ),
					'param_name' => 'icon_fontawesome',
					'value' => 'fa fa-info-circle',
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'iconsPerPage' => 200, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'icon_library',
						'value' => 'fontawesome',
					),
					'description' => __( 'Select icon from library.', 'eut-corpus-vc-extension' ),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'eut-corpus-vc-extension' ),
					'param_name' => 'icon_openiconic',
					'value' => 'vc-oi vc-oi-dial',
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'type' => 'openiconic',
						'iconsPerPage' => 200, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'icon_library',
						'value' => 'openiconic',
					),
					'description' => __( 'Select icon from library.', 'eut-corpus-vc-extension' ),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'eut-corpus-vc-extension' ),
					'param_name' => 'icon_typicons',
					'value' => 'typcn typcn-adjust-brightness',
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'type' => 'typicons',
						'iconsPerPage' => 200, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'icon_library',
						'value' => 'typicons',
					),
					'description' => __( 'Select icon from library.', 'eut-corpus-vc-extension' ),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'eut-corpus-vc-extension' ),
					'param_name' => 'icon_entypo',
					'value' => 'entypo-icon entypo-icon-note',
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'type' => 'entypo',
						'iconsPerPage' => 300, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'icon_library',
						'value' => 'entypo',
					),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'eut-corpus-vc-extension' ),
					'param_name' => 'icon_linecons',
					'value' => 'vc_li vc_li-heart',
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'type' => 'linecons',
						'iconsPerPage' => 200, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'icon_library',
						'value' => 'linecons',
					),
					'description' => __( 'Select icon from library.', 'eut-corpus-vc-extension' ),
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Icon Color", "eut-corpus-vc-extension" ),
					"param_name" => "icon_color",
					"value" => array(
						__( "Primary 1", "eut-corpus-vc-extension" ) => 'primary-1',
						__( "Primary 2", "eut-corpus-vc-extension" ) => 'primary-2',
						__( "Primary 3", "eut-corpus-vc-extension" ) => 'primary-3',
						__( "Primary 4", "eut-corpus-vc-extension" ) => 'primary-4',
						__( "Primary 5", "eut-corpus-vc-extension" ) => 'primary-5',
						__( "Green", "eut-corpus-vc-extension" ) => 'green',
						__( "Orange", "eut-corpus-vc-extension" ) => 'orange',
						__( "Red", "eut-corpus-vc-extension" ) => 'red',
						__( "Blue", "eut-corpus-vc-extension" ) => 'blue',
						__( "Aqua", "eut-corpus-vc-extension" ) => 'aqua',
						__( "Purple", "eut-corpus-vc-extension" ) => 'purple',
						__( "Black", "eut-corpus-vc-extension" ) => 'black',
						__( "Grey", "eut-corpus-vc-extension" ) => 'grey',
						__( "White", "eut-corpus-vc-extension" ) => 'white',
					),
					"description" => __( "Color of the icon.", "eut-corpus-vc-extension" ),
					"dependency" => Array( 'element' => "icon_type", 'value' => array( 'icon' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => __( "Title", "eut-corpus-vc-extension" ),
					"param_name" => "title",
					"value" => "Sample Title",
					"description" => __( "Enter counter title.", "eut-corpus-vc-extension" ),
					"save_always" => true,
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => __( "Heading", "eut-corpus-vc-extension" ),
					"param_name" => "heading",
					"admin_label" => true,
					"value" => array( 'h1', 'h2', 'h3', 'h4' , 'h5', 'h6' ),
					"description" => __( "Heading size", "eut-corpus-vc-extension" ),
					"std" => "h3",
				),
				eut_vce_add_animation(),
				eut_vce_add_animation_delay(),
				eut_vce_add_margin_bottom(),
				eut_vce_add_el_class(),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'eut_counter', 'eut_corpus_vce_counter_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = eut_corpus_vce_counter_shortcode_params( 'eut_counter' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
