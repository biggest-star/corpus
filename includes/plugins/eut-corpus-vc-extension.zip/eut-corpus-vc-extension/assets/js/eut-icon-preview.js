
(function ($) {

	$('.eut-modal-icon-preview').click(function() {
		var selectedIcon = $(this);
		$('.eut-modal-icon-preview').removeClass('eut-selected');
		selectedIcon.addClass('eut-selected');
		selectedIcon.parent().next('input').val(selectedIcon.data( 'icon-value' ));
	});

	var initialIconValue = $('#eut-icon-field').val();
	var thisIconElement = $('.eut-modal-icon-preview.fa-' + initialIconValue );

	if ( thisIconElement.length ) {
		thisIconElement.click();
		$(".eut-modal-select-icon-container").scrollTop( thisIconElement.position().top - 175 );
	}


})(jQuery);