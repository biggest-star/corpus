<?php

/*
 *	Helper functions
 *
 * 	@version	1.0
 * 	@author		Euthemians Team
 * 	@URI		http://euthemians.com
 */

function eut_corpus_vce_starts_with( $haystack, $needle ) {
     $length = strlen($needle);
     return (substr($haystack, 0, $length) === $needle);
}


 /**
 * Generates a button
 * Used in shortcodes to display a button
 */
function eut_corpus_vce_get_button( $button_text, $button_link, $button_type, $button_size, $button_color, $button_shape, $button_extra_class, $style = '' ) {

	$button = "";

	if ( !empty( $button_text ) ) {
		$button_classes = array( 'eut-btn' );

		array_push( $button_classes, 'eut-btn-' . $button_size );
		array_push( $button_classes, 'eut-' . $button_shape );

		if ( eut_corpus_vce_starts_with( $button_color, 'primary' ) ) {
			array_push( $button_classes, 'eut-bg-' . $button_color );
		} else {
			array_push( $button_classes, 'eut-' . $button_color . '-color' );
		}

		if ( 'outline' == $button_type ) {
			array_push( $button_classes, 'eut-btn-line' );
		}

		if ( !empty( $button_extra_class ) ) {
			array_push( $button_classes, $button_extra_class );
		}

		$button_class_string = implode( ' ', $button_classes );

		if ( !empty( $button_link ) ){
			$href = vc_build_link( $button_link );
			$url = $href['url'];
			if ( !empty( $href['target'] ) ){
				$target = $href['target'];
			} else {
				$target = "_self";
			}
		} else {
			$url = "#";
			$target = "_self";
		}
		$target = trim( $target );

		$button .= '<a class="' . esc_attr( $button_class_string ) . '" href="' . esc_url( $url ) . '" target="' . esc_attr( $target ) . '" style="' . $style . '">';
		$button .= '<span>';
		$button .= $button_text;
		$button .= '</span>';
		$button .= '</a>';
	}

	return $button;

}

 /**
 * Fetch Portfolio Categories
 * Used in shortcodes to generate the list of used categories ( back end )
 */
function eut_corpus_vce_get_portfolio_categories() {

	$portfolio_category = array( __( "All Categories", "eut-corpus-vc-extension" ) => "" );

	$portfolio_cats = get_terms( 'portfolio_category' );
	if ( is_array( $portfolio_cats ) ) {
	  foreach ( $portfolio_cats as $portfolio_cat ) {
		$portfolio_category[$portfolio_cat->name] = $portfolio_cat->term_id;
	  }
	}
	return $portfolio_category;

}

 /**
 * Print Portfolio Image
 * Used in portfolio to fetch feature image or link
 */
function eut_corpus_vce_print_portfolio_image( $image_size , $link = '' ) {
	if( function_exists( 'eut_print_portfolio_image' ) ) {
		eut_print_portfolio_image( $image_size , $link );
	}
}

 /**
 * Fetch Testimonial Categories
 * Used in shortcodes to generate the list of used categories ( back end )
 */
function eut_corpus_vce_get_testimonial_categories() {
	$testimonial_category = array( __( "All Categories", "eut-corpus-vc-extension" ) => "" );

	$testimonial_cats = get_terms( 'testimonial_category', array( 'hide_empty' => 0 ) );
	if ( is_array( $testimonial_cats ) ) {
	  foreach ( $testimonial_cats as $testimonial_cat ) {
		$testimonial_category[$testimonial_cat->name] = $testimonial_cat->term_id;
	  }
	}
	return $testimonial_category;
}

 /**
 * Fetch Post Categories
 * Used in shortcodes to generate the list of used categories ( back end )
 */
function eut_corpus_vce_get_post_categories() {
	$category = array( __( "All Categories", "eut-corpus-vc-extension" ) => "" );

	$cats = get_terms( 'category' );
	if ( is_array( $cats ) ) {
	  foreach ( $cats as $cat ) {
		$category[$cat->name] = $cat->term_id;
	  }
	}
	return $category;
}


 /**
 * Generates dimension string to concat in attribute style
 */
function eut_corpus_vce_build_dimension( $dimension, $value ) {
	$fixed_dimension = '';

	if( ! empty( $dimension ) &&  ! empty( $value )  ) {
		$fixed_dimension .= $dimension . ': '.(preg_match('/(px|em|\%|pt|cm)$/', $value) ? $value : $value.'px').';';
	}
	return $fixed_dimension;
}

 /**
 * Generates margin-bottom string to concat in attribute style
 */
function eut_corpus_vce_build_margin_bottom_style( $margin_bottom ) {
	$style = '';
	if( $margin_bottom != '' ) {
		$style .= 'margin-bottom: '.(preg_match('/(px|em|\%|pt|cm)$/', $margin_bottom) ? $margin_bottom : $margin_bottom .'px').';';
		$style = esc_attr( $style );
	}
	return $style;
}

 /**
 * Generates padding-top string to concat in attribute style
 */
function eut_corpus_vce_build_padding_top_style( $padding_top ) {
	$style = '';
	if( $padding_top != '' ) {
		$style .= 'padding-top: '.(preg_match('/(px|em|\%|pt|cm)$/', $padding_top) ? $padding_top : $padding_top.'px').';';
		$style = esc_attr( $style );
	}
	return $style;
}

 /**
 * Generates padding-bottom string to concat in attribute style
 */
function eut_corpus_vce_build_padding_bottom_style( $padding_bottom ) {
	$style = '';
	if( $padding_bottom != '' ) {
		$style .= 'padding-bottom: '.(preg_match('/(px|em|\%|pt|cm)$/', $padding_bottom) ? $padding_bottom : $padding_bottom.'px').';';
		$style = esc_attr( $style );
	}
	return $style;
}

 /**
 * Prints blog class depending on the blog style
 */
function eut_corpus_vce_get_blog_class( $eut_blog_style = 'large-media'  ) {

	switch( $eut_blog_style ) {

		case 'small-media':
			$eut_blog_style_class = 'eut-blog eut-small-media eut-non-isotope';
			break;
		case 'masonry':
			$eut_blog_style_class = 'eut-blog eut-blog-masonry eut-isotope eut-with-gap';
			break;
		case 'grid':
			$eut_blog_style_class = 'eut-blog eut-blog-grid eut-isotope eut-with-gap';
			break;
		case 'carousel':
			$eut_blog_style_class = 'eut-carousel-wrapper';
			break;
		case 'large-media':
		default:
			$eut_blog_style_class = 'eut-blog eut-large-media eut-non-isotope';
			break;

	}

	return $eut_blog_style_class;

}


 /**
 * Prints excerpt depending on the blog style and post format
 */
function eut_corpus_vce_print_post_title( $blog_style, $post_format ) {
	global $allowedposttags;
	$mytags = $allowedposttags;

		$title_size = '6';
	if( 'large-media' == $blog_style || 'small-media' == $blog_style  ) {
		$title_size = '5';
	}
	if( 'carousel' == $blog_style ) {
		$title_size = '6';
	}

	switch( $post_format ) {
		case 'link':
			if( 'carousel' == $blog_style ) {
				the_title( '<a ' . eut_corpus_vce_print_post_link( 'link' ) . ' rel="bookmark"><h' . $title_size . ' class="eut-post-title" itemprop="name headline">', '</h' . $title_size . '></a>' );
			} else {
				unset($mytags['a']);
				unset($mytags['img']);
				unset($mytags['p']);
				$content = wp_kses(get_the_content(), $mytags);
				echo '<a ' . eut_corpus_vce_print_post_link( 'link' ) . ' rel="bookmark">';
				the_title( '<h4 class="eut-post-title" itemprop="name headline">', '</h4>' );
				echo '<p itemprop="articleBody">' . $content . '</p>';
				echo '<div class="eut-subtitle">' . eut_corpus_vce_print_post_link( 'link', 'url' ) . '</div>';
				echo '</a>';
			}
			break;
		case 'quote':
			if( 'carousel' == $blog_style ) {
				the_title( '<a href="' . esc_url( get_permalink() ) . '" rel="bookmark"><h' . $title_size . ' class="eut-post-title" itemprop="name headline">', '</h' . $title_size . '></a>' );
			} else {
				the_title( '<h4 class="eut-hidden" itemprop="name headline">', '</h4>' );
				unset($mytags['a']);
				unset($mytags['img']);
				unset($mytags['p']);
				unset($mytags['blockquote']);
				$content = wp_kses(get_the_content(), $mytags);

				echo '<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">';
				echo '<p class="eut-leader-text" itemprop="articleBody">' . $content . '</p>';
				eut_corpus_vce_print_post_date();
				echo '</a>';
			}
			break;
		default:
			 the_title( '<a href="' . esc_url( get_permalink() ) . '" rel="bookmark"><h' . $title_size . ' class="eut-post-title" itemprop="name headline"><span>', '</span></h' . $title_size . '></a>' );
			break;
	}

}

 /**
 * Prints post link
 */
function eut_corpus_vce_print_post_link( $post_format = 'standard', $mode = '' ) {
	global $post;
	$post_id = $post->ID;

	$eut_link = get_permalink();
	$eut_target = '_self';

	if ( 'link' == $post_format ) {
		$eut_link = get_post_meta( $post_id, 'eut_post_link_url', true );
		$new_window = get_post_meta( $post_id, 'eut_post_link_new_window', true );

		if( empty( $eut_link ) ) {
			$eut_link = get_permalink();
		}

		if( !empty( $new_window ) ) {
			$eut_target = '_blank';
		}

		if ( 'url' == $mode ) {
			return $eut_link;
		}
	}

	return 'href="' . esc_url( $eut_link ) . '" target="' . $eut_target . '"';

}

/**
 * Prints excerpt depending on the blog style and post format
 */
function eut_corpus_vce_print_post_excerpt( $blog_style, $post_format, $autoexcerpt = '', $excerpt_length = '55', $excerpt_more = '' ) {

	if ( 'link' == $post_format || 'quote' == $post_format ) {
		return;
	}

	echo '<div itemprop="articleBody">';
	switch( $blog_style ) {
		case 'large-media':
			if ( empty( $autoexcerpt ) ) {
				if ( empty( $excerpt_more ) ) {
					the_content( '' );
				} else {
					global $more;
					$more = 0;
					the_content( eut_corpus_vce_read_more_string() );
				}
			} else {
				echo eut_corpus_vce_excerpt( $excerpt_length, $excerpt_more );
			}
			break;
		default:
			echo eut_corpus_vce_excerpt( $excerpt_length, $excerpt_more );
			break;
	}
	echo '</div>';

}

/**
 * Returns read more link
 */
function eut_corpus_vce_read_more( $post_id = '' ) {
	if ( empty( $post_id ) ) {
		$post_id = get_the_ID();
	}
	$read_more_string =  apply_filters( 'eut_vce_string_read_more', __( 'read more', 'eut-corpus-vc-extension' ) );
    return '<a class="eut-read-more" href="' .  esc_url( get_permalink( $post_id ) ) . '"><span>' . esc_html( $read_more_string ) . '</span></a>';
}

/**
 * Returns read more string
 */
function eut_corpus_vce_read_more_string() {
	$read_more_string =  apply_filters( 'eut_vce_string_read_more', __( 'read more', 'eut-corpus-vc-extension' ) );
    return esc_html( $read_more_string );
}

/**
 * Returns excerpt
 */
function eut_corpus_vce_excerpt( $limit, $more = "" ) {
	global $post;
	$post_id = $post->ID;

	if ( has_excerpt( $post_id ) ) {
		$excerpt = apply_filters( 'the_excerpt', $post->post_excerpt );
		if ( 'yes' == $more ) {
			$excerpt .= eut_corpus_vce_read_more( $post_id );
		}
	} else {
		$content = get_the_content('');
		$content = do_shortcode( $content );
		$content = apply_filters('the_content', $content);
		$content = str_replace(']]>', ']]>', $content);
		if ( 'yes' == $more ) {
			$excerpt = '<p>' . wp_trim_words( $content, $limit ) . '</p>';
			$excerpt .= eut_corpus_vce_read_more( $post_id );
		} else{
			$excerpt = '<p>' . wp_trim_words( $content, $limit ) . '</p>';
		}
	}
	return	$excerpt;
}


/**
 * Get empty fallback image
 */
function eut_corpus_vce_get_empty_image( $image_size = 'eut-image-small-rect-horizontal' ) {

	$image_src = EUT_CORPUS_VC_EXT_PLUGIN_DIR_URL .'assets/images/empty/' . $image_size . '.jpg';
	return '<img src="' . esc_url( $image_src ) . '" alt="no image">';

}

/**
 * Prints feature media depending on the blog style and post format
 */
function eut_corpus_vce_print_carousel_media( $image_size = 'eut-image-small-rect-horizontal' ) {
	global $post;
	$post_id = $post->ID;
	$image_src = EUT_CORPUS_VC_EXT_PLUGIN_DIR_URL .'assets/images/empty/' . $image_size . '.jpg';
?>
		<div class="eut-media eut-image-hover">
			<?php if ( has_post_thumbnail( $post_id ) ) { ?>
			<a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_post_thumbnail( $image_size ); ?></a>
			<?php } else { ?>
			<a class="eut-no-image" href="<?php echo esc_url( get_permalink() ); ?>"><img src="<?php echo esc_url( $image_src ); ?>" alt="no image"></a>
			<?php } ?>

		</div>
<?php
}

/**
 * Prints feature media depending on the blog style and post format
 */
function eut_corpus_vce_print_post_feature_media( $eut_blog_style = 'large-media', $post_format, $blog_image_mode, $blog_image_prio ) {
	global $post, $wp_embed;

	$post_id = $post->ID;
	if ( 'resize' == $blog_image_mode ) {
		switch( $eut_blog_style ) {
			case 'large-media':
				$image_size = 'eut-image-fullscreen';
			break;
			default:
				$image_size = 'large';
			break;
		}
	} elseif ( 'large' == $blog_image_mode  ) {
		$image_size = 'large';
	} elseif( 'medium_large' == $blog_image_mode ) {
		$image_size = 'medium_large';
	} elseif( 'medium' == $blog_image_mode ) {
		$image_size = 'medium';
	} else {
		switch( $eut_blog_style ) {
			case 'large-media':
				$image_size = 'eut-image-large-rect-horizontal';
			break;
			case 'masonry' :
				$image_size = 'eut-image-small-rect-horizontal';
			break;
			default:
				$image_size = 'eut-image-small-rect-horizontal-wide';
			break;
		}
	}

	if ( ( '' == $post_format || 'image' == $post_format || 'yes' == $blog_image_prio ) &&  has_post_thumbnail( $post_id ) ) {
?>
		<div class="eut-media eut-image-hover">
			<a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_post_thumbnail( $image_size ); ?></a>
		</div>
<?php

	} else if ( 'audio' == $post_format ) {

		$audio_mode = get_post_meta( $post_id, 'eut_post_type_audio_mode', true );
		$audio_mp3 = get_post_meta( $post_id, 'eut_post_audio_mp3', true );
		$audio_ogg = get_post_meta( $post_id, 'eut_post_audio_ogg', true );
		$audio_wav = get_post_meta( $post_id, 'eut_post_audio_wav', true );
		$audio_embed = get_post_meta( $post_id, 'eut_post_audio_embed', true );

		if( empty( $audio_mode ) && !empty( $audio_embed ) ) {
			echo '<div class="eut-media">' . $audio_embed . '</div>';
		} else {

			if ( !empty( $audio_mp3 ) || !empty( $audio_ogg ) || !empty( $audio_wav ) ) {

				$audio_output = '[audio ';

				if ( !empty( $audio_mp3 ) ) {
					$audio_output .= 'mp3="'. esc_url( $audio_mp3 ) .'" ';
				}
				if ( !empty( $audio_ogg ) ) {
					$audio_output .= 'ogg="'. esc_url( $audio_ogg ) .'" ';
				}
				if ( !empty( $audio_wav ) ) {
					$audio_output .= 'wav="'. esc_url ( $audio_wav ) .'" ';
				}

				$audio_output .= ']';

				echo '<div class="eut-media">';
				echo  do_shortcode( $audio_output );
				echo '</div>';

			}
		}
	} else if ( 'video' == $post_format ) {

		$video_mode = get_post_meta( $post_id, 'eut_post_type_video_mode', true );
		$video_embed = get_post_meta( $post_id, 'eut_post_video_embed', true );

		$video_output = '';

		if( empty( $video_mode ) && !empty( $video_embed ) ) {
			$video_output .= '<div class="eut-media">';
			$video_output .= $wp_embed->run_shortcode( '[embed]' . $video_embed . '[/embed]' );
			$video_output .= '</div>';
		} else {
			$video_webm = get_post_meta( $post_id, 'eut_post_video_webm', true );
			$video_mp4 = get_post_meta( $post_id, 'eut_post_video_mp4', true );
			$video_ogv = get_post_meta( $post_id, 'eut_post_video_ogv', true );
			$video_poster = get_post_meta( $post_id, 'eut_post_video_poster', true );

			$video_attr = '';
			$video_settings = array(
				'controls' => 'yes',
				'poster' => $video_poster,
			);
			$video_settings = apply_filters( 'eut_vce_media_video_settings', $video_settings );

			if ( function_exists( 'eut_print_media_video_settings' ) ) {
				$video_attr = eut_print_media_video_settings( $video_settings );
			} else {
				$video_attr = ' controls';
			}
			if ( !empty( $video_webm ) || !empty( $video_mp4 ) || !empty( $video_ogv ) ) {
				$video_output .= '<div class="eut-media">';
				$video_output .= '  <video ' . $video_attr . '>';

				if ( !empty( $video_webm ) ) {
					$video_output .= '<source src="' . esc_url( $video_webm ) . '" type="video/webm">';
				}
				if ( !empty( $video_mp4 ) ) {
					$video_output .= '<source src="' . esc_url( $video_mp4 ) . '" type="video/mp4">';
				}
				if ( !empty( $video_ogv ) ) {
					$video_output .= '<source src="' . esc_url( $video_ogv ) . '" type="video/ogg">';
				}
				$video_output .='  </video>';
				$video_output .= '</div>';

			}
		}
		echo  $video_output;
	} else if ( 'gallery' == $post_format ) {

		$slider_items = get_post_meta( $post_id, 'eut_post_slider_items', true );

		$gallery_mode = get_post_meta( $post_id, 'eut_post_type_gallery_mode', true );
		if ( empty( $gallery_mode ) ) {
			$gallery_mode = 'gallery';
		} else {
			$gallery_mode = 'slider';
		}

		if ( !empty( $slider_items ) ) {
			switch( $eut_blog_style ) {
				case 'large-media':
					$image_size = 'eut-image-large-rect-horizontal';
				break;
				case 'masonry' :
					$image_size = 'eut-image-small-rect-horizontal';
				break;
				default:
					$image_size = 'eut-image-small-rect-horizontal-wide';
				break;
			}
			eut_corpus_vce_print_gallery_slider( $gallery_mode, $slider_items, $image_size  );
		}

	}

}

 /**
 * Prints Gallery or Slider
 */
function eut_corpus_vce_print_gallery_slider( $gallery_mode, $slider_items, $image_size_slider ) {

	$image_size_gallery_thumb = 'eut-image-small-square';

	if ( $gallery_mode == 'gallery' ) {

?>
	<div class="eut-media">
		<ul class="eut-post-gallery eut-post-gallery-popup">
<?php
	foreach ( $slider_items as $slider_item ) {

		$media_id = $slider_item['id'];
		$full_src = wp_get_attachment_image_src( $media_id, 'full' );
		$image_full_url = $full_src[0];

		$caption = get_post_field( 'post_excerpt', $media_id );

		$figcaption = '';
		if	( !empty( $caption ) ) {
			$figcaption = wptexturize( $caption );
		}
		echo '<li class="eut-image-hover">';
		echo '<a title="' . esc_attr( $figcaption ) . '" href="' . esc_url( $image_full_url ) . '">';
		echo wp_get_attachment_image( $media_id, $image_size_gallery_thumb );
		echo '</a>';
		echo '</li>';
	}
?>
		</ul>
	</div>
<?php

	} else {
?>
		<div class="eut-media">
			<div class="eut-element eut-carousel-wrapper">
				<div class="eut-carousel-navigation eut-dark" data-navigation-type="2">
					<div class="eut-carousel-buttons">
						<div class="eut-carousel-prev eut-icon-nav-left"></div>
						<div class="eut-carousel-next eut-icon-nav-right"></div>
					</div>
				</div>
				<div class="eut-slider eut-carousel-element " data-slider-speed="2500" data-slider-pause="yes" data-slider-autoheight="no">
<?php
					foreach ( $slider_items as $slider_item ) {
						$media_id = $slider_item['id'];
						echo '<div class="eut-slider-item">';
						echo wp_get_attachment_image( $media_id, $image_size_slider );
						echo '</div>';
					}
?>
				</div>
			</div>
		</div>
<?php
	}
}

 /**
 * Prints post categories depending on the blog style
 */
function eut_corpus_vce_print_post_categories( $eut_blog_style = 'large-media' ) {

	$show_categories = false;
	if ( is_singular() ) {
		$show_categories = true;
	} else {
		switch( $eut_blog_style ) {

			case 'small-media':
			case 'large-media':
			default:
				$show_categories = true;
				break;
		}
	}

	if ( $show_categories ) {
		$in_categories_string =  apply_filters( 'eut_vce_blog_string_categories_in', __( 'in', 'eut-corpus-vc-extension' ) );
?>
		<span class="eut-post-categories">
			<?php echo esc_html( $in_categories_string ) . ' '; ?><?php the_category(', '); ?>
		</span>
<?php

	}

}

 /**
 * Prints post date
 */
function eut_corpus_vce_print_post_date() {

	if( function_exists( 'eut_visibility' ) && eut_visibility( 'blog_date_visibility', '1' ) ) {
?>
	<time class="eut-post-date" datetime="<?php the_time('c'); ?>">
		<?php echo get_the_date(); ?>
	</time>
<?php
	}
}

 /**
 * Prints post date meta
 */
function eut_corpus_vce_print_post_date_meta() {
?>
	<meta content="<?php the_time('c'); ?>"/>
<?php
}

 /**
 * Prints post comments
 */
function eut_corpus_vce_print_post_comments() {
	$no_comments_string =  apply_filters( 'eut_vce_blog_string_no_comments', __( 'no comments', 'eut-corpus-vc-extension' ) );
	$one_comment_string =  apply_filters( 'eut_vce_blog_string_one_comment', __( '1 comment', 'eut-corpus-vc-extension' ) );
	$comments_string =  apply_filters( 'eut_vce_blog_string_comments', __( 'comments', 'eut-corpus-vc-extension' ) );
?>
	<span class="eut-post-comments">
		<a href="<?php the_permalink(); ?>#commentform"><?php comments_number( esc_html( $no_comments_string ), esc_html( $one_comment_string ), '% ' . esc_html( $comments_string ) ); ?></a>
	</span>
<?php
}

 /**
 * Prints post author avatar
 */
function eut_corpus_vce_print_post_author( $eut_blog_style, $post_format ) {
	if ( 'large-media' == $eut_blog_style ) {
		if ( 'quote' != $post_format && 'link' != $post_format ) {
?>
	<div class="eut-post-author">
		<?php echo get_avatar( get_the_author_meta( 'ID' ), 80 ); ?>
	</div>
<?php
		}
	}
}

 /**
 * Prints post author by depending on the blog style
 */
function eut_corpus_vce_print_post_author_by( $eut_blog_style = 'large-media' ) {

	switch( $eut_blog_style ) {

		case 'small-media':
		case 'large-media':
		case 'masonry':
		case 'grid':
			$show_author_by = true;
			break;
		default:
			$show_author_by = false;
			break;
	}
	if( function_exists( 'eut_visibility' ) && !eut_visibility( 'blog_author_visibility', '1' ) ) {
		$show_author_by = false;
	}


	if ( $show_author_by ) {
		$author_by_string =  apply_filters( 'eut_vce_blog_string_by_author', __( 'By', 'eut-corpus-vc-extension' ) );
?>
		<div class="eut-post-author">
			<span><?php echo esc_html( $author_by_string ) . ' '; ?></span><span><?php the_author_posts_link(); ?></span>
		</div>
<?php

	}

}


/**
 * Gets post class depending on the blog style
 */
function eut_corpus_vce_get_post_class( $eut_blog_style = 'large-media', $extra_class = '' ) {

	$post_classes = array( 'eut-blog-item' );
	if ( !empty( $extra_class ) ){
		array_push( $post_classes, $extra_class );
	}

	switch( $eut_blog_style ) {

		case 'large-media':
			array_push( $post_classes, 'eut-big-post' );
			array_push( $post_classes, 'eut-non-isotope-item' );
			break;

		case 'small-media':
			array_push( $post_classes, 'eut-small-post' );
			array_push( $post_classes, 'eut-non-isotope-item' );
			break;

		case 'masonry':
		case 'grid':
			array_push( $post_classes, 'eut-isotope-item' );
			break;

		default:
			break;

	}

	return implode( ' ', $post_classes );

}

function eut_corpus_vce_get_image_size( $image_mode ) {

	switch( $image_mode ) {
		case 'thumbnail':
			$image_size = 'thumbnail';
		break;
		case 'medium':
			$image_size = 'medium';
		break;
		case 'large':
			$image_size = 'large';
		break;
		case 'square':
			$image_size = 'eut-image-small-square';
		break;
		case 'landscape':
			$image_size = 'eut-image-small-rect-horizontal';
		break;
		case 'landscape-wide':
			$image_size = 'eut-image-small-rect-horizontal-wide';
		break;
		case 'portrait':
			$image_size = 'eut-image-small-rect-vertical';
		break;
		default:
			$image_size = 'full';
		break;
	}

	return $image_size;

}

function eut_corpus_vce_get_custom_masonry_data( $size = 'square' ) {

	switch( $size ) {
		case 'landscape':
			$image_size_class = "eut-image-landscape";
			$image_size = 'eut-image-medium-square';
			break;
		case 'portrait':
			$image_size_class = "eut-image-portrait";
			$image_size = 'eut-image-medium-rect-vertical';
			break;
		case 'large-square':
			$image_size_class = "eut-image-large-square";
			$image_size = 'eut-image-medium-square';
			break;
		case 'square':
		default:
			$image_size_class = "eut-image-square";
			$image_size = 'eut-image-small-square';
			break;
	}
	return array(
		'class' => $image_size_class,
		'image_size' => $image_size,
	);
}

function eut_corpus_vce_get_masonry_data( $index, $columns ) {

	$image_size_class = "eut-image-square";
	$image_size = 'eut-image-small-square';

	if( '2' == $columns ) {

		if ( $index % 2  == 0 ) {
			$image_size_class = "eut-image-portrait";
			$image_size = "eut-image-medium-rect-vertical";
		}
		if ( $index % 4  == 0 ) {
			$image_size_class = "eut-image-square";
			$image_size = 'eut-image-small-square';
		}
		if ( $index % 5  == 0 ) {
			$image_size_class = "eut-image-landscape";
			$image_size = 'eut-image-medium-square';
		}
		if ( $index % 6  == 0 ) {
			$image_size_class = "eut-image-square";
			$image_size = 'eut-image-small-square';
		}
		if ( $index % 8  == 0 ) {
			$image_size_class = "eut-image-landscape";
			$image_size = 'eut-image-medium-square';
		}
		if ( $index % 9  == 0 ) {
			$image_size_class = "eut-image-portrait";
			$image_size = "eut-image-medium-rect-vertical";
		}
		if ( $index % 10  == 0 ) {
			$image_size_class = "eut-image-square";
			$image_size = 'eut-image-small-square';
		}
		if ( $index % 15  == 0 ) {
			$image_size_class = "eut-image-square";
			$image_size = 'eut-image-small-square';
		}
		if ( $index % 16  == 0 ) {
			$image_size_class = "eut-image-square";
			$image_size = 'eut-image-small-square';
		}
	}

	if( '3' == $columns ) {

		if ( $index % 4  == 0 ) {
			$image_size_class = "eut-image-landscape";
			$image_size = 'eut-image-medium-square';
		}
		if ( $index % 7  == 0 ) {
			$image_size_class = "eut-image-large-square";
			$image_size = 'eut-image-medium-square';
		}
		if ( $index % 8  == 0 ) {
			$image_size_class = "eut-image-square";
			$image_size = 'eut-image-small-square';
		}
	}

	if( '4' == $columns ) {

		if ( $index % 3  == 0 ) {
			$image_size_class = "eut-image-portrait";
			$image_size = "eut-image-medium-rect-vertical";
		}
		if ( $index % 5  == 0 ) {
			$image_size_class = "eut-image-landscape";
			$image_size = 'eut-image-medium-square';
		}
		if ( $index % 6  == 0 ) {
			$image_size_class = "eut-image-square";
			$image_size = 'eut-image-small-square';
		}
		if ( $index % 7  == 0 ) {
			$image_size_class = "eut-image-large-square";
			$image_size = 'eut-image-medium-square';
		}
		if ( $index % 10  == 0 ) {
			$image_size_class = "eut-image-square";
			$image_size = 'eut-image-small-square';
		}
		if ( $index % 14  == 0 ) {
			$image_size_class = "eut-image-square";
			$image_size = 'eut-image-small-square';
		}

	}

	if( '5' == $columns ) {

		if ( $index % 3  == 0 ) {
			$image_size_class = "eut-image-portrait";
			$image_size = "eut-image-medium-rect-vertical";
		}
		if ( $index % 6  == 0 ) {
			$image_size_class = "eut-image-landscape";
			$image_size = 'eut-image-medium-square';
		}
		if ( $index % 9  == 0 ) {
			$image_size_class = "eut-image-large-square";
			$image_size = 'eut-image-medium-square';
		}
	}

	return array(
		'class' => $image_size_class,
		'image_size' => $image_size,
	);
}

function eut_corpus_vce_text_to_bool( $value ) {
	if ( 'yes' == $value ) {
		return 'true';
	}
	return 'false';
}

/**
 * Prints post structured data
 */
function corpus_ext_vce_print_structured_data( $args = array() ) {
	if( function_exists( 'corpus_eutf_print_post_structured_data' ) ) {
		corpus_eutf_print_post_structured_data( $args );
	}
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
