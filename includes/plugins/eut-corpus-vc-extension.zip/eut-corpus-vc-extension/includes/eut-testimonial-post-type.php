<?php
/*
*	Testimonial Post Type Registration
*
* 	@author		Euthemians Team
* 	@URI		http://euthemians.com
*/

if ( ! class_exists( 'EUT_Testimonial_Post_Type' ) ) {
	class EUT_Testimonial_Post_Type {

		function __construct() {

			// Adds the testimonial post type and taxonomies
			$this->eut_testimonial_init();

			// Manage Columns for testimonial overview
			add_filter( 'manage_edit-testimonial_columns',  array( &$this, 'eut_testimonial_edit_columns' ) );
			add_action( 'manage_posts_custom_column', array( &$this, 'eut_testimonial_custom_columns' ), 10, 2 );

		}

		function eut_testimonial_init() {


			$labels = array(
				'name' => _x( 'Testimonial Items', 'Testimonial General Name', 'eut-corpus-vc-extension' ),
				'singular_name' => _x( 'Testimonial Item', 'Testimonial Singular Name', 'eut-corpus-vc-extension' ),
				'add_new' => __( 'Add New', 'eut-corpus-vc-extension' ),
				'add_new_item' => __( 'Add New Testimonial Item', 'eut-corpus-vc-extension' ),
				'edit_item' => __( 'Edit Testimonial Item', 'eut-corpus-vc-extension' ),
				'new_item' => __( 'New Testimonial Item', 'eut-corpus-vc-extension' ),
				'view_item' => __( 'View Testimonial Item', 'eut-corpus-vc-extension' ),
				'search_items' => __( 'Search Testimonial Items', 'eut-corpus-vc-extension' ),
				'not_found' =>  __( 'No Testimonial Items found', 'eut-corpus-vc-extension' ),
				'not_found_in_trash' => __( 'No Testimonial Items found in Trash', 'eut-corpus-vc-extension' ),
				'parent_item_colon' => '',
			);

			$category_labels = array(
				'name' => __( 'Testimonial Categories', 'eut-corpus-vc-extension' ),
				'singular_name' => __( 'Testimonial Category', 'eut-corpus-vc-extension' ),
				'search_items' => __( 'Search Testimonial Categories', 'eut-corpus-vc-extension' ),
				'all_items' => __( 'All Testimonial Categories', 'eut-corpus-vc-extension' ),
				'parent_item' => __( 'Parent Testimonial Category', 'eut-corpus-vc-extension' ),
				'parent_item_colon' => __( 'Parent Testimonial Category:', 'eut-corpus-vc-extension' ),
				'edit_item' => __( 'Edit Testimonial Category', 'eut-corpus-vc-extension' ),
				'update_item' => __( 'Update Testimonial Category', 'eut-corpus-vc-extension' ),
				'add_new_item' => __( 'Add New Testimonial Category', 'eut-corpus-vc-extension' ),
				'new_item_name' => __( 'New Testimonial Category Name', 'eut-corpus-vc-extension' ),
			);

			$args = array(
				'labels' => $labels,
				'public' => true,
				'publicly_queryable' => true,
				'show_ui' => true,
				'query_var' => true,
				'rewrite' => true,
				'capability_type' => 'post',
				'hierarchical' => false,
				'menu_position' => 5,
				'menu_icon' => 'dashicons-testimonial',
				'supports' => array( 'title', 'editor', 'author' ),
				'rewrite' => array( 'slug' => 'testimonial', 'with_front' => false ),
			  );

			register_post_type( 'testimonial' , $args );

			register_taxonomy(
				'testimonial_category',
				array( 'testimonial' ),
				array(
					'hierarchical' => true,
					'label' => __( 'Testimonial Categories', 'eut-corpus-vc-extension' ),
					'labels' => $category_labels,
					'show_in_nav_menus' => false,
					'show_tagcloud' => false,
					'rewrite' => true,
				)
			);
			register_taxonomy_for_object_type( 'testimonial_category', 'testimonial' );

		}

		function eut_testimonial_edit_columns( $columns ) {

			$columns['cb'] = "<input type=\"checkbox\" />";
			$columns['title'] = __( 'Title', 'eut-corpus-vc-extension' );
			$columns['author'] = __( 'Author', 'eut-corpus-vc-extension' );
			$columns['testimonial_category'] = __( 'Testimonial Categories', 'eut-corpus-vc-extension' );
			$columns['date'] = __( 'Date', 'eut-corpus-vc-extension' );

			return $columns;
		}

		function eut_testimonial_custom_columns( $column, $post_id ) {

			switch ( $column ) {
				case 'testimonial_category':
					echo get_the_term_list( $post_id, 'testimonial_category', '', ', ','' );
				break;
			}
		}

	}
	new EUT_Testimonial_Post_Type;
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
