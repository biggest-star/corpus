<?php
/*
*	Portfolio Post Type Registration
*
* 	@author		Euthemians Team
* 	@URI		http://euthemians.com
*/

if ( ! class_exists( 'EUT_Portfolio_Post_Type' ) ) {
	class EUT_Portfolio_Post_Type {

		function __construct() {

			// Adds the portfolio post type and taxonomies
			$this->eut_portfolio_init();

			// Manage Columns for portfolio overview
			add_filter( 'manage_edit-portfolio_columns',  array( &$this, 'eut_portfolio_edit_columns' ) );
			add_action( 'manage_posts_custom_column', array( &$this, 'eut_portfolio_custom_columns' ), 10, 2 );

		}

		function eut_portfolio_init() {

			$portfolio_base_slug = 'portfolio';
			if ( function_exists( 'eut_option' ) ) {
				$portfolio_base_slug = eut_option( 'portfolio_slug', 'portfolio' );
			}


			$labels = array(
				'name' => _x( 'Portfolio Items', 'Portfolio General Name', 'eut-corpus-vc-extension' ),
				'singular_name' => _x( 'Portfolio Item', 'Portfolio Singular Name', 'eut-corpus-vc-extension' ),
				'add_new' => __( 'Add New', 'eut-corpus-vc-extension' ),
				'add_new_item' => __( 'Add New Portfolio Item', 'eut-corpus-vc-extension' ),
				'edit_item' => __( 'Edit Portfolio Item', 'eut-corpus-vc-extension' ),
				'new_item' => __( 'New Portfolio Item', 'eut-corpus-vc-extension' ),
				'view_item' => __( 'View Portfolio Item', 'eut-corpus-vc-extension' ),
				'search_items' => __( 'Search Portfolio Items', 'eut-corpus-vc-extension' ),
				'not_found' =>  __( 'No Portfolio Items found', 'eut-corpus-vc-extension' ),
				'not_found_in_trash' => __( 'No Portfolio Items found in Trash', 'eut-corpus-vc-extension' ),
				'parent_item_colon' => '',
			);

			$category_labels = array(
				'name' => __( 'Portfolio Categories', 'eut-corpus-vc-extension' ),
				'singular_name' => __( 'Portfolio Category', 'eut-corpus-vc-extension' ),
				'search_items' => __( 'Search Portfolio Categories', 'eut-corpus-vc-extension' ),
				'all_items' => __( 'All Portfolio Categories', 'eut-corpus-vc-extension' ),
				'parent_item' => __( 'Parent Portfolio Category', 'eut-corpus-vc-extension' ),
				'parent_item_colon' => __( 'Parent Portfolio Category:', 'eut-corpus-vc-extension' ),
				'edit_item' => __( 'Edit Portfolio Category', 'eut-corpus-vc-extension' ),
				'update_item' => __( 'Update Portfolio Category', 'eut-corpus-vc-extension' ),
				'add_new_item' => __( 'Add New Portfolio Category', 'eut-corpus-vc-extension' ),
				'new_item_name' => __( 'New Portfolio Category Name', 'eut-corpus-vc-extension' ),
			);

			$field_labels = array(
				'name' => __( 'Portfolio Fields', 'eut-corpus-vc-extension' ),
				'singular_name' => __( 'Portfolio Field', 'eut-corpus-vc-extension' ),
				'search_items' => __( 'Search Portfolio Fields', 'eut-corpus-vc-extension' ),
				'all_items' => __( 'All Portfolio Fields', 'eut-corpus-vc-extension' ),
				'parent_item' => __( 'Parent Portfolio Field', 'eut-corpus-vc-extension' ),
				'parent_item_colon' => __( 'Parent Portfolio Field:', 'eut-corpus-vc-extension' ),
				'edit_item' => __( 'Edit Portfolio Field', 'eut-corpus-vc-extension' ),
				'update_item' => __( 'Update Portfolio Field', 'eut-corpus-vc-extension' ),
				'add_new_item' => __( 'Add New Portfolio Field', 'eut-corpus-vc-extension' ),
				'new_item_name' => __( 'New Portfolio Field Name', 'eut-corpus-vc-extension' ),
			);

			$args = array(
				'labels' => $labels,
				'public' => true,
				'publicly_queryable' => true,
				'show_ui' => true,
				'query_var' => true,
				'rewrite' => true,
				'capability_type' => 'post',
				'hierarchical' => false,
				'menu_position' => 5,
				'menu_icon' => 'dashicons-format-gallery',
				'supports' => array( 'title', 'editor', 'author', 'excerpt', 'thumbnail', 'custom-fields', 'comments' ),
				'rewrite' => array( 'slug' => $portfolio_base_slug, 'with_front' => false ),
			);

			register_post_type( 'portfolio' , $args );

			register_taxonomy(
				'portfolio_category',
				array( 'portfolio' ),
				array(
					'hierarchical' => true,
					'label' => __( 'Portfolio Categories', 'eut-corpus-vc-extension' ),
					'labels' => $category_labels,
					'show_in_nav_menus' => false,
					'show_tagcloud' => false,
					'rewrite' => true,
				)
			);
			register_taxonomy_for_object_type( 'portfolio_category', 'portfolio' );

			register_taxonomy(
				'portfolio_field',
				array( 'portfolio' ),
				array(
					'hierarchical' => true,
					'label' => __( 'Portfolio Fields', 'eut-corpus-vc-extension' ),
					'labels' => $field_labels,
					'show_in_nav_menus' => false,
					'show_tagcloud' => false,
					'rewrite' => true,
				)
			);
			register_taxonomy_for_object_type( 'portfolio_field', 'portfolio' );

		}

		function eut_portfolio_edit_columns( $columns ) {

			$columns['cb'] = "<input type=\"checkbox\" />";
			$columns['title'] = __( 'Title', 'eut-corpus-vc-extension' );
			$columns['portfolio_thumbnail'] = __( 'Featured Image', 'eut-corpus-vc-extension' );
			$columns['author'] = __( 'Author', 'eut-corpus-vc-extension' );
			$columns['portfolio_category'] = __( 'Portfolio Categories', 'eut-corpus-vc-extension' );
			$columns['portfolio_field'] = __( 'Portfolio Fields', 'eut-corpus-vc-extension' );
			$columns['date'] = __( 'Date', 'eut-corpus-vc-extension' );

			return $columns;
		}

		function eut_portfolio_custom_columns( $column, $post_id ) {

			switch ( $column ) {
				case "portfolio_thumbnail":
					if ( has_post_thumbnail( $post_id ) ) {
						$thumbnail_id = get_post_thumbnail_id( $post_id );
						$attachment_src = wp_get_attachment_image_src( $thumbnail_id, array( 80, 80 ) );
						$thumb = $attachment_src[0];
					} else {
						$thumb = get_template_directory_uri() . '/includes/images/no-image.jpg';
					}
					echo '<img class="attachment-80x80" width="80" height="80" alt="portfolio image" src="' . esc_url( $thumb ) . '">';
					break;
				case 'portfolio_category':
					echo get_the_term_list( $post_id, 'portfolio_category', '', ', ','' );
				break;
				case 'portfolio_field':
					echo get_the_term_list( $post_id, 'portfolio_field', '', ', ','' );
				break;
			}
		}

	}
	new EUT_Portfolio_Post_Type;
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
