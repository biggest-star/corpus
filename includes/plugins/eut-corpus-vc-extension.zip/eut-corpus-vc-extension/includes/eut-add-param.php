<?php

/*
 *	Helper functions
 *
 * 	@version	1.0
 * 	@author		Euthemians Team
 * 	@URI		http://euthemians.com
 */



 /**
 * Generic Parameters to reuse
 * Used in vc shortcodes
 */

if( !function_exists( 'eut_vce_add_animation_delay' ) ) {
	function eut_vce_add_animation_delay() {
		return array(
			"type" => "textfield",
			"heading" => __('Css Animation Delay', 'eut-corpus-vc-extension'),
			"param_name" => "animation_delay",
			"value" => '200',
			"description" => __( "Add delay in milliseconds.", "eut-corpus-vc-extension" ),
		);
	}
}

if( !function_exists( 'eut_vce_add_animation' ) ) {
	function eut_vce_add_animation() {
		return array(
			"type" => "dropdown",
			"heading" => __("CSS Animation", "eut-corpus-vc-extension"),
			"param_name" => "animation",
			"admin_label" => true,
			"value" => array(
				__( "No", "eut-corpus-vc-extension" ) => '',
				__( "Fade In", "eut-corpus-vc-extension" ) => "fadeIn",
				__( "Fade In Up", "eut-corpus-vc-extension" ) => "fadeInUp",
				__( "Fade In Down", "eut-corpus-vc-extension" ) => "fadeInDown",
				__( "Fade In Left", "eut-corpus-vc-extension" ) => "fadeInLeft",
				__( "Fade In Right", "eut-corpus-vc-extension" ) => "fadeInRight",
			),
			"description" => __("Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", "eut-corpus-vc-extension" ),
		);
	}
}

if( !function_exists( 'eut_vce_add_margin_bottom' ) ) {
	function eut_vce_add_margin_bottom() {
		return array(
			"type" => "textfield",
			"heading" => __('Bottom margin', 'eut-corpus-vc-extension'),
			"param_name" => "margin_bottom",
			"description" => __( "You can use px, em, %, etc. or enter just number and it will use pixels.", "eut-corpus-vc-extension" ),
		);
	}
}

if( !function_exists( 'eut_vce_add_el_class' ) ) {
	function eut_vce_add_el_class() {
		return array(
			"type" => "textfield",
			"heading" => __( "Extra class name", "eut-corpus-vc-extension" ),
			"param_name" => "el_class",
			"description" => __( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "eut-corpus-vc-extension" ),
		);
	}
}

if( !function_exists( 'eut_vce_add_align' ) ) {
	function eut_vce_add_align() {
		return array(
			"type" => "dropdown",
			"heading" => __( "Alignment", "eut-corpus-vc-extension" ),
			"param_name" => "align",
			"value" => array(
				__( "Left", "eut-corpus-vc-extension" ) => 'left',
				__( "Right", "eut-corpus-vc-extension" ) => 'right',
				__( "Center", "eut-corpus-vc-extension" ) => 'center',
			),
			"description" => '',
		);
	}
}

if( !function_exists( 'eut_vce_add_button_type' ) ) {
	function eut_vce_add_button_type() {
		return array(
			"type" => "dropdown",
			"heading" => __( "Button type", "eut-corpus-vc-extension" ),
			"param_name" => "button_type",
			"value" => array(
				__( "Simple", "eut-corpus-vc-extension" ) => 'simple',
				__( "Outline", "eut-corpus-vc-extension" ) => 'outline',
			),
			"description" => __( "Select button type.", "eut-corpus-vc-extension" ),
			"group" => __( "Button", "eut-corpus-vc-extension" ),
		);
	}
}

if( !function_exists( 'eut_vce_add_button_color' ) ) {
	function eut_vce_add_button_color() {
		return array(
			"type" => "dropdown",
			"heading" => __( "Button Color", "eut-corpus-vc-extension" ),
			"param_name" => "button_color",
			"value" => array(
				__( "Primary 1", "eut-corpus-vc-extension" ) => 'primary-1',
				__( "Primary 2", "eut-corpus-vc-extension" ) => 'primary-2',
				__( "Primary 3", "eut-corpus-vc-extension" ) => 'primary-3',
				__( "Primary 4", "eut-corpus-vc-extension" ) => 'primary-4',
				__( "Primary 5", "eut-corpus-vc-extension" ) => 'primary-5',
				__( "Green", "eut-corpus-vc-extension" ) => 'green',
				__( "Orange", "eut-corpus-vc-extension" ) => 'orange',
				__( "Red", "eut-corpus-vc-extension" ) => 'red',
				__( "Blue", "eut-corpus-vc-extension" ) => 'blue',
				__( "Aqua", "eut-corpus-vc-extension" ) => 'aqua',
				__( "Purple", "eut-corpus-vc-extension" ) => 'purple',
				__( "Black", "eut-corpus-vc-extension" ) => 'black',
				__( "Grey", "eut-corpus-vc-extension" ) => 'grey',
				__( "White", "eut-corpus-vc-extension" ) => 'white',
			),
			"description" => __( "Color of the button.", "eut-corpus-vc-extension" ),
			"group" => __( "Button", "eut-corpus-vc-extension" ),
		);
	}
}

if( !function_exists( 'eut_vce_add_button_text' ) ) {
	function eut_vce_add_button_text() {
		return array(
			"type" => "textfield",
			"heading" => __( "Button Text", "eut-corpus-vc-extension" ),
			"param_name" => "button_text",
			"save_always" => true,
			"admin_label" => true,
			"value" => "Button",
			"description" => __( "Text of the button.", "eut-corpus-vc-extension" ),
			"group" => __( "Button", "eut-corpus-vc-extension" ),
		);
	}
}

if( !function_exists( 'eut_vce_add_button_size' ) ) {
	function eut_vce_add_button_size() {
		return array(
			"type" => "dropdown",
			"heading" => __( "Button Size", "eut-corpus-vc-extension" ),
			"param_name" => "button_size",
			"value" => array(
				__( "Extra Small", "eut-corpus-vc-extension" ) => 'extrasmall',
				__( "Small", "eut-corpus-vc-extension" ) => 'small',
				__( "Medium", "eut-corpus-vc-extension" ) => 'medium',
				__( "Large", "eut-corpus-vc-extension" ) => 'large',
				__( "Extra Large", "eut-corpus-vc-extension" ) => 'extralarge',
			),
			"description" => '',
			"std" => 'medium',
			"group" => __( "Button", "eut-corpus-vc-extension" ),
		);
	}
}

if( !function_exists( 'eut_vce_add_button_shape' ) ) {
	function eut_vce_add_button_shape() {
		return array(
			"type" => "dropdown",
			"heading" => __( "Button Shape", "eut-corpus-vc-extension" ),
			"param_name" => "button_shape",
			"value" => array(
				__( "Square", "eut-corpus-vc-extension" ) => 'square',
				__( "Round", "eut-corpus-vc-extension" ) => 'round',
				__( "Extra Round", "eut-corpus-vc-extension" ) => 'extra-round',
			),
			"description" => '',
			"std" => 'square',
			"group" => __( "Button", "eut-corpus-vc-extension" ),
		);
	}
}

if( !function_exists( 'eut_vce_add_button_link' ) ) {
	function eut_vce_add_button_link() {
		return array(
			"type" => "vc_link",
			"heading" => __( "Button Link", "eut-corpus-vc-extension" ),
			"param_name" => "button_link",
			"value" => "",
			"description" => __( "Enter link.", "eut-corpus-vc-extension" ),
			"group" => __( "Button", "eut-corpus-vc-extension" ),
		);
	}
}

if( !function_exists( 'eut_vce_add_button_class' ) ) {
	function eut_vce_add_button_class() {
		return array(
			"type" => "textfield",
			"heading" => __( "Button class name", "eut-corpus-vc-extension" ),
			"param_name" => "button_class",
			"description" => __( "If you wish to style your button differently, then use this field to add a class name and then refer to it in your css file.", "eut-corpus-vc-extension" ),
			"group" => __( "Button", "eut-corpus-vc-extension" ),
		);
	}
}

if( !function_exists( 'eut_vce_add_order_by' ) ) {
	function eut_vce_add_order_by() {
		return array(
			"type" => "dropdown",
			"heading" => __( "Order By", "eut-corpus-vc-extension" ),
			"param_name" => "order_by",
			"value" => array(
				__( "Date", "eut-corpus-vc-extension" ) => 'date',
				__( "Last modified date", "eut-corpus-vc-extension" ) => 'modified',
				__( "Number of comments", "eut-corpus-vc-extension" ) => 'comment_count',
				__( "Title", "eut-corpus-vc-extension" ) => 'title',
				__( "Author", "eut-corpus-vc-extension" ) => 'author',
				__( "Random", "eut-corpus-vc-extension" ) => 'rand',
			),
			"description" => '',
		);
	}
}

if( !function_exists( 'eut_vce_add_order' ) ) {
	function eut_vce_add_order() {
		return array(
			"type" => "dropdown",
			"heading" => __( "Order", "eut-corpus-vc-extension" ),
			"param_name" => "order",
			"value" => array(
				__( "Descending", "eut-corpus-vc-extension" ) => 'DESC',
				__( "Ascending", "eut-corpus-vc-extension" ) => 'ASC'
			),
			"dependency" => Array( 'element' => "order_by", 'value' => array( 'date', 'modified', 'comment_count', 'name', 'author', 'title' ) ),
			"description" => '',
		);
	}
}

if( !function_exists( 'eut_vce_add_slideshow_speed' ) ) {
	function eut_vce_add_slideshow_speed() {
		return array(
			"type" => "textfield",
			"heading" => __( "Slideshow Speed", "eut-corpus-vc-extension" ),
			"param_name" => "slideshow_speed",
			"value" => '3000',
			"description" => __( "Slideshow Speed in ms.", "eut-corpus-vc-extension" ),
		);
	}
}

if( !function_exists( 'eut_vce_add_pagination_speed' ) ) {
	function eut_vce_add_pagination_speed() {
		return array(
			"type" => "textfield",
			"heading" => __( "Pagination Speed", "eut-corpus-vc-extension" ),
			"param_name" => "pagination_speed",
			"value" => '400',
			"description" => __( "Pagination Speed in ms.", "eut-corpus-vc-extension" ),
		);
	}
}

if( !function_exists( 'eut_vce_add_navigation_type' ) ) {
	function eut_vce_add_navigation_type() {
		return array(
			"type" => "dropdown",
			"heading" => __( "Navigation Type", "eut-corpus-vc-extension" ),
			"param_name" => "navigation_type",
			'value' => array(
				__( 'Style 1' , 'eut-corpus-vc-extension' ) => '1',
				__( 'Style 2' , 'eut-corpus-vc-extension' ) => '2',
				__( 'Style 3' , 'eut-corpus-vc-extension' ) => '3',
				__( 'Style 4' , 'eut-corpus-vc-extension' ) => '4',
				__( 'No Navigation' , 'eut-corpus-vc-extension' ) => '0',
			),
			"description" => __( "Select your Navigation type.", "eut-corpus-vc-extension" ),
		);
	}
}

if( !function_exists( 'eut_vce_add_navigation_color' ) ) {
	function eut_vce_add_navigation_color() {
		return array(
			"type" => "dropdown",
			"heading" => __( "Navigation Color", "eut-corpus-vc-extension" ),
			"param_name" => "navigation_color",
			'value' => array(
				__( 'Dark' , 'eut-corpus-vc-extension' ) => 'dark',
				__( 'Light' , 'eut-corpus-vc-extension' ) => 'light',
			),
			"description" => __( "Select the background Navigation color.", "eut-corpus-vc-extension" ),
		);
	}
}

if( !function_exists( 'eut_vce_add_auto_height' ) ) {
	function eut_vce_add_auto_height() {
		return array(
			"type" => 'checkbox',
			"heading" => __( "Auto Height", "eut-corpus-vc-extension" ),
			"param_name" => "auto_height",
			"value" => Array( __( "Select if you want smooth auto height", "eut-corpus-vc-extension" ) => 'yes' ),
		);
	}
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
